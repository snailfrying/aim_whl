# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :BaggingRegression.py

@Time      :2023/7/6 9:59

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''


import sys
sys.path.append('../../..')
import warnings
warnings.filterwarnings("ignore")
from loguru import logger
from scipy.stats import uniform
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)
import numpy as np
from sklearn.ensemble import BaggingRegressor
from sklearn.tree import DecisionTreeRegressor

class NewBaggingRegressor(BaggingRegressor):
    # 重写feature_importances_属性
    @property
    def feature_importances_(self):
        # 计算特征重要性
        feature_importances = np.mean(
            [tree.feature_importances_ for tree in self.estimators_],
            axis=0
        )
        # 返回一个numpy数组
        # 将数组中小于0的置为0
        feature_importances[feature_importances < 0] = 0

        return np.array(feature_importances)




@logger.catch
def definition_model():
    # 定义参数分布
    param_dist = {
        'n_estimators': range(50, 200),
        'max_samples': range(1, 100),
        'random_state': range(1, 50)
    }
    model = NewBaggingRegressor()
    # model = BaggingRegressor(DecisionTreeRegressor())
    return model, param_dist
