# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :SVRRegression.py

@Time      :2023/7/6 9:55

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''


import sys
sys.path.append('../../..')
import warnings
warnings.filterwarnings("ignore")
from loguru import logger
from scipy.stats import uniform
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)

from sklearn.svm import SVR
import numpy as np





@logger.catch
def definition_model():
    # 定义参数分布
    # 'C', 'cache_size', 'coef0', 'degree', 'epsilon', 'gamma', 'kernel', 'max_iter', 'shrinking', 'tol', 'verbose'
    param_dist = {
        'C': np.logspace(-3, 3, 10),  # C是正则化参数的倒数，范围从10^-3到10^3
        'cache_size': [200, 300, 400, 500],  # cache_size是内核缓存的大小（以MB为单位）
        'coef0': np.linspace(0, 1, 10),  # coef0是核函数中的独立项，对于'poly'和'sigmoid'有意义
        'degree': np.arange(1, 6),  # degree是多项式核函数的次数，必须是非负整数
        'epsilon': np.logspace(-3, 1, 10),  # epsilon是epsilon-SVR模型中的epsilon-管，范围从10^-3到10^1
        'gamma': ['scale', 'auto'] + list(np.logspace(-4, 0, 10)),
        # gamma是'rbf'，'poly'和'sigmoid'核函数的系数，可以是'scale'，'auto'或浮点数
        'kernel': ['linear', 'poly', 'rbf', 'sigmoid', 'precomputed'],  # kernel是指定算法中使用的核函数类型，可以是字符串或可调用对象
        'max_iter': range(1000,3000),  # max_iter是求解器内部迭代的硬限制，-1表示无限制
        'tol': np.logspace(-6, -2, 10),  # tol是停止准则的容差
    }

    model = SVR()
    return model, param_dist
