# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :DecisionTreeRegression.py

@Time      :2023/7/6 9:58

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''


import sys
sys.path.append('../../..')
import warnings
warnings.filterwarnings("ignore")
from loguru import logger
from scipy.stats import uniform
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)

from sklearn.tree import DecisionTreeRegressor





@logger.catch
def definition_model():
    # 定义参数分布
    param_dist = {
        'splitter': ['best', 'random'],
        'max_features': [None, 'sqrt', 'log2'],
        'max_depth': range(10, 100),
        'min_samples_split': range(2, 10),
        'min_samples_leaf': range(1, 10),
        'min_weight_fraction_leaf': uniform(0, 0.5)
    }
    model = DecisionTreeRegressor()
    return model, param_dist
