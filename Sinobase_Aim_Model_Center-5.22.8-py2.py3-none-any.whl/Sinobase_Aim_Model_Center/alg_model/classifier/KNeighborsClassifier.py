# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :KNeighborsClassifier.py

@Time      :2023/5/19 10:22

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''
import sys
import warnings

from loguru import logger
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LassoCV
from sklearn.neighbors import KNeighborsClassifier
import numpy as np
sys.path.append('../../..')
warnings.filterwarnings("ignore")
from warnings import simplefilter

simplefilter(action='ignore', category=FutureWarning)


# for k in range(2, 10, 1):
# KNeighborsClassifier

class NewKNeighborsClassifier(KNeighborsClassifier):
    # 重写feature_importances_属性
    def fit(self, X, y):
        super().fit(X, y)
        self.X_ = X
        self.y_ = y
        return self

    @property
    def feature_importances_(self):
        result = permutation_importance(self, self.X_, self.y_)
        return result.importances_mean


@logger.catch
def definition_model():
    # 定义参数分布
    param_dist = {
        'algorithm': ['auto', 'ball_tree', 'kd_tree', 'brute'],
        'n_neighbors': range(2, 10),
        'weights': ['uniform', 'distance'],
        'leaf_size': range(10, 50),
        'p': range(1, 3),
        'metric': ['minkowski', 'euclidean', 'manhattan', 'chebyshev']
    }
    model = NewKNeighborsClassifier()
    return model, param_dist
