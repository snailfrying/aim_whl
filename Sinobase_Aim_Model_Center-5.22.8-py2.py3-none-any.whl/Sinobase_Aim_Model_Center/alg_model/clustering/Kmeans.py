# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :Kmeans.py

@Time      :2023/8/30 17:02

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
import sys
sys.path.append('../../..')
import warnings
warnings.filterwarnings("ignore")
from loguru import logger
from scipy.stats import uniform
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)

from sklearn.cluster import KMeans

@logger.catch
def definition_model():
    # 定义参数分布
    param_dist = {

    }
    model = KMeans()
    return model, param_dist
