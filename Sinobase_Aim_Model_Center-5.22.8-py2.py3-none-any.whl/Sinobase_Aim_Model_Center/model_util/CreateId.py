# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :CreateId.py

@Time      :2023/6/16 10:18

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''


# 随机生成len长度的字符串，如果num为true 则生成的字符串含有数组，如果word为true则生成的字符串含有字母
def CreateOnes(num, word, len):
    import random
    if num == True and word == True:
        str = '1234567890abcdefghijklmnopqrstuvwxyz'
    elif num == True and word == False:
        str = '1234567890'
    elif num == False and word == True:
        str = 'abcdefghijklmnopqrstuvwxyz'
    else:
        str = 'abcdefghijklmnopqrstuvwxyz'
    salt = ''
    for i in range(len):
        salt += random.choice(str)
    return salt


def Create():
    a = CreateOnes(True, True, 8)
    b = CreateOnes(True, True, 4)
    c = CreateOnes(True, True, 4)
    d = CreateOnes(True, True, 4)
    e = CreateOnes(True, True, 12)
    str = a + '-' + b + '-' + c + '-' + d + '-' + e
    return str
