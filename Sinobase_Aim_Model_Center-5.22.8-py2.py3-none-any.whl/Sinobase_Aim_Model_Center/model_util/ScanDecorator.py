# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :scan.py

@Time      :2023/11/08 11:20

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''

import ast


def count_decorators(file):
    funclist = {}
    num_list = []
    var_list = []
    all_list = []
    col_list = []
    seq_list = []
    with open(file, 'r', encoding='utf-8') as f:
        source = f.read()
        tree = ast.parse(source)
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                if len(node.decorator_list) > 0:
                    seq_list.append(node.name)
                    if node.decorator_list[0].id == 'num_feature':
                        num_list.append(node.name)
                    if node.decorator_list[0].id == 'var_feature':
                        var_list.append(node.name)
                    if node.decorator_list[0].id == 'all_feature':
                        all_list.append(node.name)
                    if node.decorator_list[0].id == 'col_feature':
                        col_list.append(node.name)
    funclist['all'] = all_list
    funclist['col'] = col_list
    funclist['var'] = var_list
    funclist['num'] = num_list
    funclist['seq'] = seq_list
    return funclist
