# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :renamedf.py

@Time      :2023/5/23 13:58

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''


#对dataframe的列进行重命名
def redfcolumnname(df):
    indexlist = []
    for i in range(len(df.columns)):
        indexlist.append("c"+str(i))
    df.columns = indexlist
    return df
