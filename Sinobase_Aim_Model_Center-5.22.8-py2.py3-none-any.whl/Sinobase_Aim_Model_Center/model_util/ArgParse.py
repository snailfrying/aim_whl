# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :ArgParse.py

@Time      :2023/5/19 13:58

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

import argparse
from loguru import logger

@logger.catch
def CreateHeader():
    parser = argparse.ArgumentParser()
    parser.description = '请输入参数'
    parser.add_argument("-cdb", "--configdatabase", help="选择一个配置数据库['MYSQL','PGSQL','ELASTICSEARCH']", dest="configdatabase", type=str, default="mysql")
    parser.add_argument("-ydb", "--sourcedatabase", help="选择一个源数据库['MYSQL','PGSQL','ELASTICSEARCH']", dest="sourcedatabase", type=str, default="pgsql")
    parser.add_argument("-t", "--task_id", help="任务id", dest="task_id", type=str, default=None)
    parser.add_argument("-tn", "--tenant", help="租户id", dest="tenant", type=str, default=None)
    parser.add_argument("-f", "--filetype", help="文件类型，1是数据库，2是csv文件", dest="filetype", type=int, default=0)
    parser.add_argument("-l", "--location", help="如果是数据库，就是表名，否则是文件路径", dest="location", type=str, default=None)
    parser.add_argument("-s", "--study", help="自学习", dest="study", type=int, default=0)
    parser.add_argument("-u", "--update_id", help="更新", dest="update_id", type=int, default=0)
    parser.add_argument("-m", "--modelname", help="预测的模型", dest="modelname", type=str, default='test_model_center')
    parser.add_argument("-cv", "--cv", help="交叉验证数", dest="cv", type=int, default=2)
    parser.add_argument("-p", "--predict", help="预测id", dest="predict", type=str, default=None)
    parser.add_argument("-pr", "--primary", help="推送主键", dest="primary", type=str, default=None)
    parser.add_argument("-g", "--group", help="group_id", dest="group_id", type=str, default=None)
    parser.add_argument("-api", "--api_data", help="Api预测的json数据", dest="api_data", type=str, default=None)

    # # parser.add_argument("-s", "--separation", help="特征与标签是否是分离值，True-False", dest="separation", type=int, default=False)
    # parser.add_argument("-m", "--modelname", help="使用的模型的名称", dest="modelname", type=str, default="defalt")
    # parser.add_argument("-fdb", "--featuredb", help="特征 表名称", dest="featuredb", type=str, default="NoTable")
    # parser.add_argument("-ldb", "--labeldb", help="标签 表名称", dest="labeldb", type=str, default="NoTable")
    # parser.add_argument("-algs", "--algorithms", help="选择的多种算法名称", dest="algorithms", type=str, default="NoAlgs")
    # parser.add_argument("-algs", "--algorithms", help="选择的多种算法名称", dest="algorithms", type=str,
    #                     default="NoAlgs")
    args = parser.parse_args()

    return args
