# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :DatabricksGetPassword.py

@Time      :2023/11/03 11:05

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
from databricks.sdk.runtime import *

def get_password_from_secrets(secret_scope, secret_key):
    """
    从databricks密钥存储中获取密码
    args:
        secret_scope(str): 密钥作用域的名称
        secret_name(str): 密钥的名称
    return:
        password: 获取的key_value
    """
    try:
        key_value = dbutils.secrets.get(secret_scope, secret_key)
        return key_value
    except Exception as e:
        raise Exception(f"Failed to retrieve key from secrets:{str(e)}")

