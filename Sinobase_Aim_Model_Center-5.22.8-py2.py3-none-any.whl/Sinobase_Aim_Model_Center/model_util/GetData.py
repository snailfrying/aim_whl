# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :GetData.py

@Time      :2023/6/6 16:47

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''
import copy

from loguru import logger
import re
import os
from pathlib import Path
import importlib.util
from datetime import datetime
import pandas as pd
from warnings import simplefilter
from Sinobase_Aim_Model_Center.model_util import ScanDecorator, dfutil
from scipy import stats
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_classif  # 用于分类数据的F检验
from sklearn.feature_selection import f_regression  # 用于回归数据的F检验
import numpy as np
import Sinobase_Aim_Model_Center.model_util.SuperVar as SuperVar
from Sinobase_Aim_Model_Center.model_center.Feature_Engineering import System_script
from Sinobase_Aim_Model_Center.model_util import loadScriptConstructor

simplefilter(action='ignore', category=FutureWarning)
import sys


# 检查cupy是否已经安装

# import subprocess
# try:
#     subprocess.check_output('nvidia-smi')
#     import cupy as np
#     np.cuda.Device(1)
#     # import numpy as np
#     # logger.info("GPU")
# except Exception:
#     import numpy as np

@logger.catch
def Deal_var(var_miss, var_focus, var_type, var_onehot, var_group, dataXvar, sourcedata, engine):
    SuperVar.setVar("sourcedata", sourcedata)
    logger.info('开始处理字符型变量')
    SuperVar.setVar('var_group', var_group)
    # if int(var_group):
    #     System_script.var_group()
    sourcedata = SuperVar.getVar('sourcedata')
    feature = SuperVar.getVar("feature")
    dataXvar = feature.loc[feature['feature_type'] == '字符型变量']
    for i, j in zip(dataXvar['feature_name'], dataXvar['id']):
        # 计算缺失率
        if float(var_miss) > float(sourcedata[i].count()) / float(sourcedata[i].shape[0]) * 100:
            logger.debug("%s缺失率过高————排除" % i)
            logger.info("%s缺失率过高————排除" % i)
            engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % j)
            sourcedata.drop(columns=[i], inplace=True)
            continue
        # 计算集中
        if float(var_focus) < float(sum(sourcedata[i] == sourcedata[i].mode().values[0])) / float(
                sourcedata[i].count()) * 100:
            logger.debug("%s集中度过高————排除" % i)
            logger.info("%s集中度过高————排除" % i)
            engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % j)
            sourcedata.drop(columns=[i], inplace=True)
            continue
        # 计算类型数
        if int(var_type) < len(sourcedata[i].unique()):
            logger.debug("%s类型过多————排除" % i)
            logger.info("%s类型过多————排除" % i)
            engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % j)
            sourcedata.drop(columns=[i], inplace=True)
            continue
        # 如果不选择onehot 那么就全部排除  (变量值分组？？？？？)
        if int(var_onehot):
            sourcedata[i] = pd.get_dummies(sourcedata[i]).astype(int).apply(lambda x: ''.join(x.astype(str)), axis=1)
        else:
            engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % j)
            if i in sourcedata.columns:
                sourcedata.drop(columns=[i], inplace=True)
            else:
                logger.error(f"异常列：{i}")
            continue

    return sourcedata


def Deal_int(num_miss, num_focus, num_fill, num_swap, dataXint, sourcedata, engine):
    # SuperVar.setVar("sourcedata",sourcedata)
    logger.info("正在处理数值型")
    SuperVar.setVar('num_fill', num_fill)
    # 均值填充
    # if int(num_fill) == 1:
    #     System_script.Numerical_filling_mean()
    # #     大
    # if int(num_fill) == 2:
    #     System_script.Numerical_filling_max()
    # #     小
    # if int(num_fill) == 3:
    #     System_script.Numerical_filling_min()
    # #     0
    # if int(num_fill) == 4:
    #     System_script.Numerical_filling_zero()
    # 数值变换
    SuperVar.setVar('num_swap', num_swap)
    # if int(num_swap):
    #     System_script.Numerical_switch()
    sourcedata = SuperVar.getVar('sourcedata')
    feature = SuperVar.getVar("feature")
    dataXint = feature.loc[feature['feature_type'] == '数值型变量']
    for i, j in zip(dataXint['feature_name'], dataXint['id']):
        # 计算缺失率
        try:
            if float(num_miss) > float(sourcedata[i].count()) / float(sourcedata[i].shape[0]) * 100:
                logger.debug("%s缺失率过高————排除" % i)
                logger.info("%s缺失率过高————排除" % i)
                engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % j)
                sourcedata.drop(columns=[i], inplace=True)
                continue
            # 计算集中
            if float(num_focus) < float(sum(sourcedata[i] == sourcedata[i].mode().values[0])) / float(
                    sourcedata[i].count()) * 100:
                logger.debug("%s集中度过高————排除" % i)
                logger.info("%s集中度过高————排除" % i)
                engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % j)
                sourcedata.drop(columns=[i], inplace=True)
                continue
        except Exception as e:
            logger.error(e)
            engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % j)
            if i in sourcedata.columns:
                sourcedata.drop(columns=[i], inplace=True)
            else:
                logger.error(f"异常列：{i}")
            continue
        # 处理其他情况

    logger.info("数值型处理完成")
    return sourcedata


@logger.catch
def Deal_feature(feature_skip, feature_num, sourcedata, engine):
    SuperVar.setVar("sourcedata", sourcedata)
    if not int(feature_skip):
        logger.debug('跳过特征选择')
        logger.info('跳过特征选择')
        savedata = sourcedata.iloc[:, int(feature_num):]
        for i, j in zip(savedata['feature_name'], savedata['id']):
            engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % j)
            sourcedata.drop(columns=[i], inplace=True)
    return sourcedata


@logger.catch
def GetDataStart(engine, sourceengine, sc_type):
    global vfdataX, vfdataY
    vfdataX, vfdataY = None, None
    logger.info("开始获取数据")
    task_id = SuperVar.getVar("task_id")
    # tenant = args.tenant
    filetype = SuperVar.getVar("filetype")

    # self_learing = args.study
    # update_id = args.update_id

    # dir_path = '/aim/model/train'
    # logger.info(args)
    #     读取参数
    params = engine.execute(sql="""select * from model_instance where id = '%s'""" % task_id)
    location = SuperVar.getVar("location")
    #     获取选择算法
    self_learing = 0
    update_id = 0
    # 是否自学习状态
    if self_learing == 0 and update_id == 0:
        model_type = '正常'
        SuperVar.setVar('model_type', 0)
    elif self_learing == 0 and update_id != 0:
        model_type = '更新'
        SuperVar.setVar('model_type', 1)
        feature = engine.execute(sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % task_id)
        SuperVar.setVar('old_feature', feature)
    else:
        model_type = '自学习'
        SuperVar.setVar('model_type', 2)
        feature = engine.execute(sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % task_id)
        SuperVar.setVar('old_feature', feature)

    #     文件路径
    if SuperVar.getVar("System_info") == 'User':
        filetype = 2
        location = SuperVar.getVar("file_path")

    if filetype == 1:
        table_name = location
        if SuperVar.getVar("source_database") == 'pgsql':
            sourcedata = sourceengine.execute(
                sql="""select * from """ + SuperVar.getVar("tenant") + """.%s""" % table_name)
        else:
            sourcedata = sourceengine.execute(sql="""select * from %s""" % table_name)

    elif filetype == 2:
        # print(location)
        try:
            sourcedata = pd.read_csv(location)
        except Exception as e:
            logger.error("文件不存在")
            logger.error(e)
            return '', '', '', '', '', '文件不存在,请联系管理员', False
    else:
        logger.error('请输入正确的数据路径')
        return '', '', '', '', '', '请输入正确的数据路径', False
    SuperVar.setVar("sourcedata", sourcedata)
    validation = params['validation'].values[0]
    # 读取特征字典
    # 先让特征字典进行初始化
    engine.execute(
        sql="""UPDATE model_feature SET deleted = 1 WHERE task_id='%s' and create_user = 'System_create'""" % task_id)
    feature = engine.execute(sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % task_id)
    SuperVar.setVar('feature', feature)
    logger.debug(feature['feature_type'])

    # 选择使用的算法
    algorithm = engine.execute(
        sql="""select func from alg_map where id in (%s)""" % params['algorithm'].to_string(index=False))

    # 特征集合
    # 先对 Y 进行判断，如果不符合要求，那么直接结束训练：
    # 二分类 0-1 多分类 int 回归 int
    # 目标集合
    dataYname = feature.loc[feature['feature_type'] == '目标变量']
    dataY = sourcedata[dataYname['feature_name']]

    logger.debug(dataY)

    # 定义一个函数，用来判断一个字符串是否是纯数字或者是小数
    def is_number(s):
        try:
            float(s)  # 尝试将字符串转换为浮点数
            return True  # 如果成功，返回True
        except ValueError:  # 如果出现错误，返回False
            return False

    regress_result = True
    if sc_type == 'classier':
        if dataY.isin([0, 1]).all()[0]:
            logger.info("特征校验通过——二分类")
        else:
            logger.error("请检查 目标变量 是否只含有0或1")
            return '', '', '', '', '', '请检查 目标变量 是否只含有0或1', False

    if sc_type == 'regress':
        for index, row in dataY.iterrows():
            if not is_number(row[0]):  # 如果不是纯数字或者是小数，将结果改为"no"，并跳出循环
                logger.error(row[0])
                regress_result = False
                break
        if regress_result:
            logger.info("特征校验通过——回归")
        else:
            logger.error("请检查 目标变量 是否是数字，不应当包含字符")
            return '', '', '', '', '', '请检查 目标变量 是否是数字，不应当包含字符', False

    # 4.验证集

    if validation:
        vf_name = params['validation_field_name'].values[0]
        vf_label = params['validation_label'].values[0]
        vf_value = params['validation_value'].values[0]
        vf_type = params['validation_field_type'].values[0]

        if vf_type == 2:
            vf_value = float(vf_value)

        #     从sourcedata中，找到列名为vf_name的列，按照vf_operator和vf_value进行筛选 其中vf_label的操作有 “等于、不包含、不等于、为空、不为空、包含” 将他保存为验证集 并在sourcedata中删除
        logger.info("开始验证集处理")
        logger.debug("开始验证集处理")
        if vf_label == '等于':
            vf = sourcedata[sourcedata[vf_name] == vf_value]
        elif vf_label == '不包含':
            vf = sourcedata[~sourcedata[vf_name].str.contains(vf_value)]
        elif vf_label == '不等于':
            vf = sourcedata[sourcedata[vf_name] != vf_value]
        elif vf_label == '为空':
            vf = sourcedata[sourcedata[vf_name].isnull()]
        elif vf_label == '不为空':
            vf = sourcedata[sourcedata[vf_name].notnull()]
        elif vf_label == '包含':
            vf = sourcedata[sourcedata[vf_name].str.contains(vf_value)]
        else:
            logger.error("验证集操作符错误")
            return '', '', '', '', '', '验证集操作符错误', False

    # 加入用户自定义处理
    # 重新读取特征字典

    feature = engine.execute(sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % task_id)
    SuperVar.setVar('feature', feature)

    dataXvar = feature.loc[feature['feature_type'] == '字符型变量']
    dataXint = feature.loc[feature['feature_type'] == '数值型变量']
    dataID = feature.loc[feature['feature_type'] == 'ID']['feature_name'].values.tolist()[0]
    SuperVar.setVar("dataXvar", dataXvar)
    SuperVar.setVar("dataXint", dataXint)
    SuperVar.setVar("dataID", dataID)
    #
    # 变量值分组
    var_group = params['var_group']
    # 缺失值填充方法
    num_fill = params['num_fill']
    # 是否使用数据交换
    num_swap = params['num_exchange']
    SuperVar.setVar('var_group', var_group)
    SuperVar.setVar('num_fill', num_fill)
    SuperVar.setVar('num_swap', num_swap)
    baseconfig = SuperVar.getVar("base_config")
    if baseconfig['system_script']:
        logger.info("开始使用系统脚本处理数据")
        # 系统模板脚本处理
        default_feature_path = Path(__file__).parent.parent / 'model_center' / 'Feature_Engineering'
        system_default = default_feature_path / 'default.py'
        if not os.path.exists(system_default):
            system_default = default_feature_path / 'default.pyc'
        loadScriptConstructor.Script_System(system_default)
    logger.info("外部脚本处理数据已经完成")
    # function_list = ScanDecorator.count_decorators(system_default)
    # func_num_size = cal_dict_size(function_list)
    # logger.info(f"外部脚本处理总计： {func_num_size['sum']} 个")
    # for key in list(func_num_size.keys()):
    #     if key != 'sum' and key != 'seq':
    #         logger.info(f"{key}特征处理 脚本个数： {func_num_size[key]} 个")
    # spec = importlib.util.spec_from_file_location("module.name", system_default)
    # module = importlib.util.module_from_spec(spec)
    # spec.loader.exec_module(module)
    # # for key in list(function_list.keys()):
    # for func in function_list['seq']:
    #     logger.info(f"正在处理外部脚本 --> {func} ")
    #     getattr(module, func)()

    sourcedata = SuperVar.getVar("sourcedata")
    # print("外部脚本 ↓")
    # print(sourcedata.columns.to_list())
    # print("外部脚本 ↑")
    # 获取各种类型数据处理方式
    # 1.字符型变量

    logger.info("开始使用用户脚本处理数据")

    caller = SuperVar.getVar('main_file')
    if caller != 'GuanJiahao':
        loadScriptConstructor.Script_seq(caller)
        logger.info("用户脚本处理数据已经完成")
    else:
        logger.info("没有发现用户脚本无法处理")

    # function_list = ScanDecorator.count_decorators(caller)
    # func_num_size = cal_dict_size(function_list)
    # logger.info(f"用户脚本处理总计： {func_num_size['sum']} 个")
    # for key in list(func_num_size.keys()):
    #     if key != 'sum' and key != 'seq':
    #         logger.info(f"{key}特征处理 脚本个数： {func_num_size[key]} 个")
    # spec = importlib.util.spec_from_file_location("module.name", caller.strip(' '))
    # module = importlib.util.module_from_spec(spec)
    # spec.loader.exec_module(module)
    # for func in function_list['seq']:
    #     logger.info(f"正在处理脚本 --> {func} ")
    #     getattr(module, func)()

    sourcedata = SuperVar.getVar("sourcedata")
    # TODO 页面处理这里存在严重bug 等待修改
    # 修改逻辑 根据 数据库中的列 正控 dataframe
    logger.info("开始处理页面勾选数据")
    # todo 下列逻辑中存在问题
    # 获取最新的
    feature = engine.execute(sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % task_id)
    # org_feature_list = feature.loc[feature['feature_type'].isin(['字符型变量', '数值型变量', 'ID', '目标变量'])][
    #     'feature_name'].values.tolist()
    org_feature_list = feature.loc[feature['feature_type'].isin(['字符型变量', '数值型变量'])][
        'feature_name'].values.tolist()
    SuperVar.setVar('org_feature_list', copy.deepcopy(org_feature_list))
    org_feature_list = SuperVar.getVar("org_feature_list")
    # 比较 现在的sourcedata 和 org_feature_list
    in_source, in_org, out = dfutil.compareA2Blist(sourcedata, org_feature_list)

    logger.info("原数据 sourceData: " + str(sourcedata.columns))
    logger.info("数据库中存在的列 org_feature_list: " + str(org_feature_list))
    logger.info("in_source: " + str(in_source))
    logger.info("in_org: " + str(in_org))
    logger.info("交集out: " + str(out))
    # 判断字段是否在sourcedata中
    for i in in_org:
        if i in sourcedata.columns:
            # 排除页面配出的字段
            sourcedata.drop(i, axis=1, inplace=True)
        else:
            logger.error(f"排除可能异常，字段 {i} 不存在，当前全部列：{str(sourcedata.columns)}")

    new_feature_list = feature.loc[feature['feature_type'].isin(['ID', '目标变量'])][
        'feature_name'].values.tolist()
    for i in new_feature_list:
        in_source.remove(i)
    logger.info("排除页面选中字段:" + str(in_source))
    for i in in_source:
        logger.info('排除额外字段:' + str(i))
        feature_id = feature.query(f'feature_name == "{i}"')['id'].values.tolist()[0]
        engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % feature_id)
        sourcedata.drop(i, axis=1, inplace=True)



    logger.info("org_feature_list: " + str(org_feature_list))
    for i in in_org:
        sql = """INSERT INTO model_feature  (task_id, feature_name, field_type, feature_type, feature_attr, feature_explain, feature_item, feature_count, feature_complete, feature_complete_rate, feature_category, feature_many, feature_many_rate, create_user, update_user, create_time, update_time, tenant_api_name) VALUES ('%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s')""" % (
            SuperVar.getVar("task_id"), str(i), 'number', '数值型变量', '其他', str(i), str(i), sourcedata[i].shape[0],
            len(sourcedata[sourcedata[i].notnull()]), len(sourcedata[sourcedata[i].notnull()]) / sourcedata[i].shape[0],
            len(set(sourcedata[i])), sourcedata[i].mode()[0],
            sourcedata[i].value_counts().max() / sourcedata[i].shape[0],
            'System_create', 'System_create', datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"), SuperVar.getVar("tenant"))
        engine.execute(
            sql=sql)
    logger.info("页面勾选处理已经完成")
    SuperVar.setVar("sourcedata", sourcedata)
    # 处理逻辑， 分别对字符型和数值型进行处理，然后统一获取一次
    feature = engine.execute(sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % task_id)
    SuperVar.setVar("feature", feature)
    dataXvar = feature.loc[feature['feature_type'] == '字符型变量']
    dataXint = feature.loc[feature['feature_type'] == '数值型变量']

    # print("用户脚本 ↓")
    # print(sourcedata.columns.to_list())
    # print("用户脚本 ↑")

    if validation:
        vfdataY = vf[dataYname['feature_name']]
    # 1.字符型变量
    # 最大缺失率
    var_miss = params['var_miss']
    # 最大变量集中程度，
    var_focus = params['var_focus']
    # 最多类型数，
    var_type = params['var_type']
    # OneHot编码，
    var_onehot = params['var_onehot']
    # 变量值分组
    var_group = params['var_group']
    sourcedata = Deal_var(var_miss, var_focus, var_type, var_onehot, var_group, dataXvar, sourcedata, engine)
    if validation:
        vf = Deal_var(var_miss, var_focus, var_type, var_onehot, var_group, dataXvar, vf, engine)
    # 2.数值型变量
    # 最大缺失率
    num_miss = params['num_miss']
    # 最大变量集中程度，
    num_focus = params['num_focus']
    # 缺失值填充方法
    num_fill = params['num_fill']
    # 是否使用数据交换
    num_swap = params['num_exchange']
    sourcedata = Deal_int(num_miss, num_focus, num_fill, num_swap, dataXint, sourcedata, engine)
    if validation:
        vf = Deal_int(num_miss, num_focus, num_fill, num_swap, dataXint, vf, engine)
    # 3.特征筛选
    # 是否跳过特征筛选
    feature_skip = params['feature_screening']
    # 保留特征数
    feature_num = params['feature_number']

    # sourcedata = Deal_feature(feature_skip, feature_num, sourcedata, engine)
    if validation:
        pass
        # vf = Deal_feature(feature_skip, feature_num, vf, engine)
    if SuperVar.getVar("model_type") == 0:
        logger.info("正常训练")
        feature = engine.execute(sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % task_id)
        SuperVar.setVar('feature', feature)
    elif SuperVar.getVar("model_type") == 1:
        logger.info("更新")
        feature = SuperVar.getVar("old_feature")
    else:
        logger.info("自学习")
        feature = SuperVar.getVar("old_feature")
    dataXnotname = feature.loc[feature['feature_type'].isin(['排除'])]
    dataXIDname = feature.loc[feature['feature_type'].isin(['目标变量', 'ID'])]
    dataXIDnameCol = dataXIDname['feature_name'].values.tolist()

    logger.info(f"dataXIDnameCol 去掉目标变量与ID->{dataXIDnameCol}")

    # 按顺序从dataXname中拿到name 并从数据集中抽出对应的列

    # sourcedata = SuperVar.getVar("sourcedata")
    # 保证数据 一致性
    sourcedata_columns = set(sourcedata.columns)
    _, _, inner_col = dfutil.compareA2Blist(dataXnotname, sourcedata_columns)
    # logger.info(f"数据处理后：dataX-》{dataX.columns}")
    try:
        # dataX = sourcedata[dataXnotname['feature_name']]
        dataX = sourcedata.drop(columns=inner_col)
        dataXCol = set(dataX.columns)
        logger.info("开始验证数据中是否存在目标变量与ID")
        columns_to_drop = [col for col in dataXIDnameCol if col in dataXCol]
        logger.info(f"columns_to_drop 存在的目标变量和id->{columns_to_drop}")
        dataX.drop(columns=columns_to_drop, inplace=True)
        if validation:
            vfdataX = vf.drop(dataXnotname['feature_name'], axis=1)
            vfdataX.drop(columns=columns_to_drop, inplace=True)

        # dataX.to_csv("/opt/model-pyspark/py/guan/Aim_model/logs/data.csv")
    except Exception as e:
        logger.error('[ALL]模型计算失败')

        logger.error(e)
        engine.execute(sql="""UPDATE model_instance SET state = 4  WHERE id ='%s' """ % task_id)
        sys.exit(0)
    logger.info(f"数据处理后：dataX-》{dataX.columns}")
    return vfdataX, vfdataY, dataX, dataY, algorithm.values.tolist(), params, True


@logger.catch
def GetUserDataStart(engine, sourceengine, sc_type):
    global vfdataX, vfdataY
    vfdataX, vfdataY = None, None
    logger.info("开始获取数据")
    # 获取y的列名
    sourcedata = pd.read_csv(SuperVar.getVar("file_path"))
    sourcedata = sourcedata.assign(thisID=sourcedata.index + 1)
    SuperVar.setVar("sourcedata", sourcedata)
    SuperVar.setVar("dataID", "thisID")
    logger.info("正在处理数据")
    # 加入用户自定义处理
    caller = SuperVar.getVar('main_file')

    # function_list = ScanDecorator.count_decorators(caller)
    # func_num_size = cal_dict_size(function_list)
    # logger.info(f"用户脚本处理总计： {func_num_size['sum']} 个")
    # for key in list(func_num_size.keys()):
    #     if key != 'sum':
    #         logger.info(f"{key}特征处理 脚本个数： {func_num_size[key]} 个")
    # spec = importlib.util.spec_from_file_location("module.name", caller.strip(' '))
    # module = importlib.util.module_from_spec(spec)
    # spec.loader.exec_module(module)
    # for key in list(function_list.keys()):
    #     for func in function_list[key]:
    #         getattr(module, func)()
    loadScriptConstructor.Script_seq(caller)
    sourcedata = SuperVar.getVar('sourcedata')
    logger.info("数据处理完成")
    # 从dataframe中取出列名为y的一行
    dataY = pd.DataFrame(sourcedata[SuperVar.getVar("label")], columns=[SuperVar.getVar("label")])
    dataX = sourcedata.drop(SuperVar.getVar("label"), axis=1)
    # dataX = dataX.drop(SuperVar.getVar("dataID"), axis=1)
    data = {'proportion': ['30'],
            'cross_validation': ['0'],
            'validation': ['0'],
            'evaluation_index': ['1'],
            }

    return vfdataX, vfdataY, dataX, dataY, {}, pd.DataFrame(data), True
