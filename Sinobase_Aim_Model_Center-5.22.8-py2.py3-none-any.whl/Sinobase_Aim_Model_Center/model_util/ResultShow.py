# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :ResultShow.py

@Time      :2023/6/9 10:45

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''
import math

import datetime
from loguru import logger
import pandas as pd
from Sinobase_Aim_Model_Center.model_util import SuperVar, loadConfig, CalLoss
from Sinobase_Aim_Model_Center.model_util.paths import get_config_path
import numpy as np
import itertools
import warnings

import decimal

# from alive_progress import alive_bar

warnings.filterwarnings("ignore")


def BeforeShow(model, dataX, dataY, X_test, y_test, config, y_pred, dataY_pred, params, X_vf, y_vf, vfy_pred,
               verify_loss,
               model_name):
    # 保存模型路径
    engine = SuperVar.getVar('engine')
    engine.execute(
        sql="""INSERT INTO model_map (model_path,task_id,ass_id,model_name) VALUES ('%s', '%s','%s','%s') """ % (
            config['model_path'], config['task_id'], config['ass_id'], model_name))

    # basemodel.fit(dataX, dataY.values.ravel())
    feature_names = list(dataX.columns)
    # 获取是什么模型

    test_loss = CalLoss.cal(y_test, y_pred, config['model_species'])
    # config['datasource'] = '测试集'
    config['datasource'] = '1'
    vfy_pred_proba = []
    if config['model_species'] == 'classier':
        logger.info("使用分类模型")
        y_pred_proba = model.predict_proba(X_test)
        dataY_pred_proba = model.predict_proba(dataX)
        # 验证集
        if config['verify']:
            vfy_pred_proba = model.predict_proba(X_vf)
    elif config['model_species'] == 'regress':
        logger.info("使用回归模型")
        y_pred_proba = []
        dataY_pred_proba = []
        if config['verify']:
            vfy_pred_proba = []
    else:
        logger.info("其他模型")
        y_pred_proba = []
        dataY_pred_proba = []
        if config['verify']:
            vfy_pred_proba = []

    data_loss = CalLoss.cal(dataY, dataY_pred, config['model_species'])

    # config['datasource'] = '建模集'
    sum_insert(model_name, params, config, dataY_pred_proba, feature_names, dataY, model, dataY_pred,
               data_loss, test_loss,
               verify_loss, dataX)

    config['datasource'] = '2'
    sum_insert(model_name, params, config, y_pred_proba, feature_names, y_test, model, y_pred, data_loss,
               test_loss,
               verify_loss, X_test)
    if config['verify']:
        config['datasource'] = '3'
        sum_insert(model_name, params, config, vfy_pred_proba, feature_names, y_vf, model, vfy_pred,
                   data_loss, test_loss,
                   verify_loss, X_vf)


def sum_insert(model_name, params, config, y_pred_proba, feature_names, true_label, model, predictions, data_loss,
               test_loss,
               verify_loss, data_X):
    if config['datasource'] == '1':
        logger.info("测试集计算开始")
        # sql_log.insertSqlLog(config['task_id'],'','1','1','', SuperVar.get_engine(),time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))
        #  sql_log.insertSqlLog(args.task_id, '开始训练模型', '1', '1', '', engine, create_time)
        insert_model_assessment(data_loss, test_loss, verify_loss, model_name, config)
        logger.info("计算重要特征")
        insert_model_ass_feature(model, model_name, config, feature_names)
        logger.info("计算模型参数")
        insert_model_ass_parameter(params, model_name, config)
    elif config['datasource'] == '2':
        logger.info("建模集计算开始")
    elif config['datasource'] == '3':
        logger.info("验证集计算开始")

    if config['model_species'] == 'classier':
        logger.info("计算提升曲线")
        true_label = true_label.values.tolist()
        insert_model_lift(model, model_name, config, true_label, data_X)

        logger.info("计算混淆矩阵")
        insert_model_ass_matrix(y_pred_proba, true_label, predictions, model_name, config)
        insert_model_ass_normality(y_pred_proba, true_label, predictions, model_name, config)
    elif config['model_species'] == 'regress':
        logger.info("计算提升曲线")
        true_label = true_label.values.tolist()
        insert_regress_model_lift(model, model_name, config, true_label, data_X)


@logger.catch
def insert_model_assessment(data_loss, test_loss, verify_loss, model_name, config):
    # model_assessment
    # with alive_bar(len(data_loss),
    #                title="开始计算",
    #                bar="filling",
    #                spinner="notes",
    #                force_tty=True
    #                ) as bar:
    dictlist = []
    for i in range(len(data_loss)):
        curr_datetime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        model_assessment_table = {}
        model_assessment_table['task_id'] = config['task_id']
        model_assessment_table['ass_id'] = config['ass_id']
        model_assessment_table['model_name'] = model_name
        model_assessment_table['modeling_set'] = data_loss[i] if not math.isnan(data_loss[i]) else 0
        model_assessment_table['test_set'] = test_loss[i] if not math.isnan(data_loss[i]) else 0
        if config['verify']:
            model_assessment_table['validation_set'] = verify_loss[i] if not math.isnan(data_loss[i]) else 0
        model_assessment_table['use'] = 0
        model_assessment_table['target'] = i + 1
        # JAVA端join表
        model_assessment_table['create_user'] = None
        model_assessment_table['update_user'] = None
        model_assessment_table['version'] = config['version']

        model_assessment_table['create_time'] = curr_datetime
        model_assessment_table['update_time'] = curr_datetime
        model_assessment_table['tenant_api_name'] = config['tenant']
        model_assessment_table['deleted'] = 0
        model_assessment_table['is_history'] = 0
        # engine = SuperVar.getVar('engine')
        # engine.DictUSql(datadict=model_assessment_table, table='model_assessment')
        dictlist.append(model_assessment_table)


    engine = SuperVar.getVar('engine')
    engine.DictListSql(dictlist, table='model_assessment')
        # bar()


@logger.catch
def insert_model_ass_matrix(predictions, true_label, pre_label, model_name, config):
    # with alive_bar(100,
    #                title="计算混淆矩阵",
    #                bar="filling",
    #                spinner="notes",
    #                force_tty=True
    #                ) as bar:
    dictlist = []
    for i in np.arange(0, 1.01, 0.01):
        tp = 0
        fp = 0
        tn = 0
        fn = 0
        for m in range(len(predictions)):
            # 判断预测概率是否大于等于阈值
            # 真实值 为 0 1 0 1
            # 预测为0的1的概率  0.3 0.5 0.1 0.6
            # 概率阈值 0.1：1 1 1 1
            # 0.5：0 1 0 1


            if predictions[m][1] >= i:
                # 判断预测标签是否与真实标签一致
                if 1 == true_label[m][0]:
                    tp += 1
                # 如果一致，并且都是负类，则为真负例
                else:
                    fp += 1
            # 判断预测概率是否小于阈值
            else:
                if 0 == true_label[m][0]:
                    tn += 1
                else:
                    fn += 1

        # tpr = tp / (tp + fn) if tp + fn != 0 else 0
        # fpr = fp / (fp + tn) if fp + tn != 0 else 0
        # precision = tp / (tp + fp) if tp + fp != 0 else 0
        tpr = tp / (tp + fn) if tp + fn != 0 else 0
        fpr = fp / (fp + tn) if fp + tn != 0 else 0
        precision = tp / (tp + fp) if tp + fp != 0 else 0
        recall = tp / (tp + fn) if tp + fn != 0 else 0
        f1_score = 2 * (precision * recall) / (precision + recall) if precision + recall != 0 else 0
        curr_datetime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        model_matrix_table = {}
        model_matrix_table['task_id'] = config['task_id']
        model_matrix_table['ass_id'] = config['ass_id']
        model_matrix_table['algorithm_name'] = model_name
        model_matrix_table['threshold'] = i
        # data_source_1 = '建模集'
        # data_source_2 = '测试集'
        # data_source_3 = '样本外验证集'
        model_matrix_table['data_list'] = config['datasource']
        model_matrix_table['tp'] = tp
        model_matrix_table['fp'] = fp
        model_matrix_table['tn'] = tn
        model_matrix_table['fn'] = fn
        model_matrix_table['tpr'] = tpr
        model_matrix_table['fpr'] = fpr
        model_matrix_table['f1_score'] = f1_score
        model_matrix_table['create_time'] = curr_datetime
        # engine = SuperVar.getVar('engine')
        # engine.DictUSql(datadict=model_matrix_table, table='model_ass_matrix')
        # bar()
        dictlist.append(model_matrix_table)
    engine = SuperVar.getVar('engine')
    engine.DictListSql(dictlist, table='model_ass_matrix')


@logger.catch
def insert_regress_model_lift(model, model_name, config, true_label, data_X):
    true_label = list(itertools.chain(*true_label))
    # logger.error(true_label)
    # 提升曲线
    # lift

    # 提示指数
    # 累积提示指数
    # 提示指数是指第m轮训练后，模型在加权数据集上的分类误差率。累积提示指数是指第m轮训练后，模型在原始数据集上的分类误差率
    # 提升占比
    # 累积提升占比
    #       # 与base相比 提升多少
    # 相应率
    # 累积相应率
    # 响应率是指第m轮训练后，模型对正例的预测概率2。累积响应率是指第m轮训练后，模型对所有样本的预测概率之和
    # danwei = config['RS']['n_iter'] / 10
    # with alive_bar(10,
    #                title="计算提升曲线",
    #                bar="filling",
    #                spinner="notes",
    #                force_tty=True
    #                ) as bar:
    model_pre_data = model.predict(data_X)
    df = pd.DataFrame({'true_label': true_label, 'pred_prob': model_pre_data})
    df = df.sort_values(by='pred_prob', ascending=False).reset_index(drop=True)
    df['rank'] = df.index + 1
    n = len(df)

    # 计算每个decile包含的样本数k，向上取整
    k = int(np.ceil(n / 10))
    # 设置一个阈值，大于等于该阈值的预测概率认为是响应者，小于该阈值的认为是非响应者
    threshold = 0.5

    # 用阈值对sub_df['pred_prob']进行二值化，得到一个布尔向量sub_df['pred_label']

    # 计算每个decile中模型预测为响应者的样本数predicted

    # 定义一个空列表deciles，用来存储每个decile的统计信息
    deciles = []

    model_ass_return_table = {}
    responderslist = []
    predictedlist = []
    response_rate_list = []
    total_list = []
    promote_list = []
    income_average_list = []
    for i in range(10):
        # 计算每个decile的起始位置和结束位置
        start = i * k
        end = min((i + 1) * k, n)
        # 提取每个decile对应的子数据框sub_df
        sub_df = df.iloc[start:end]
        sub_df['pred_label'] = sub_df['pred_prob'] >= threshold
        # 计算每个decile的响应者数、非响应者数、总数和响应率
        responders = sub_df['true_label'].mean()
        responderslist.append(responders)
        predicted = sub_df['pred_label'].mean()
        predictedlist.append(predicted)
        # non_responders = len(sub_df) - responders
        total = len(sub_df)
        total_list.append(total)
        # response_rate = responders[i] / total
        # response_rate_list.append(response_rate)
    dictlist = []
    for i in range(10):
        curr_datetime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        #  model_ass_lift

        model_ass_return_table['task_id'] = config['task_id']
        model_ass_return_table['ass_id'] = config['ass_id']
        model_ass_return_table['algorithm_name'] = model_name
        model_ass_return_table['data_list'] = config['datasource']
        model_ass_return_table['grade'] = i
        # U31/T31 / U41/T41 * 100
        model_ass_return_table['cue_index'] = (responderslist[i] / total_list[i]) / (
                np.sum(responderslist) / np.sum(total_list)) * 100
        # =Z31/Z$40*100
        # =SUM(U31:U32)/SUM(T31:T32)   /    =SUM(U31:U40)/SUM(T31:T40)
        # U  responders   T    total

        model_ass_return_table['cue_index_count'] = (np.sum(responderslist[0:i + 1]) / np.sum(total_list[0:i + 1])) / (
                np.sum(responderslist) / np.sum(total_list))*100

        # 提升占比有疑问
        # U31/U41

        promote = (responderslist[i] / np.sum(responderslist)) * 100
        promote_list.append(promote)
        logger.debug(promote_list)

        model_ass_return_table['income_rate'] = promote
        model_ass_return_table['income_rate_count'] = np.sum(promote_list)

        # U31 / T31
        model_ass_return_table['income_average'] = (responderslist[i] / total_list[i])
        # =SUM(U31: U40) / SUM(T31: T40)
        model_ass_return_table['income_average_count'] = (np.sum(responderslist[0:i + 1]) / np.sum(
            total_list[0:i + 1]))

        model_ass_return_table['create_time'] = curr_datetime
        # engine = SuperVar.getVar('engine')
        # engine.DictUSql(datadict=model_ass_return_table, table='model_ass_return')
        dictlist.append(model_ass_return_table)
    engine = SuperVar.getVar('engine')
    engine.DictListSql(dictlist, table='model_ass_return')

@logger.catch
def insert_model_lift(model, model_name, config, true_label, data_X):
    true_label = list(itertools.chain(*true_label))
    # logger.error(true_label)
    # 提升曲线
    # lift

    # 提示指数
    # 累积提示指数
    # 提示指数是指第m轮训练后，模型在加权数据集上的分类误差率。累积提示指数是指第m轮训练后，模型在原始数据集上的分类误差率
    # 提升占比
    # 累积提升占比
    #       # 与base相比 提升多少
    # 相应率
    # 累积相应率
    # 响应率是指第m轮训练后，模型对正例的预测概率2。累积响应率是指第m轮训练后，模型对所有样本的预测概率之和
    # danwei = config['RS']['n_iter'] / 10
    # with alive_bar(10,
    #                title="计算提升曲线",
    #                bar="filling",
    #                spinner="notes",
    #                force_tty=True
    #                ) as bar:
    model_pre_data = model.predict_proba(data_X)[:, 1]
    df = pd.DataFrame({'true_label': true_label, 'pred_prob': model_pre_data})
    df = df.sort_values(by='pred_prob', ascending=False).reset_index(drop=True)
    df['rank'] = df.index + 1
    n = len(df)

    # 计算每个decile包含的样本数k，向上取整
    k = int(np.ceil(n / 10))
    # 设置一个阈值，大于等于该阈值的预测概率认为是响应者，小于该阈值的认为是非响应者
    threshold = 0.5

    # 用阈值对sub_df['pred_prob']进行二值化，得到一个布尔向量sub_df['pred_label']

    # 计算每个decile中模型预测为响应者的样本数predicted

    # 定义一个空列表deciles，用来存储每个decile的统计信息
    deciles = []

    model_ass_lift_table = {}
    responderslist = []
    predictedlist = []
    response_rate_list = []
    total_list = []
    promote_list = []
    dictlist = []
    for i in range(10):
        # 计算每个decile的起始位置和结束位置
        start = i * k
        end = min((i + 1) * k, n)
        # 提取每个decile对应的子数据框sub_df
        sub_df = df.iloc[start:end]
        sub_df['pred_label'] = sub_df['pred_prob'] >= threshold
        # 计算每个decile的响应者数、非响应者数、总数和响应率
        responders = sub_df['true_label'].sum()
        responderslist.append(responders)
        predicted = sub_df['pred_label'].sum()
        predictedlist.append(predicted)
        # non_responders = len(sub_df) - responders
        total = len(sub_df)
        total_list.append(total)
        # response_rate = responders[i] / total
        # response_rate_list.append(response_rate)

    for i in range(10):
        curr_datetime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        #  model_ass_lift
        model_ass_lift_table = {}
        model_ass_lift_table['task_id'] = config['task_id']
        model_ass_lift_table['ass_id'] = config['ass_id']
        model_ass_lift_table['algorithm_name'] = model_name
        model_ass_lift_table['data_list'] = config['datasource']
        model_ass_lift_table['grade'] = i
        # U31/T31 / U41/T41 * 100
        model_ass_lift_table['cue_index'] = (responderslist[i] / total_list[i]) / (
                np.sum(responderslist) / np.sum(total_list)) * 100
        # =Z31/Z$40*100
        # =SUM(U31:U32)/SUM(T31:T32)   /    =SUM(U31:U40)/SUM(T31:T40)
        # U  responders   T    total
        model_ass_lift_table['cue_index_count'] = (np.sum(responderslist[0:i + 1]) / np.sum(total_list[0:i + 1])) / (
                np.sum(responderslist) / np.sum(total_list))*100

        logger.debug("=========================================")
        logger.debug((np.sum(responderslist[0:i + 1]) / np.sum(total_list[0:i + 1])) / (
                np.sum(responderslist) / np.sum(total_list))*100)
        logger.debug("=========================================")
        # 提升占比有疑问
        # U31/U41

        promote = (responderslist[i] / np.sum(responderslist)) * 100
        promote_list.append(promote)
        logger.debug(promote_list)

        model_ass_lift_table['promote'] = promote
        model_ass_lift_table['promote_count'] = np.sum(promote_list)

        # U31 / T31
        model_ass_lift_table['response_rate'] = (responderslist[i] / total_list[i]) * 100
        # =SUM(U31: U40) / SUM(T31: T40)
        model_ass_lift_table['response_rate_count'] = (np.sum(responderslist[0:i + 1]) / np.sum(
            total_list[0:i + 1])) * 100

        model_ass_lift_table['create_time'] = curr_datetime
        # engine = SuperVar.getVar('engine')
        # engine.DictUSql(datadict=model_ass_lift_table, table='model_ass_lift')
        dictlist.append(model_ass_lift_table)
    # print(dictlist)
    engine = SuperVar.getVar('engine')
    engine.DictListSql(dictlist, table='model_ass_lift')


@logger.catch
def insert_model_ass_normality(predictions, true_label, pre_label, model_name, config):
    # with alive_bar(100,
    #                title="计算混淆矩阵图4",
    #                bar="filling",
    #                spinner="notes",
    #                force_tty=True
    #                ) as bar:
    arr = np.array(predictions)
    pre_label = arr.round(2)
    res = {}
    dictlist = []
    # 遍历列表a中的每个值
    for i in range(len(pre_label)):
        # 如果值已经在字典中，就更新对应的0和1的数量
        if pre_label[i][0] in res:
            res[pre_label[i][0]][true_label[i][0]] += 1
        # 如果值不在字典中，就创建一个新的键值对，初始值为[0, 0]
        else:
            res[pre_label[i][0]] = [0, 0]
            res[pre_label[i][0]][true_label[i][0]] += 1

    items = list(res.items())
    for key, value in items:
        curr_datetime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        model_ass_normality_table = {}
        # model_ass_normality_table['id'] = None
        model_ass_normality_table['task_id'] = config['task_id']
        model_ass_normality_table['ass_id'] = config['ass_id']
        model_ass_normality_table['algorithm_name'] = model_name
        model_ass_normality_table['data_list'] = config['datasource']
        model_ass_normality_table['estimate'] = key
        model_ass_normality_table['case_point'] = value[0]
        model_ass_normality_table['negative_examples'] = value[1]
        model_ass_normality_table['create_date'] = curr_datetime
        # engine = SuperVar.getVar('engine')
        # engine.DictUSql(datadict=model_ass_normality_table, table='model_ass_normality')
        # bar()
        dictlist.append(model_ass_normality_table)
    engine = SuperVar.getVar('engine')
    engine.DictListSql(dictlist, table='model_ass_normality')


@logger.catch
def insert_model_ass_parameter(params, model_name, config):
    param = params.items()
    loadconfig = loadConfig.loadConfig()
    # 读取本地 yaml文件 Modelfeature.yml
    # feature_config_path = get_config_path(SuperVar.getVar('model_feature'))
    feature = SuperVar.getVar('model_feature')



    # with alive_bar(len(params),
    #                title="计算模型参数",
    #                bar="filling",
    #                spinner="notes",
    #                force_tty=True
    #                ) as bar:
    dictlist = []
    for k, v in param:
        curr_datetime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        model_para_table = {}
        # model_para_table['id'] = None
        model_para_table['task_id'] = config['task_id']
        model_para_table['ass_id'] = config['ass_id']
        model_para_table['algorithm_name'] = model_name
        model_para_table['parameter_name'] = k
        model_para_table['parameter_describe'] = feature[k] if k in feature else '暂无解释'
        model_para_table['parameter_number'] = v
        model_para_table['create_date'] = curr_datetime
        # engine = SuperVar.getVar('engine')
        # engine.DictUSql(datadict=model_para_table, table='model_ass_parameter')
        # bar()
        dictlist.append(model_para_table)
    engine = SuperVar.getVar('engine')
    engine.DictListSql(dictlist, table='model_ass_parameter')


@logger.catch
def insert_model_ass_feature(model, model_name, config, feature_names):
    try:
        importances = model.feature_importances_
    except Exception as e:
        logger.debug('特征不存在')
        logger.info(e)
        return
    dictlist = []
    for i in range(len(feature_names)):
        curr_datetime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        model_importance_table = {}
        # model_importance_table['id'] = None
        model_importance_table['ass_id'] = config['ass_id']
        model_importance_table['task_id'] = config['task_id']
        model_importance_table['algorithm_name'] = model_name
        model_importance_table['features_name'] = feature_names[i]
        decimal.getcontext().prec = 20
        tmp_x = decimal.Decimal(importances[i])
        tmp_y = tmp_x.quantize(decimal.Decimal('0.0001'))
        model_importance_table['Important_index'] = tmp_y
        model_importance_table['create_time'] = curr_datetime
        # engine = SuperVar.getVar('engine')
        # engine.DictUSql(datadict=model_importance_table, table='model_ass_feature')
        dictlist.append(model_importance_table)
    engine = SuperVar.getVar('engine')
    engine.DictListSql(dictlist, table='model_ass_feature')
