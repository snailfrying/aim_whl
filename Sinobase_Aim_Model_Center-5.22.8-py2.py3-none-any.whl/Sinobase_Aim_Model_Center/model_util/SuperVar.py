# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :SuperVar.py

@Time      :2023/5/31 11:11

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

all_things = {}
engine = None
config = None
dataX = None
dataY = None
title = None
X_test = None
y_test = None


def setVar(name, value):
    global all_things
    all_things[name] = value


def getVar(name):
    global all_things
    return all_things[name]


def set_dataX(str):
    global dataX
    dataX = str


def get_dataX():
    global dataX
    return dataX


def set_dataY(str):
    global dataY
    dataY = str


def get_dataY():
    global dataY
    return dataY


def set_title(str):
    global title
    title = str


def get_title():
    global title
    return title


def set_X_test(str):
    global X_test
    X_test = str


def get_X_test():
    global X_test
    return X_test


def set_y_test(str):
    global y_test
    y_test = str


def get_y_test():
    global y_test
    return y_test


def set_engine(str):
    global engine
    engine = str


def get_engine():
    global engine
    return engine


def set_config(str):
    global config
    config = str


def get_config():
    global config
    return config
