# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :paths.py.py

@Time      :2023/11/01 13:32

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
"""Paths that are useful throughout the project."""
from pathlib import Path


def get_project_root() -> Path:
    """Returns the path to the project root folder.

    Returns:
        The path to the project root folder.
    """
    return Path(__file__).parent.parent.parent.parent


def get_alg_root(path: str) -> Path:
    """Returns the path to the project root folder.

    Returns:
        The path to the project root folder.
    """
    return Path(__file__).parent.parent / 'alg_model' / path


def get_config_path(file_name: str) -> Path:
    """Returns the path a config file.

    Returns:
        The path to a config file.
    """
    return Path(__file__).parent.parent / file_name


def get_data_path() -> Path:
    """Returns the path to the dataset cache ([root] / data)

    Returns:
        The path to the dataset cache
    """
    return get_project_root() / "data"
