# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :loadConfig.py

@Time      :2023/5/18 10:29

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''
import yaml
from loguru import logger


class loadConfig:
    def __init__(self,
                 config_file: str = None,
                 ):
        pass
    #     读取配置文件
    def read(self,config_file):
        # ("读取配置文件")
        with open(config_file, 'r', encoding='utf-8') as f:
            result = yaml.load(f.read(), Loader=yaml.FullLoader)
        return result

    #     保存配置文件
    def save(self):
        logger.info("执行保存")

    def readsqlconnect(self):
        # ("读取配置文件")
        with open('sqlconnect.yml', 'r', encoding='utf-8') as f:
            result = yaml.load(f.read(), Loader=yaml.FullLoader)
        return result

    def readfeature(self):
        # ("读取配置文件")
        with open('Modelfeature.yml', 'r', encoding='utf-8') as f:
            result = yaml.load(f.read(), Loader=yaml.FullLoader)
        return result
    def get_config(self,config_file):
        # ("读取配置文件")
        with open(config_file, 'r', encoding='utf-8') as f:
            result = yaml.load(f.read(), Loader=yaml.FullLoader)
        return result