# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :exprotConfig.py

@Time      :2023/11/02 09:48

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
import os
import shutil
from pathlib import Path
from Sinobase_Aim_Model_Center.model_util import SuperVar, logConfig


def export_config(path):
    # task_id = SuperVar.getVar("task_id")
    # 生成日志
    log_config = SuperVar.getVar('log_config')
    logger = logConfig.Createlogging(log_config['LogConfig'], 'Use', 'exportConfig')
    logger.info("")
    logger.info("============================日志开始记录=================================")
    SuperVar.setVar("logger", logger)
    # 源文件夹路径
    src_dir = Path(__file__).parent.parent / 'resource' / 'expand'
    # 目标文件夹路径
    dst_dir = path
    # 遍历源文件夹中的所有文件
    for filename in os.listdir(src_dir):
        # 构建源文件路径和目标文件路径
        src_file_path = os.path.join(src_dir, filename)
        dst_file_path = os.path.join(dst_dir, filename)
        # 复制文件到目标文件夹
        shutil.copy(src_file_path, dst_file_path)
    SuperVar.getVar('logger').info(f'配置文件导出成功，路径为{path}')
