# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :push.py

@Time      :2023/11/02 09:48

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
import time
import joblib
import numpy as np
import pandas as pd
from Sinobase_Aim_Model_Center.model_util import HttpRequest
from Sinobase_Aim_Model_Center.model_util import SuperVar, logConfig
from Sinobase_Aim_Model_Center.model_util.Rt_Alarm import create_rt_alarm


def push():
    task_id = SuperVar.getVar("task_id")
    # 生成日志
    log_config = SuperVar.getVar('log_config')
    logger = logConfig.Createlogging(log_config['LogConfig'], task_id, 'push')
    logger.info("")
    logger.info("============================日志开始记录=================================")
    SuperVar.setVar("logger", logger)
    open_alarm = SuperVar.getVar("open_alarm")
    logger = SuperVar.getVar("logger")
    filetype = SuperVar.getVar("filetype")
    model_config = SuperVar.getVar("model_config")
    source_engine = SuperVar.getVar("source_engine")
    location = SuperVar.getVar("location")
    tenant = SuperVar.getVar("tenant")
    engine = SuperVar.getVar("engine")
    primary = SuperVar.getVar("primary")
    predict_id = SuperVar.getVar("predict_id")
    alarm_config = SuperVar.getVar("alarm_config")

    if open_alarm:
        logger.info("实时预警开启")
        #     获取token
        token = HttpRequest.gettoken(alarm_config['alarm']['url'], alarm_config['alarm']['clientId'],
                                     alarm_config['alarm']['clientSecret'])
        model_config['token'] = token
        SuperVar.setVar("token", token)
        logger.debug("token获取成功")
        logger.debug(token)
    else:
        logger.info("实时预警关闭")

    # 获取创建者
    creator = engine.execute(
        sql="""select user_id from model_instance where id = '%s'""" % task_id).values.tolist()[
        0][0]
    # 获取训练名称
    task_name = engine.execute(
        sql="""select name from model_instance where id='%s'""" % task_id).values.tolist()[
        0][0]
    # 获取数据
    table_name = location
    schema_name = tenant
    sourcedata = source_engine.execute(sql="""select * from %s.%s""" % (schema_name, table_name))

    feature = engine.execute(
        sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % task_id)
    params = engine.execute(sql="""select * from model_instance where id = '%s'""" % task_id)

    dataXvar = feature.loc[feature['feature_type'] == '字符型变量']

    for i, j in zip(dataXvar['feature_name'], dataXvar['id']):
        sourcedata[i] = pd.get_dummies(sourcedata[i]).astype(int).apply(lambda x: ''.join(x.astype(str)), axis=1)
        # 进入特征处理
    params = engine.execute(sql="""select * from model_instance where id = '%s'""" % task_id)
    # OneHot编码，
    var_onehot = params['var_onehot']
    dataXvar = feature.loc[feature['feature_type'] == '字符型变量']
    for i in dataXvar['feature_name']:
        if int(var_onehot):
            sourcedata[i] = pd.get_dummies(sourcedata[i]).astype(int).apply(lambda x: ''.join(x.astype(str)),
                                                                            axis=1)

    dataXint = feature.loc[feature['feature_type'] == '数值型变量']
    # 缺失值填充方法
    num_fill = params['num_fill']
    # 是否使用数据交换
    num_swap = params['num_exchange']
    for i in dataXint['feature_name']:
        # 均值填充
        if int(num_fill) == 1:
            sourcedata[i].fillna(sourcedata[i].mean(), inplace=True)
        #     大
        if int(num_fill) == 2:
            sourcedata[i].fillna(sourcedata[i].max(), inplace=True)
        #     小
        if int(num_fill) == 3:
            sourcedata[i].fillna(sourcedata[i].min(), inplace=True)
        #     0
        if int(num_fill) == 4:
            sourcedata[i].fillna(0, inplace=True)
        # 数值变换
        if int(num_swap):
            sourcedata[i + '_stand'] = sourcedata[i].apply(
                lambda x: (x - np.mean(sourcedata[i])) / np.std(sourcedata[i]))
            sourcedata[i + '_normal'] = sourcedata[i].apply(
                lambda x: (x - np.min(sourcedata[i])) / (np.max(sourcedata[i]) - np.min(sourcedata[i])))
            sourcedata[i + '_log'] = sourcedata[i].apply(lambda x: 0 if x <= 0 else np.log(x))
            # sourcedata[i + '_sqrt'] = sourcedata[i].apply(lambda x: np.sqrt(x))

    # dataXname = feature.loc[feature['feature_type'].isin(['字符型变量', '数值型变量'])]
    # dataX = sourcedata[dataXname['feature_name']]
    dataXnotname = feature.loc[feature['feature_type'].isin(['目标变量', 'ID', '排除'])]
    dataX = sourcedata.drop(dataXnotname['feature_name'], axis=1)
    #
    # dataXname = feature.loc[feature['feature_type'].isin(['字符型变量', '数值型变量'])]
    # dataX = sourcedata[dataXname['feature_name']]

    #
    use_ass_id = engine.execute(sql="""select ass_id from model_assessment where task_id = '%s' and `use`=1 """ % (
        task_id))
    the_use_ass_id = use_ass_id.values.tolist()[0][0]
    # 获取模型路径
    model_path = engine.execute(sql="""select model_path from model_map where task_id = '%s' and ass_id='%s' """ % (
        task_id, the_use_ass_id))

    model_path = model_path.values.tolist()[0][0]

    logger.debug(model_path)
    try:
        model = joblib.load(model_path)
    except Exception as e:
        logger.error("模型丢失！")
        logger.error(e)
    dataX = dataX.sort_index(axis=1, ascending=False)
    y_pre_proba = model.predict_proba(dataX)
    y_pre_proba = y_pre_proba[:, -1]
    # 把一维数组y_pre_proba缩放到0-100中
    score = (y_pre_proba - np.min(y_pre_proba)) / (np.max(y_pre_proba) - np.min(y_pre_proba)) * 100
    # 把id加上
    IDname = feature.loc[feature['feature_type'].isin(['ID'])]
    ID = sourcedata[IDname['feature_name']]
    ID.columns = ['id']
    dataX = pd.concat([ID, dataX], axis=1)
    # logger.info(dataX.shape)
    # 把score放回数据集中
    # logger.info(len(score))
    dataX = dataX.assign(score=score)
    dataX = dataX.sort_values(by='score').reset_index(drop=True)
    move_colunm = \
        engine.execute(sql="""select model_name from model_instance where id = '%s'""" % task_id).values.tolist()[
            0][0]
    # 去掉字符串move_colunm后两个字符
    move_colunm = move_colunm[:-2]
    dataX['group_auto'] = pd.cut(dataX.score, [-1, 15, 40, 65, 85, 100],
                                 labels=['超低' + move_colunm, '低' + move_colunm, '一般' + move_colunm,
                                         '高' + move_colunm, '超高' + move_colunm])

    dataX['order_by'] = pd.cut(dataX.score, [-1, 15, 40, 65, 85, 100],
                               labels=['5', '4', '3', '2', '1'])
    dataX['row_id'] = dataX.index

    result = dataX[['id', 'score', 'group_auto', 'order_by', 'row_id']]

    result.insert(loc=0, column=primary, value=dataX['id'])

    result.insert(loc=1, column='predict_id', value=predict_id)
    try:
        a = result.to_sql('model_predict_select_model_data_' + predict_id, source_engine.connect(pgsql=True),
                          index=False,
                          if_exists='replace',
                          schema=tenant)
        logger.info("总推送数据：" + str(a))
        engine.execute(sql="""update model_predict_result set status = 1 where  predict_id = '%s'""" % predict_id)
        logger.info("推送完成")
        if open_alarm:
            content = {"title": task_name,
                       'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
            user = {"creator": creator}
            HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                    create_rt_alarm('model_application_05', content, user))
    except Exception as e:
        logger.error("推送失败")
        if open_alarm:
            content = {"title": task_name,
                       'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
            user = {"creator": creator}
            HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                    create_rt_alarm('model_application_04', content, user))
        logger.error(e)
        engine.execute(sql="""update model_predict_result set status = 0 where  predict_id = '%s'""" % predict_id)