# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :default.py

@Time      :2023/11/09 13:40

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
from Sinobase_Aim_Model_Center.Script_Constructor import num_feature, var_feature, all_feature, col_feature
from pandas import DataFrame
import numpy as np
from Sinobase_Aim_Model_Center.model_util import SuperVar


@var_feature
def var_group(data: DataFrame = None):
    if int(SuperVar.getVar('var_group')):
        logger = SuperVar.getVar('logger')
        dataID = SuperVar.getVar('dataID')
        for i in data.columns.tolist():
            if i != dataID and i != "thisID":
                logger.info("%s变量值分组" % i)
                li = data[i].values.tolist()
                li = list(set(li))
                replace_dict = {}
                for m in range(len(li)):
                    replace_dict[li[m]] = m
                data[i] = data[i].replace(replace_dict)
    return data


@num_feature
def Numerical_filling_max(data: DataFrame = None):
    if int(SuperVar.getVar('num_fill')) == 2:
        logger = SuperVar.getVar('logger')
        dataID = SuperVar.getVar('dataID')
        for i in data.columns.tolist():
            if i != dataID and i != "thisID":
                logger.debug("%s 最大值填充" % i)
                logger.info("%s 最大值填充" % i)
                data[i].fillna(data[i].max(), inplace=True)
    return data


@num_feature
def Numerical_filling_min(data: DataFrame = None):
    if int(SuperVar.getVar('num_fill')) == 3:
        logger = SuperVar.getVar('logger')
        dataID = SuperVar.getVar('dataID')
        for i in data.columns.tolist():
            if i != dataID and i != "thisID":
                logger.debug("%s 最小值填充" % i)
                logger.info("%s 最小值填充" % i)
                data[i].fillna(data[i].min(), inplace=True)
    return data


@num_feature
def Numerical_filling_mean(data: DataFrame = None):
    if int(SuperVar.getVar('num_fill')) == 1:
        logger = SuperVar.getVar('logger')
        dataID = SuperVar.getVar('dataID')
        for i in data.columns.tolist():
            if i != dataID and i != "thisID":
                logger.debug("%s 均值填充" % i)
                logger.info("%s 均值填充" % i)
                data[i].fillna(data[i].mean(), inplace=True)
    return data


@num_feature
def Numerical_filling_zero(data: DataFrame = None):
    if int(SuperVar.getVar('num_fill')) == 4:
        logger = SuperVar.getVar('logger')
        dataID = SuperVar.getVar('dataID')
        for i in data.columns.tolist():
            if i != dataID and i != "thisID":
                logger.debug("%s 0值填充" % i)
                logger.info("%s 0值填充" % i)
                data[i].fillna(0, inplace=True)
    return data


@num_feature
def Numerical_switch(data: DataFrame = None):
    if int(SuperVar.getVar('num_swap')):
        logger = SuperVar.getVar('logger')
        dataID = SuperVar.getVar('dataID')
        for i in data.columns.tolist():
            if i != dataID and i != "thisID":
                logger.debug("%s 变换" % i)
                logger.info("%s 变换" % i)
                # data[i + '_stand'] = data[i].apply(
                #     lambda x: (x - np.mean(data[i])) / np.std(data[i]))
                data[i + '_normal'] = data[i].apply(
                    lambda x: (x - np.min(data[i])) / (np.max(data[i]) - np.min(data[i])))
                data[i + '_log'] = data[i].apply(lambda x: 0 if x <= 0 else np.log(x))  # 如果log计算出错 则为0
    return data


def start():
    var_group()
    Numerical_filling_max()
    Numerical_filling_min()
    Numerical_filling_mean()
    Numerical_filling_zero()
    Numerical_switch()
