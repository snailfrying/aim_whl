#!/usr/bin/env python3
# -*- coding: utf-8 _*_

"""
    @Author: json
    @Time: 2023/5/10 18:16
    @Describe mysql功能函数封装
    @Version 1.0
"""

import pymysql
from pymysql.cursors import DictCursor
from pymysql.err import OperationalError
from sqlalchemy import create_engine
from sqlalchemy.pool import NullPool

class MySQLHelper:
    def __init__(self, host, port, username, password, db_name, charset='utf8mb4'):
        self.host = host
        self.port = port
        self.user = username
        self.password = password
        self.db_name = db_name
        self.charset = charset
        # 创建 SQLAlchemy 引擎
        self.engine = create_engine(f'mysql+pymysql://{username}:{password}@{host}:{port}/{db_name}', poolclass=NullPool)

    def connect(self):
        try:
            conn = pymysql.connect(host=self.host,
                                   port=self.port,
                                   user=self.user,
                                   password=self.password,
                                   db=self.db_name,
                                   charset=self.charset,
                                   cursorclass=DictCursor)
            return conn
        except OperationalError as e:
            print("Error:", e)
            return None

    def close(self, conn, cursor):
        cursor.close()
        conn.close()

    def query(self, sql):
        conn = self.connect()
        if conn:
            try:
                with conn.cursor() as cursor:
                    cursor.execute(sql)
                    results = cursor.fetchall()
                    return results
            except Exception as e:
                print("Error:", e)
            finally:
                self.close(conn, cursor)
        return None

    def insert(self, sql):
        conn = self.connect()
        if conn:
            try:
                with conn.cursor() as cursor:
                    cursor.execute(sql)
                conn.commit()
            except Exception as e:
                print("Error:", e)
                conn.rollback()
            finally:
                self.close(conn, cursor)

    def update(self, sql):
        conn = self.connect()
        if conn:
            try:
                with conn.cursor() as cursor:
                    cursor.execute(sql)
                conn.commit()
            except Exception as e:
                print("Error:", e)
                conn.rollback()
            finally:
                self.close(conn, cursor)

    def delete(self, sql):
        conn = self.connect()
        if conn:
            try:
                with conn.cursor() as cursor:
                    cursor.execute(sql)
                conn.commit()
            except Exception as e:
                print("Error:", e)
                conn.rollback()
            finally:
                self.close(conn, cursor)

# Example usage:
# if __name__ == '__main__':
#     helper = MySQLHelper(
#         host='10.88.10.22',
#         port=3306,
#         username='root',
#         password='sinobase@123',
#         db_name='mip_aim_model',
#         charset='utf8mb4'
#     )
#     results = helper.query("SELECT * FROM model_ass_normality")
#     if results:
#         print("results:", results)
#     print("over")
