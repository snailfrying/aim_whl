#!/usr/bin/env python3
# -*- coding: utf-8 _*_

"""
    @Author: json
    @Time: 2023/10/27 14:20
    @Describe
    @Version 1.0
"""
import logging

from Sinobase_Aim_Model_Center.model_util import SuperVar
from Sinobase_Aim_Model_Center.rfm.utils import mysqlHelper
from Sinobase_Aim_Model_Center.rfm.utils import HttpRequest
from Sinobase_Aim_Model_Center.rfm.utils import customLogger
from Sinobase_Aim_Model_Center.rfm.utils import postgreHelper

import sys
import math
import yaml
import traceback
import argparse
import pandas as pd

pd.set_option('display.max_rows', 100)
# 设置最大显示列数为 10
pd.set_option('display.max_columns', 100)
day_dict = {1: 91, 2: 181, 3: 366, 4: 731}

# 默认的标签名称
rfm_default_label = {'222': '重要价值用户', '202': '重要发展用户', '022': '重要保持用户', '002': '重要挽留用户',
                     '220': '一般价值用户',
                     '200': '一般发展用户', '020': '一般保持用户', '000': '一般挽留用户'}

# 翻译字典
translation_dict = {
    '重要价值用户': 'Important_Value_User',
    '重要发展用户': 'Importan_Growth_User',
    '重要保持用户': 'Importan_Retention_User',
    '重要挽留用户': 'Important_Retain_User',
    '一般价值用户': 'General_Value_User',
    '一般发展用户': 'General_Growth_User',
    '一般保持用户': 'General_Retention_User',
    '一般挽留用户': 'General_Retain_User'
}

# 生成新的字典
new_dict = {value: translation_dict[value] for value in rfm_default_label.values()}

# 输出新字典
print(new_dict)



def read_log():
    log_config = SuperVar.getVar('log_config')
    logger = customLogger.CustomLogger(log_config, __name__, "processing")
    # 修改Loguru的record属性，使其显示正确的函数和列名
    custom_logger = logger.logger
    custom_logger.info("********开始执行rfm模型，并输出运行日志*******")
    return custom_logger

def detect_file_type(file_path):
    import os
    _, extension = os.path.splitext(file_path)
    if extension == '.csv':
        return 'csv'
    elif extension in ['.xls', '.xlsx', '.xlsm']:
        return 'excel'
    else:
        return 'unknown'

def read_data(pgdb, flag, data_location):
    """
    根据传参读取数据
    :param flag: 2：文件 否读数据库表
    :param data_location: 文件名|表名
    :return:
    """
    # data_location = r"E:\sinobaseAim\models\rfm\data\RFM订单数据大金额.csv"
    print('data_loction ' + str(data_location))
    if str(flag) == "2":
        if detect_file_type(data_location) == 'csv':
            try:
                data = pd.read_csv(data_location, encoding='utf-8')
            except Exception:
                data = pd.read_csv(data_location, encoding='gbk')
            finally:
                print("只支持utf-8和gbk编码文件！")
        else:
            try:
                data = pd.read_excel(data_location)
            except Exception:
                data = pd.read_excel(data_location, engine='openpyxl')
            finally:
                print("只支持utf-8和gbk编码文件！")
    else:
        query = f"SELECT * FROM {data_location};"
        columns, result = pgdb.query(query)
        data = pd.DataFrame(result, columns=columns)
    data.columns = ['userid', 'datetime', 'amount']
    data["userid"] = data['userid'].rank(method='dense')
    # 转换datetime列为日期格式
    data['datetime'].dropna(inplace=True)
    data['datetime'] = pd.to_datetime(data['datetime'])
    return data


def rfm_split_point(v, type, rfm_max_point_dict):
    v = v[type]
    if 'point' in rfm_max_point_dict or type + '_point' in rfm_max_point_dict:
        return str(0 if v < rfm_max_point_dict[type] else 2)
    else:
        a, b = rfm_max_point_dict[type]
        return str(0 if v <= a else (2 if v > b else 1))


def r_switch(r_s):
    r_r = int(r_s)
    cycle_ranges = {
        1: {10: 'R≤10', 30: '10<R≤30', 60: '30<R≤60', 80: '60<R≤80'},
        2: {30: 'R≤30', 60: '30<R≤60', 100: '60<R≤100', 160: '100<R≤160'},
        3: {30: 'R≤30', 90: '30<R≤90', 180: '90<R≤180', 340: '180<R≤340'},
        4: {90: 'R≤90', 180: '90<R≤180', 360: '180<R≤360', 680: '360<R≤680'}
    }

    if data_cycle in cycle_ranges:
        for threshold, label in cycle_ranges[data_cycle].items():
            if r_r <= threshold:
                return label
        return 'R>' + str(list(cycle_ranges[data_cycle].keys())[-1])
    else:
        return '未知数据周期'


def f_group(f_max):
    split_f = math.floor(f_max / 5)
    split_f_1 = split_f
    split_f_2 = split_f * 2
    split_f_3 = split_f * 3
    split_f_4 = split_f * 4
    split_labels = [0, split_f_1, split_f_2, split_f_3, split_f_4, f_max]
    return split_labels


def f_switch(fvv, f_max):
    fv = fvv['frequency']
    if f_max > 10:
        split_labels = f_group(f_max)
        for i in range(len(split_labels) - 1):
            if fv <= split_labels[i]:
                return str(split_labels[i - 1]) + '<F≤' + str(split_labels[i])
    else:
        switch_dict = {1: 'F=1', 2: 'F=2', 3: 'F=3', 4: 'F=4', 5: 'F≥5'}
        return switch_dict.get(fv) if fv <= 4 else switch_dict.get(5)


def read_rmf_model_pparameter(mysqlHp):
    """
    读取用户分析rfm报表后，分的组别或默认组别
    :param mysqlHp:
    :return:
    """
    param_sql = "select level_num,dimension,first_separator,second_separator from model_rfm_param where deleted = 0 and instance_id = '%s'" % task_id
    result = mysqlHp.query(param_sql)
    # 默认取值范围为前一年的数据
    type = 3
    global data_cycle
    data_cycle = 3
    rfm_max_point_dict = {}
    if not result:
        # 默认分组
        max_sql = "select cycle,recency,frequency,monetary from model_rfm_max_value where cycle = 3 and instance_id = '%s'" % task_id
        rfm_max_dict = mysqlHp.query(max_sql)
        print(rfm_max_dict)
        # 默认分割点的值
        if rfm_max_dict:
            rfm_max_point_dict = rfm_max_dict[0]
            # 点数默认为2点
            rfm_max_point_dict["point"] = 2
            print(rfm_max_point_dict)
        else:
            print("model_rfm_max_value table, No results found.")

    else:
        # 用户根据rfm报表，自己划分的组
        cycle_sql = "select cycle, push_cycle from model_rfm_query where deleted = 0 and instance_id = '%s'" % task_id
        cycle_result = mysqlHp.query(cycle_sql)
        print("cycle_result", cycle_result)
        rfm_max_point_dict = {}
        data_cycle = cycle_result[0]['push_cycle']
        rfm_max_point_dict['cycle'] = cycle_result[0]['cycle']
        rfm_name = ['recency', 'frequency', 'monetary']
        for i, v in enumerate(result):
            split_point = result[i]['level_num']
            rfm_max_point_dict[rfm_name[i] + '_point'] = split_point
            if split_point == 2:
                rfm_max_point_dict[rfm_name[i]] = v['first_separator']
            else:
                rfm_max_point_dict[rfm_name[i]] = [v['first_separator'], v['second_separator']]
    # 读取标签字典
    task = 'default'
    group_sql = "select group_code, group_name from model_rfm_group where deleted = 0 and instance_id = '%s'" % task
    group_result = mysqlHp.execute(group_sql)
    print('group_result', group_result)

    group_result_dcit = {d['group_code']: d['group_name'] for i, d in group_result.iterrows()}
    # 读取model feature
    sql = "select feature_name, feature_type from model_feature where task_id = '%s' and deleted= 0" % task_id
    f_result = mysqlHp.execute(sql)
    print('f_result', f_result)
    feature_dict = {d['feature_type']: d['feature_name'] for i, d in f_result.iterrows()}
    u_user_id = feature_dict['ID']
    u_datetime = feature_dict['行为时间']
    u_amount = feature_dict['消费金额']

    return rfm_max_point_dict, data_cycle, group_result_dcit


def rfm_predict(pgdb, mysqlHp, data, rfm_max_point_dict, data_cycle, group_result_dcit, predict_id, tenant_api):
    """
    开始预测，划分组别，并保存结果
    :param data:
    :param rfm_max_point_dict:
    :param data_cycle:
    :param group_result_dcit:
    :param predict_id:
    :param tenant_api:
    :return:
    """
    schema_name = tenant_api
    table_name = 'model_predict_select_model_data_' + str(predict_id)
    res_sql = f"DELETE FROM {table_name} WHERE instance_id = '{task_id}'"
    pgdb.execute_pg(res_sql)
    datetime_max = data['datetime'].max()
    # 根据周期，分析不同阶段数据
    date_gap = day_dict.get(data_cycle, 0)
    days_d_ago = data[data['datetime'] >= datetime_max - pd.DateOffset(days=date_gap)]
    # 按照r_time列降序排序
    days_d_ago = days_d_ago.sort_values('datetime', ascending=False)
    # 根据ID_var列删除重复行
    distinct_data = days_d_ago.drop_duplicates(subset=['userid'])
    # 计算RFM指标
    rfm_df = distinct_data.groupby('userid').agg(
        recency=('datetime', lambda x: (datetime_max - x.max()).days),
        frequency=('datetime', 'count'),
        monetary=('amount', 'sum')
    ).reset_index()
    # 根据RFM打标签
    for ty in ['recency', 'frequency', 'monetary']:
        rfm_df[ty + '_label'] = rfm_df.apply(lambda x: rfm_split_point(x, ty, rfm_max_point_dict), axis=1)
    rfm_df['RFM_label'] = rfm_df['recency_label'] + rfm_df['frequency_label'] + rfm_df['monetary_label']
    rfm_df['rfm_label_name'] = rfm_df['RFM_label'].map(group_result_dcit)
    # 中文翻译为英文
    rfm_df['rfm_label_name'] = rfm_df['rfm_label_name'].map(translation_dict)

    rfm_df['r_switch'] = rfm_df['recency'].apply(r_switch)
    f_max = rfm_df['frequency'].max()
    rfm_df['f_switch'] = rfm_df.apply(lambda x: f_switch(x, f_max), axis=1)
    result = rfm_df[['userid', 'recency', 'frequency', 'monetary', 'rfm_label_name', 'r_switch', 'f_switch']]
    result['instance_id'] = task_id
    print(result)
    # result.to_sql(table_name, con=pgdb, if_exists='replace', index=False, schema=schema_name)

    pgdb.insert_dataframe_to_pg(df=result, table_name=table_name, tenant=schema_name)
    result = result[['userid', 'recency', 'frequency', 'monetary', 'rfm_label_name']]
    # 保存到服务器路径
    task_replace_id = task_id.replace("-", "_")
    predict_path = str(task_replace_id) + "_" + str(predict_id) + '.csv'
    main_path = SuperVar.getVar("output_table_path")
    ppath = main_path + predict_path
    print(f"保存路径{ppath}")
    result.to_csv(ppath, encoding='utf-8', index=None)
    sql = "update model_pre_lib set predict_file_path =  '%s' where instance_id = '%s'" % (ppath, task_id)
    mysqlHp.execute(sql)

def select_name_and_creator(mysqldb, task_id):
    """
    读取任务创建者和名称
    :param mysqldb:
    :param task_id:
    :return:
    """
    sql = "select user_id, name from model_instance where id = '%s'" % task_id
    results = mysqldb.query(sql)
    user_id, name = '001', '001'
    # 解析结果
    if results:
        for row in results:
            user_id = str(row['user_id'])
            name = str(row['name'])
            print(f"user_id: {user_id}, name: {name}")
    return user_id, name


def parse_arguments():
    """
    后台传参
    :return:
    """
    parser = argparse.ArgumentParser(description='Script description')
    parser.add_argument('-t', '--task_id', type=str, required=True, help='Task ID')
    parser.add_argument('-ten', '--tenant_api', type=str, required=True, help='Tenant API')
    parser.add_argument('-f', '--flag', type=str, required=True, choices=["1", "2"],
                        help='Flag, 1: 建模数据集，2:上传文件数据集')
    parser.add_argument('-l', '--data_location', type=str, required=True, help='根据flag，对应表名或路径')
    parser.add_argument('-te', '--tenant_api', default='t100059', type=str, required=True, help='api名称')
    parser.add_argument('-p', '--predict', type=str, required=True, help='预测标识')
    return parser.parse_args()


def rfm_predict_main(pgdb, mysqlHp, flag, data_location, predict_id, user_id, name):
    """
    执行rfm预测脚本主程序
    :return:
    """
    try:
        # user_id, name = select_name_and_creator(mysqlHp, task_id)
        print(user_id, name)
        HttpRequest.post_messeage(user_id, task_id, f'AI模型中心【{name}】任务，预测开始！',
                                  name, flag=2)
        rfm_max_point_dict, data_cycle, group_result_dcit = read_rmf_model_pparameter(mysqlHp)
        # 读取数据
        data = read_data(pgdb, flag, data_location)
        # rfm 模型预测
        rfm_predict(pgdb, mysqlHp, data, rfm_max_point_dict, data_cycle, group_result_dcit, predict_id, tenant_api)
        mysqlHp.execute(sql="""update model_predict_result set status = 1 where  predict_id = '%s'""" % predict_id)
        mysqlHp.execute(sql="""UPDATE model_pre_lib set `status` = 1 where pre_id='%s'""" % predict_id)
        HttpRequest.post_messeage(user_id, task_id, f'AI模型中心【{name}】任务，预测完成！',
                                  name, flag=2)
    except Exception as E:
        traceback_info = traceback.format_exc()
        print(traceback_info)
        HttpRequest.post_messeage(user_id, task_id, f'AI模型中心【{name}】任务，预测报错！',
                                  name, flag=2)


def read_database():
    # 从YAML配置文件中加载数据库连接参数
    # with open('utils/db_config.yaml', 'r') as stream:
    #     config = yaml.safe_load(stream)
    # mysql_config = config[ 'mysql' ]
    # pg_config = config[ 'postgresql' ]
    # db_config = SuperVar.getVar('database_config')
    # mysql_config = db_config['database']['mysql']
    # pg_config = db_config['database']['pgsql']
    #
    # # 使用加载的配置文件创建数据库连接
    # mysqlHp = mysqlHelper.MySQLHelper(
    #     host=mysql_config['host'],
    #     port=mysql_config['port'],
    #     username=mysql_config['username'],
    #     password=mysql_config['password'],
    #     db_name=mysql_config['database'],
    #     # charset=mysql_config['charset']
    # )
    #
    # pgdb = postgreHelper.PostgreSQLDatabase(
    #     host=pg_config['host'],
    #     port=pg_config['port'],
    #     database=pg_config['database'],
    #     user=pg_config['username'],
    #     password=pg_config['password']
    # )

    mysqlHp = SuperVar.getVar("engine")
    pgdb = SuperVar.getVar("source_engine")
    return mysqlHp, pgdb


def rfm_predict_start():
    # args = parse_arguments()
    # task_id = args.task_id
    # tenant_api = args.tenant_api
    # flag = args.flag
    # data_location = args.data_location
    # predict_id = args.predict
    global task_id
    global tenant_api
    global custom_logger
    task_id = SuperVar.getVar('task_id')
    task_name = SuperVar.getVar('task_name')
    tenant_api = SuperVar.getVar('tenant')
    predict_id = SuperVar.getVar('predict_id')
    # predict_id = 688
    flag = SuperVar.getVar('filetype')
    data_location = SuperVar.getVar('location')
    creator = SuperVar.getVar('creator')
    start_json = SuperVar.getVar("start_json")
    if 'output_table_path' in start_json.keys():
        output_table_path = start_json['output_table_path']
        SuperVar.setVar("output_table_path", output_table_path)
    # custom_logger = read_log()
    mysqlHp, pgdb = read_database()

    mysqlHp.execute("")
    # 调度程序
    rfm_predict_main(pgdb, mysqlHp, flag, data_location, predict_id, creator, task_name)

# if __name__ == '__main__':
#     rfm_predict_start()
#     # 接收脚本传递过来的建模参数
#     args = parse_arguments()
#     task_id = args.task_id
#     tenant_api = args.tenant_api
#     flag = args.flag
#     data_location = args.data_location
#     predict_id = args.predict
#     predict_id = 688
#     # 调试参数
#     # flag = '2'
#     # tenant_api = 't100059'
#     # task_id = '268e1a10-cdfa-4462-9cd4-9e06077821ab'
#     # data_location = r"./data/RFM订单数据大金额.csv"
#     # entityTable = 1
#     # predict_ID = 1
#     # table_name =1
#     # user_Id = 1
#     # predict_id= 688
# 
#     mysqlHp, pgdb = read_database()
#     # 调度程序
#     rfm_predict_main()
