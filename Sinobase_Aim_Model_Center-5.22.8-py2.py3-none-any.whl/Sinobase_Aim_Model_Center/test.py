#!/usr/bin/env python3
# -*- coding: utf-8 _*_

"""
    @Author: json
    @Time: 2023/11/14 14:26
    @Describe
    @Version 1.0
"""
from Sinobase_Aim_Model_Center.Model_Center import ModelCenter

if __name__ == '__main__':
    train_json = {"task_id":"756a8261-59b1-4b05-a5e3-aafa1a04c54a", "tenant":"t100059",
                  "model_species":"classier", "alg_name":"rfm", "predict_id":"0","primary":"0",
                  'System_info':'Sinobase'}
    mc = ModelCenter(train_json, config_path=r"C:\Users\woniu\PycharmProjects\mip-aim-python-whl-model-center\src\Sinobase_Aim_Model_Center\resource\config")
    # mc.rfm()
    mc.rfm_predict()