# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :load_script_constructor.py

@Time      :2023/11/10 09:30

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
from Sinobase_Aim_Model_Center import  Script_Constructor as ScanDecorator
from Sinobase_Aim_Model_Center.Script_Constructor import num_feature, var_feature, all_feature, col_feature

from loguru import logger
import importlib.util

def cal_dict_size(func_dict: dict):
    sum_func = 0
    func_num_size = {}
    for i in list(func_dict.keys()):
        func_num_size[i] = len(func_dict[i])
        sum_func += len(func_dict[i])
    func_num_size['sum'] = int(sum_func / 2)
    return func_num_size
def Script_seq(path):
    function_list = ScanDecorator.count_decorators(path)
    func_num_size = cal_dict_size(function_list)
    logger.info(f"脚本数量总计： {func_num_size['sum']} 个")
    for key in list(func_num_size.keys()):
        if key != 'sum' and key != 'seq':
            logger.info(f"{key}特征处理 脚本个数： {func_num_size[key]} 个")
    spec = importlib.util.spec_from_file_location("module.name", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # for key in list(function_list.keys()):
    for func in function_list['seq']:
        logger.info(f"正在处理脚本 --> {func} ")
        getattr(module, func)()


def Script_class(path):
    function_list = ScanDecorator.count_decorators(path)
    func_num_size = cal_dict_size(function_list)
    logger.info(f"脚本数量总计： {func_num_size['sum']} 个")
    for key in list(func_num_size.keys()):
        if key != 'sum' and key != 'seq':
            logger.info(f"{key}特征处理 脚本个数： {func_num_size[key]} 个")
    spec = importlib.util.spec_from_file_location("module.name", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for key in list(function_list.keys()):
        if key != 'seq':
            for func in function_list[key]:
                logger.info(f"正在处理脚本 --> {func} ")
                getattr(module, func)()

def Script_System(path):
    spec = importlib.util.spec_from_file_location("module.name", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    getattr(module, 'start')()