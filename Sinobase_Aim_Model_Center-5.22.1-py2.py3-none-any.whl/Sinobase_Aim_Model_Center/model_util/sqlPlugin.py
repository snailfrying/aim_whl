# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :sqlPlugin.py

@Time      :2023/5/19 14:13

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''
from Sinobase_Aim_Model_Center.model_util import SuperVar

import time
from urllib import parse
from loguru import logger

import pandas as pd
from sqlalchemy import text
from sqlalchemy import create_engine


class Usesql:
    def __init__(self, host, port, username, password, database, connection, ssl):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.database = database
        self.connection = connection
        self.ssl = ssl

    # 创建连接mysql
    @logger.catch
    def connect(self, pgsql=False):
        my_ssl_args = {
            "ssl": {
                "ca": self.ssl
            }  # CA 证书路径
        }
        pg_ssl_args = {
            'sslmode': 'require',
            'sslrootcert': self.ssl  # Path to your CA certificate
        }
        '''连接数据库'''
        # logger.debug(self.connection
        #              % (self.username, parse.quote_plus(self.password), self.host, self.port, self.database))
        if self.ssl is None or self.ssl == "":
            engine = create_engine(self.connection
                                   % (self.username, parse.quote_plus(self.password), self.host, self.port,
                                      self.database))
        else:
            engine = create_engine(self.connection
                                   % (self.username, parse.quote_plus(self.password), self.host, self.port,
                                      self.database), connect_args=my_ssl_args if not pgsql else pg_ssl_args)

        return engine

    # 查询
    @logger.catch
    def execute(self, sql):
        if SuperVar.getVar("System_info") != 'User':
            logger.debug(sql)
            start = time.time()
            conn = self.connect()
            # try:
            if "select" in sql.lower():
                result = pd.read_sql(sql, conn)
                logger.debug("获取数据花费时间：%s" % (time.time() - start))
                logger.debug(result)
                conn.dispose()
                return result
            else:
                connection = conn.connect()
                # 执行一个更新操作
                result = connection.execute(text(sql))
                connection.commit()
                logger.debug("花费时间：%s" % (time.time() - start))
                # 关闭或者消费结果对象
                result.close()
        # except Exception as e:
        #     logger.error("SQL出错")
        #     logger.error(e)

    @logger.catch
    def DictUUSql(self, datadict, table):
        if SuperVar.getVar("System_info") != 'User':
            try:
                logger.debug(datadict)
                cols = ", ".join('`{}`'.format(k) for k in datadict.keys())
                val_cols = ', '.join('\'%({})s\''.format(k) for k in datadict.keys())
                sql = "insert into %s (%s) values(%s);"
                res_sql = sql % (table, cols, val_cols)  # 这里用%来格式化sql语句
                res_sql = res_sql % datadict  # 这里用format来格式化res_sql语句，把datadict的值放 入
                conn = self.connect()
                connection = conn.connect()
                result = connection.execute(text(res_sql))  # 这里用text包装res_sql，并传入datadict作为参数
                connection.commit()
                result.close()
            except Exception as e:
                logger.error("SQL出错")
                logger.error(e)

    @logger.catch
    def DictListSql(self, dictlist, table):
        if SuperVar.getVar("System_info") != 'User':
            try:
                full_values_sql = ''
                col_dict = dictlist[0]
                cols = ", ".join('`{}`'.format(k) for k in col_dict.keys())
                sql = "insert into %s (%s) values %s"
                for datadict in dictlist:
                    logger.debug(datadict)
                    val_cols = ', '.join('\'%({})s\''.format(k) for k in datadict.keys())
                    values_col = f'({val_cols}),'
                    res_sql = values_col % datadict
                    full_values_sql += res_sql
                    # print(full_values_sql)

                res_sql = sql % (table, cols, full_values_sql[:-1])  # 这里用%来格式化sql语句
                # print("=====================")
                # print(res_sql)
                conn = self.connect()
                connection = conn.connect()
                result = connection.execute(text(res_sql))  # 这里用text包装res_sql，并传入datadict作为参数
                connection.commit()
                result.close()
            except Exception as e:
                logger.error("SQL出错")
                logger.error(e)

    @logger.catch
    def insert_dataframe_to_pg(self, df: pd.DataFrame, table_name):
        """
        Insert a pandas DataFrame into a MySQL or PostgreSQL database table.

        Args:
        df (pandas.DataFrame): The DataFrame to insert.
        table_name (str): The name of the target database table.
        db_string (str): Database connection string.
        """
        # Create the sqlalchemy engine
        engine = self.connect(pgsql=True)

        # Insert the dataframe into the database in one bulk
        df.to_sql(table_name, engine, index=False, if_exists='append')

    @logger.catch
    def query(self, sql):
        if SuperVar.getVar("System_info") != 'User':
            logger.debug(sql)
            start = time.time()
            conn = None
            try:
                conn = self.connect()
                with conn.connect() as connection:
                    result = connection.execute(text(sql))

                    columns = result.keys()
                    rows = result.fetchall()
                    # 获取所有行数据并将其转换为字典形式
                    results_as_dict = []
                    for row in rows:
                        row_dict = dict(zip(columns, list(row)))
                        results_as_dict.append(row_dict)
                    logger.debug("花费时间：%s" % (time.time() - start))
                    return results_as_dict
            except Exception as e:
                logger.error("查询出错")
                logger.error(e)
            finally:
                if conn:
                    conn.dispose()
        return None
