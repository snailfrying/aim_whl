# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :load.py

@Time      :2023/5/12 16:19

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''
from sklearn.model_selection import train_test_split
import pandas as pd
import numpy as np
from loguru import logger


@logger.catch
def load_dataset(X,y,proportion):
    # X.to_csv('X.csv')
    # y.to_csv('y.csv')

    # df = pd.DataFrame(data)

    # X = df.iloc[:, 0:featuresnum].values
    # y = df.iloc[:, featuresnum:df.shape[1]].values
    proportion = 1-proportion
    X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=proportion, random_state=0)
    logger.debug(proportion)
    logger.debug(X_train.shape)
    logger.debug(X_train)
    logger.debug(X_test.shape)
    logger.debug(X_test)
    logger.debug(y_train.shape)
    logger.debug(y_test.shape)
    return X_train, X_test, y_train, y_test
