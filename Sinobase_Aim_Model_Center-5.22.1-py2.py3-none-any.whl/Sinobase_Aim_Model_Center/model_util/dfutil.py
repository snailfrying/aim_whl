# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :dfutil.py

@Time      :2023/11/09 10:05

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''


def compareAB(dfa, dfb):
    list1 = dfa.columns.tolist()
    list2 = dfb.columns.tolist()
    set1 = set(list1)
    set2 = set(list2)
    # 计算交集
    intersection = set1.intersection(set2)
    # 计算差集
    differencea = list(set1.difference(intersection))
    differenceb = list(set2.difference(intersection))
    return differencea, differenceb, list(intersection)


def compareA2Blist(dfa, listB):
    list1 = dfa.columns.tolist()
    list2 = listB
    set1 = set(list1)
    set2 = set(list2)
    # 计算交集
    intersection = set1.intersection(set2)
    # 计算差集
    differencea = list(set1.difference(intersection))
    differenceb = list(set2.difference(intersection))
    return differencea, differenceb, list(intersection)


def dfaWithListB(dfa, listb):
    seta = set(dfa.columns.tolist())
    intersection = seta.intersection(set(listb))
    return list(intersection)
