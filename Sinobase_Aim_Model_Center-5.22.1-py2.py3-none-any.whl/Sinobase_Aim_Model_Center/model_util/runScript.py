# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :runScript.py

@Time      :2023/6/27 10:40

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

import warnings
import pandas as pd
import joblib
import subprocess
from pathlib import Path
from Sinobase_Aim_Model_Center.model_util import SuperVar

try:
    subprocess.check_output('nvidia-smi')
    import cupy as np

    np.cuda.Device(1)
    # import numpy as np
    # logger.info("GPU")
except Exception:
    import numpy as np

import sys

from sklearn.model_selection import RandomizedSearchCV
import os
from Sinobase_Aim_Model_Center.model_util import ResultShow, CalLoss, CreateId
from warnings import simplefilter
from loguru import logger
from sklearn.exceptions import ConvergenceWarning

warnings.filterwarnings("ignore")
sys.path.append('../../../..')
warnings.filterwarnings("ignore", category=ConvergenceWarning)
simplefilter(action='ignore', category=UserWarning)


def use_model(model, param_dist, config, dataX, dataY, X_test, y_test, X_vf, y_vf, title):
    modelname = config['model']['path'] + config['task_id'] + '/' + title
    # 获取模型的类型
    # 根据类型获取不同的评估指标
    # 分类 1 auc 2 F1 3 准确率  4 召回率
    # 回归 1 r2    2 mse   3 rmse
    model_species = config['model_species']
    evaluation_indexc = config['evaluation_index']
    SuperVar.setVar("evaluation_indexc", evaluation_indexc)
    # 分类
    if model_species == 'classier':
        if evaluation_indexc == 1:
            evaluation = 'roc_auc'
        elif evaluation_indexc == 2:
            evaluation = 'f1'
        elif evaluation_indexc == 3:
            evaluation = 'accuracy'
        elif evaluation_indexc == 4:
            evaluation = 'recall'
        else:
            logger.error('分类评价指标出错')
            return False, '分类评价指标出错'
    elif model_species == 'regress':
        if evaluation_indexc == 1:
            evaluation = 'r2'
        elif evaluation_indexc == 2:
            evaluation = 'neg_mean_squared_error'
        elif evaluation_indexc == 3:
            evaluation = 'neg_root_mean_squared_error'
        else:
            logger.error('回归评价指标出错')
            return False, '回归评价指标出错'
    elif model_species == 'kmeans':
        if evaluation_indexc == 1:
            evaluation = 'r2'
        elif evaluation_indexc == 2:
            evaluation = 'neg_mean_squared_error'
        elif evaluation_indexc == 3:
            evaluation = 'neg_root_mean_squared_error'
        else:
            logger.error('Kmeans评价指标出错')
            return False, 'Kmeans评价指标出错'

    logger.info(f'使用的评价指标为 ： {evaluation}')

    if model_species == 'regress' or model_species == 'classier':

        # 创建自定义RandomizedSearchCV对象
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=ConvergenceWarning)
            rscv = RandomizedSearchCV(
                estimator=model,
                param_distributions=param_dist,
                n_iter=config['RS']['n_iter'],
                scoring=evaluation,
                n_jobs=-1,
                cv=config['cv'],
                random_state=42
            )
        i = 0
        try:
            rscv.fit(dataX, dataY.values.ravel())
        except Exception as e:
            logger.error(title + " 模型全部寻优 训练失败！内容保存在Debug日志")
            logger.debug(e)
            logger.error(e)
            return False, e

        # 根据mean_test_score获取前3个模型的索引

        top_indices = np.argsort(rscv.cv_results_['mean_test_score'])[-3:]

        # 根据索引获取对应的参数值
        top_models = [rscv.cv_results_['params'][i] for i in top_indices]
        logger.debug(top_models)
        model_config = SuperVar.getVar("model_config")
        model_ass_loss = {}
        model_ass_loss['max'] = 0
        model_ass_loss['max_ass'] = ''
        SuperVar.setVar("model_ass_loss", model_ass_loss)
        # 保存前3个模型
        for i, params in enumerate(top_models):
            if SuperVar.getVar("base_config")['databricks']:
                config['ass_id'] = CreateId.Create()
                model.set_params(**params)
                model.fit(dataX, dataY.values.ravel())

                saved_model_path = f"{modelname}-{config['ass_id'].split('-')[0]}_No{i + 1}" + config['model'][
                    'modelsuffix']
                config['model_path'] = saved_model_path
                task_file_path = Path(__file__).parent.parent.parent.parent / config['model']['path'] / config[
                    'task_id']
                # 创建task_id文件夹
                logger.info("databricks模式开启")
                logger.info("关闭模型保存模式")
                logger.info(config['ass_id'].split('-')[0])
                SuperVar.setVar(config['ass_id'].split('-')[0], model)
                import mlflow
                # experiment 需要绝对路径保存，并需要根据此client_id赋权
                model_path = "/Workspace/model_log_mlflow/"
                experiment_name = model_path + SuperVar.getVar(
                    "task_id") + "-" + config['ass_id'].split('-')[0]
                mlflow.set_experiment(experiment_name)

                with mlflow.start_run(run_name=SuperVar.getVar("task_id")) as run:
                    # 将模型保存到当前运行的artifacts目录下
                    model_path = saved_model_path
                    if model_species == 'classier':
                        mlflow.sklearn.log_model(model, artifact_path=model_path,pyfunc_predict_fn='predict_proba')
                    else:
                        mlflow.sklearn.log_model(model, artifact_path=model_path)

                    # 注册模型
                    registered_model_name = SuperVar.getVar("task_id")
                    logger.info("uri" + f"runs:/{run.info.run_id}/{model_path}")
                    mlmodel = mlflow.register_model(model_uri=f"runs:/{run.info.run_id}/{model_path}", name=registered_model_name)
                    config['version'] = 'Version '+ str(mlmodel.version)
                    logger.info("[INNER]模型保存" + saved_model_path + " 模型以保存")

                # # 开始一个新的MLflow运行
                # with mlflow.start_run(run_name=SuperVar.getVar("task_name")) as run:
                #
                #     # 将模型保存到当前运行的artifacts目录下
                #     model_path = "model"
                #     mlflow.sklearn.log_model(model, artifact_path=model_path)
                #
                #     # 注册模型
                #     registered_model_name = SuperVar.getVar("task_name")
                #     mlflow.register_model(model_uri=f"runs:/{run.info.run_id}/{model_path}", name=registered_model_name)

                # if not os.path.exists(config['model']['path'] + config['task_id']):
                #     os.makedirs(config['model']['path'] + config['task_id'])
                # if SuperVar.getVar("System_info") != 'User' and SuperVar.getVar("model_config")['model']['open']:
                #     joblib.dump(model, saved_model_path)
                #     logger.info("[INNER]模型保存" + saved_model_path + " 模型以保存")
                # elif SuperVar.getVar("System_info") != 'User' and not SuperVar.getVar("model_config")['model']['open']:
                #
                # else:
                #     logger.info("沙盒模型下，模型无法保存")
                y_pred = model.predict(X_test)

                dataY_pred = model.predict(dataX)
                # data_loss = CalLoss.cal(dataY, dataY_pred, config['model_species'])
                # loss = data_loss[SuperVar.getVar("evaluation_indexc")]
                # model_ass_loss = SuperVar.getVar("model_ass_loss")
                # if loss > model_ass_loss['max']:
                #     model_ass_loss['max'] = loss
                #     model_ass_loss['max_ass'] = config['ass_id']
                #     SuperVar.setVar("model_ass_loss", model_ass_loss)
                #     SuperVar.setVar("model_ass_loss_model", model)

                verify = config['verify']
                if verify:
                    vfy_pred = model.predict(X_vf)
                    verify_loss = CalLoss.cal(y_vf, vfy_pred, config['model_species'])
                else:
                    vfy_pred = None
                    verify_loss = [0, 0, 0, 0]

                model_name = f"{title}_No{i + 1}"
                ResultShow.BeforeShow(model, dataX, dataY, X_test, y_test, config, y_pred, dataY_pred, params,
                                      X_vf, y_vf,
                                      vfy_pred,
                                      verify_loss,
                                      model_name)


            else:
                config['ass_id'] = CreateId.Create()
                # model.set_params(**params)
                train_model = model.fit(dataX, dataY.values.ravel())

                # print(dataX.columns.to_list())
                saved_model_path = f"{modelname}-{config['ass_id'].split('-')[0]}_No{i + 1}" + config['model'][
                    'modelsuffix']
                config['model_path'] = saved_model_path
                task_file_path = Path(__file__).parent.parent.parent.parent / config['model']['path'] / config[
                    'task_id']
                # 创建task_id文件夹
                if not os.path.exists(config['model']['path'] + config['task_id']):
                    os.makedirs(config['model']['path'] + config['task_id'])
                if SuperVar.getVar("System_info") != 'User' and SuperVar.getVar("model_config")['model']['open']:
                    joblib.dump(model, saved_model_path)
                    logger.info("[INNER]模型保存" + saved_model_path + " 模型以保存")
                elif SuperVar.getVar("System_info") != 'User' and not SuperVar.getVar("model_config")['model']['open']:
                    logger.info("关闭模型保存模式")
                    logger.debug("注册模型")

                else:
                    logger.info("沙盒模型下，模型无法保存")
                    # (same syntax works for LightGBM, CatBoost, scikit-learn, transformers, Spark, etc.)
                    import shap
                    import matplotlib.pyplot as plt
                    from shap import plots
                    # explainer = shap.KernelExplainer(model.predict, dataX)
                    explainer = shap.Explainer(model.predict, X_test)
                    shap_values = explainer(X_test)
                    # visualize the first prediction's explanation
                    # shap.plots.waterfall(shap_values[0])
                    # shap.plots.force(shap_values[0])
                    # explainer = shap.Explainer(train_model)
                    # shap_values = explainer(dataX)
                    import matplotlib.pyplot as plt
                    # 创建一个大的画布
                    # 在第一个子图中显示瀑布图
                    shap.plots.waterfall(shap_values[0], show=False)
                    plt.savefig(f'ma{i}.png')
                    plt.clf()
                    shap.plots.scatter(shap_values[:, X_test.columns[0]], color=shap_values, show=False)
                    plt.savefig(f'mb{i}.png')
                    plt.clf()
                    shap.plots.beeswarm(shap_values, show=False)
                    plt.savefig(f'mc{i}.png')
                    plt.clf()
                    shap.plots.bar(shap_values, show=False)
                    plt.savefig(f'md{i}.png')
                    plt.clf()
                    # print(shap_values)
                    shap.plots.force(shap_values[:10])
                    plt.savefig(f'me{i}.png')
                    plt.clf()
                    # 调整子图之间的间距
                    # mk(ax=ax1)
                    # bl(ax=ax2)
                    # plt.subplots_adjust(wspace=0.3)
                    # 显示或保存图形

                    # plt.savefig('combined.png')

                    # print(type(mk))
                    # 显示新figure
                    # plt.show()

                    # 显示图表
                    # visualize the first prediction's explanation
                    # shap.plots.waterfall(shap_values[0])
                    # joblib.dump(model, saved_model_path)
                y_pred = model.predict(X_test)

                dataY_pred = model.predict(dataX)

                verify = config['verify']
                if verify:
                    vfy_pred = model.predict(X_vf)
                    verify_loss = CalLoss.cal(y_vf, vfy_pred, config['model_species'])
                else:
                    vfy_pred = None
                    verify_loss = [0, 0, 0, 0]

                model_name = f"{title}_No{i + 1}"
                if SuperVar.getVar("System_info") != 'User':
                    ResultShow.BeforeShow(model, dataX, dataY, X_test, y_test, config, y_pred, dataY_pred, params, X_vf,
                                          y_vf,
                                          vfy_pred,
                                          verify_loss,
                                          model_name)
                else:
                    pass

        return True, ''
    elif model_species == 'kmeans':
        # 先将dataX, dataY, X_test, y_test, X_vf, y_vf 数据整合为完整数据
        X = pd.concat([dataX, X_test], ignore_index=True)
        model.set_params(**param_dist)
        y = model.fit(X)
        return True, ''
    else:
        return False, '模型类型错误'
