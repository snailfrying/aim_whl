# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :user.py

@Time      :2023/11/08 13:51

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
import inspect
import importlib.util
from Sinobase_Aim_Model_Center.model_util import ScanDecorator


def hello():
    caller = inspect.stack()[1].filename
    function_list = scan.count_decorators(caller)
    spec = importlib.util.spec_from_file_location("module.name", caller.strip(' '))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for func in function_list['all']:
        getattr(module, func)()
