# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :LinearDiscriminantAnalysis.py

@Time      :2023/5/19 10:23

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''
import sys
import warnings

from loguru import logger
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LassoCV

sys.path.append('../../..')
warnings.filterwarnings("ignore")
import numpy as np
# LinearDiscriminantAnalysis
from warnings import simplefilter

simplefilter(action='ignore', category=FutureWarning)


class MyLinearDiscriminant(LinearDiscriminantAnalysis):
    # 重写feature_importances_属性
    def fit(self, X, y):
        super().fit(X, y)
        self.X_ = X
        self.y_ = y
        return self

    @property
    def feature_importances_(self):
        result = permutation_importance(self, self.X_, self.y_)
        return result.importances_mean


@logger.catch
def definition_model():
    # 定义参数分布
    param_dist = {
        'shrinkage': np.arange(0.1, 1, 0.1),
        'solver': ['lsqr', 'eigen'],
        'tol': np.arange(0.1, 1, 0.1),
        'store_covariance': [True, False]
    }
    model = MyLinearDiscriminant()
    return model, param_dist
