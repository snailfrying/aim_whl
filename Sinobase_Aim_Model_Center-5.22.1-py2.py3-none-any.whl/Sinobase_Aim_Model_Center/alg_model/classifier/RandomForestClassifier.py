# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :RandomForestClassifier.py

@Time      :2023/5/19 10:22

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

import sys
import warnings

from loguru import logger
from sklearn.ensemble import RandomForestClassifier

sys.path.append('../../..')
warnings.filterwarnings("ignore")
from scipy.stats import uniform
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)


#         for n_estimators in range(10, 50, 5):
#             for max_depth in range(4, 10, 2):
#                 for min_samples_leaf in range(1, 15, 3):
#                     for max_features in range(1, 3, 1):
#                         for min_impurity_decrease in np.arange(0, 0.5, 0.1):

# RandomForestClassifier

@logger.catch
def definition_model():
    # 定义参数分布
    param_dist = {
        'n_estimators':[50, 150, 200],
        'max_depth':[ 5, 8, 10 ],
        # 'min_samples_split':[ 2, 5, 10 ],
        # 'min_samples_leaf':[ 1, 2, 5 ],
        # 'max_features':[ 'auto', 'sqrt', 'log2', 5, 10 ],
        'bootstrap':[ True, False ]
    }
    model = RandomForestClassifier()
    return model, param_dist