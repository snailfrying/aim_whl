# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :LinearRegression.py

@Time      :2023/7/6 9:56

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''


import sys
sys.path.append('../../..')
import warnings
warnings.filterwarnings("ignore")
from loguru import logger
from scipy.stats import uniform
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)

from sklearn.linear_model import LinearRegression

class MyLinearRegression(LinearRegression):
    @property
    def feature_importances_(self):
        if self.coef_ is None:
            self.coef_ = self.coef_.flatten()
        return self.coef_ / abs(self.coef_).sum()



@logger.catch
def definition_model():
    # 定义参数分布
    # 'copy_X', 'fit_intercept', 'n_jobs', 'positive'
    param_dist = {
        # 'copy_X': [True, False],  # 是否复制 X 在拟合之前
        'fit_intercept': [True, False],  # 是否计算截距项
        # 'n_jobs': [None, -1, 1, 2],  # 并行运行的任务数
        # 'positive': [True, False],  # 是否强制系数为正
    }

    model = MyLinearRegression()
    return model, param_dist
