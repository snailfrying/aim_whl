# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :ExtraTreeRegression.py

@Time      :2023/7/6 9:59

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''


import sys
sys.path.append('../../..')
import warnings
warnings.filterwarnings("ignore")
from loguru import logger
from scipy.stats import uniform
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)

from sklearn.tree import ExtraTreeRegressor





@logger.catch
def definition_model():
    # 定义参数分布
    # 'ccp_alpha', 'criterion', 'max_depth', 'max_features', 'max_leaf_nodes', 'min_impurity_decrease', 'min_samples_leaf', 'min_samples_split', 'min_weight_fraction_leaf', 'random_state', 'splitter'
    param_dist = {
        'ccp_alpha': [0.0, 0.01, 0.1, 1.0],  # 复杂性参数，用于最小成本复杂性修剪
        'criterion': ['poisson', 'friedman_mse', 'squared_error', 'absolute_error'],  # 分割质量的衡量标准
        'max_depth': [None, 5, 10, 20],  # 树的最大深度
        'max_features': range(1, 100),  # 寻找最佳分割时要考虑的特征数量
        'max_leaf_nodes': [None, 10, 50, 100],  # 树的最大叶节点数
        'min_impurity_decrease': [0.0, 0.01, 0.1],  # 分裂节点所需的最小杂质减少量
        'min_samples_leaf': [1, 2, 5, 10],  # 叶节点所需的最小样本数
        'min_samples_split': [2, 5, 10],  # 分裂内部节点所需的最小样本数
        'min_weight_fraction_leaf': [0.0, 0.1, 0.2],  # 叶节点所需的权重总和的最小加权分数
        'random_state': [None, 42],  # 随机选择每次拆分时使用的 max_features 的随机数生成器
        'splitter': ['random', 'best'],  # 选择每个节点的分割策略
    }

    model = ExtraTreeRegressor()
    return model, param_dist
