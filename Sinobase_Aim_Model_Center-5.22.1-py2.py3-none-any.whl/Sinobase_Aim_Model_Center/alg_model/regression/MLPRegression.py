# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :MLPRegression.py

@Time      :2023/7/6 9:58

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

import sys

from sklearn.inspection import permutation_importance

sys.path.append('../../..')
import warnings

warnings.filterwarnings("ignore")
from loguru import logger
from scipy.stats import uniform
from warnings import simplefilter

simplefilter(action='ignore', category=FutureWarning)
simplefilter(action='ignore', category=UserWarning)
from sklearn.exceptions import ConvergenceWarning

simplefilter(action='ignore', category=ConvergenceWarning)

from sklearn.neural_network import MLPRegressor
import numpy as np

class MyMLPRegressor(MLPRegressor):
    # 重写feature_importances_属性
    def fit(self, X, y):
        super().fit(X, y)
        self.X_ = X
        self.y_ = y
        return self

    @property
    def feature_importances_(self):
        result = permutation_importance(self, self.X_, self.y_)
        return result.importances_mean
@logger.catch
def definition_model():
    # 有问题
    # 定义参数分布
    # 'activation', 'alpha', 'batch_size', 'beta_1', 'beta_2', 'early_stopping', 'epsilon', 'hidden_layer_sizes', 'learning_rate', 'learning_rate_init', 'max_fun', 'max_iter', 'momentum', 'n_iter_no_change', 'nesterovs_momentum', 'power_t', 'random_state', 'shuffle', 'solver', 'tol', 'validation_fraction', 'verbose', 'warm_start'
    param_dist = {
        'activation': ['identity', 'logistic', 'tanh', 'relu'],  # activation是激活函数，用于隐藏层的输出
        'alpha': range(0, 10),  # alpha是L2正则化参数，用于惩罚权重
        # 'hidden_layer_sizes': [(10,), (50,), (100,), (10, 10), (50, 50), (100, 100)],
        # hidden_layer_sizes是一个元组，表示每个隐藏层的神经元数量
        'max_iter': range(1000, 3000),  # max_iter是最大迭代次数
        # 'learning_rate': ['constant', 'invscaling', 'adaptive'],  # learning_rate是学习率的更新策略，可以是固定的，反比例的，或者自适应的
        # 'learning_rate_init': np.logspace(-4, -1, 10),  # learning_rate_init是初始学习率，只对'constant'和'adaptive'有效
        # 'max_fun': range(15000, 20000),  # max_fun是最大函数调用次数，当达到这个次数时停止训练
        'momentum': uniform(0, 1),  # momentum是动量系数，用于加速梯度下降
        'n_iter_no_change': range(10, 20),  # n_iter_no_change是在验证分数没有改善时停止训练的迭代次数
        'validation_fraction': uniform(0, 1),  # validation_fraction是预留作为早期停止验证集的训练数据比例
        # 'warm_start': [True, False],  # warm_start是一个布尔值，表示是否使用之前训练结果作为初始化

    }

    model = MyMLPRegressor()
    return model, param_dist
