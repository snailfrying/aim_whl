# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :LassoRegression.py

@Time      :2023/7/6 9:57

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''


import sys
sys.path.append('../../..')
import warnings
warnings.filterwarnings("ignore")
from loguru import logger
from scipy.stats import uniform
from warnings import simplefilter
from sklearn.exceptions import ConvergenceWarning
warnings.filterwarnings("ignore")

# 有问题
from sklearn.linear_model import Lasso

from sklearn.linear_model import Lasso


class MyLasso(Lasso):
    @property
    def feature_importances_(self):
        if self.coef_ is None:
            self.coef_ = self.coef_.flatten()
        return self.coef_ / abs(self.coef_).sum()



@logger.catch
def definition_model():
    # 定义参数分布
    # 'alpha', 'copy_X', 'fit_intercept', 'max_iter', 'positive', 'precompute', 'random_state', 'selection', 'tol', 'warm_start'
    param_dist = {
        'alpha': [0.001, 0.01, 0.1, 1.0],  # 正则化系数
        'copy_X': [True, False],  # 是否复制 X 在拟合之前
        'max_iter': range(1000, 10000),  # 最大迭代次数
        'positive': [True, False],  # 是否强制系数为正
        'precompute': [True, False],  # 是否预先计算 Gram 矩阵
        'random_state': [None, 42],  # 随机数生成器
        'selection': ['cyclic', 'random'],  # 更新系数时的选择方法
        'tol': [1e-4, 1e-3, 1e-2],  # 停止迭代的容忍度
        'warm_start': [False, True],  # 是否使用之前训练结果作为初始化
    }

    model = MyLasso()
    return model, param_dist
