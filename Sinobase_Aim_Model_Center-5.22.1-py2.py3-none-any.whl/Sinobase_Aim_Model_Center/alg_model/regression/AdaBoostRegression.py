# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :AdaBoostRegression.py

@Time      :2023/7/6 9:59

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

# https://blog.csdn.net/qq_43751211/article/details/115372774
import sys
sys.path.append('../../..')
import warnings

warnings.filterwarnings("ignore")
from loguru import logger
from scipy.stats import uniform
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)
simplefilter(action='ignore', category=UserWarning)

from sklearn.ensemble import AdaBoostRegressor





@logger.catch
def definition_model():
    # 定义参数分布
    param_dist = {
        'learning_rate': uniform(0.01, 1),
        'n_estimators': range(50, 200),
        'random_state': range(1, 10)
    }
    model = AdaBoostRegressor()
    return model, param_dist
