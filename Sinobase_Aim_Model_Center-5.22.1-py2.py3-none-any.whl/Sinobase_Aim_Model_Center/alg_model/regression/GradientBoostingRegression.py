# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :GradientBoostingRegression.py

@Time      :2023/7/6 9:59

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

import sys

sys.path.append('../../..')
import warnings

warnings.filterwarnings("ignore")
from loguru import logger
from scipy.stats import uniform
from warnings import simplefilter

simplefilter(action='ignore', category=FutureWarning)

from sklearn.ensemble import GradientBoostingRegressor


@logger.catch
def definition_model():
    # 定义参数分布
    # 'alpha', 'ccp_alpha', 'criterion', 'init', 'learning_rate', 'loss', 'max_depth', 'max_features', 'max_leaf_nodes', 'min_impurity_decrease', 'min_samples_leaf', 'min_samples_split', 'min_weight_fraction_leaf', 'n_estimators', 'n_iter_no_change', 'random_state', 'subsample', 'tol', 'validation_fraction', 'verbose', 'warm_start'
    param_dist = {
        # 'alpha': [0.1, 0.5, 0.9],  # 置信区间的水平
        # 'ccp_alpha': [0.0, 0.01, 0.1, 1.0],  # 复杂性参数，用于最小成本复杂性修剪
        # 'criterion': ['friedman_mse', 'squared_error'],  # 分割质量的衡量标准
        'learning_rate': [0.01, 0.001],  # 学习率，控制每棵树对最终结果的贡献
        # 'loss': ['absolute_error', 'huber', 'squared_error', 'quantile'],  # 损失函数
        'max_depth': [5, 8],  # 树的最大深度
        # 'max_features': range(1, 100),  # 寻找最佳分割时要考虑的特征数量
        # 'min_impurity_decrease': [0.0, 0.01, 0.1],  # 分裂节点所需的最小杂质减少量
        # 'min_samples_leaf': [1, 2, 5, 10],  # 叶节点所需的最小样本数
        'min_samples_split': [1, 2, 3],  # 分裂内部节点所需的最小样本数
        # 'min_weight_fraction_leaf': [0.0, 0.1, 0.2],  # 叶节点所需的权重总和的最小加权分数
        'n_estimators': [50,80, 100],  # 树的数量
        # 'n_iter_no_change': [5, 10],  # 在验证分数没有改善时停止训练的迭代次数
        'subsample': [0.85, 0.9],  # 训练每棵树时使用的样本比例
        # 'tol': [1e-4, 1e-3, 1e-2],  # 在验证分数没有改善时停止训练的容忍度
        # 'validation_fraction': [0.1, 0.2, 0.3],  # 预留作为早期停止验证集的训练数据比例
    }

    model = GradientBoostingRegressor()
    return model, param_dist
