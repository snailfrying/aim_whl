#!/usr/bin/env python3
# -*- coding: utf-8 _*_

"""
    @Author: json
    @Time: 2023/6/7 18:26
    @Describe
    @Version 1.0
"""

from Sinobase_Aim_Model_Center.rfm.utils import mysqlHelper
from Sinobase_Aim_Model_Center.rfm.utils import customLogger
from Sinobase_Aim_Model_Center.rfm.utils import postgreHelper
from Sinobase_Aim_Model_Center.rfm.utils import HttpRequest
from Sinobase_Aim_Model_Center.model_util import SuperVar

import os
import re
import sys
import yaml
import math
import json
import argparse
import traceback
import numpy as np
import pandas as pd
# from pandarallel import pandarallel
from pprint import pprint

# pandarallel.initialize()
# 设置最大显示行数为 10
pd.set_option('display.max_rows', 10)
# 设置最大显示列数为 10
pd.set_option('display.max_columns', 100)

period_dict = {90: 1, 180: 2, 365: 3, 730: 4}
target_dict = {'R': 1, 'F': 2, 'M': 3}

# 加载配置文件
# with open('utils/log.yaml', 'r') as config_file:
#     log_config = yaml.safe_load(config_file)
def read_log():
    log_config = SuperVar.getVar('log_config')
    logger = customLogger.CustomLogger(log_config, __name__, "processing")
    # 修改Loguru的record属性，使其显示正确的函数和列名
    custom_logger = logger.logger
    custom_logger.info("********开始执行rfm模型，并输出运行日志*******")
    return custom_logger

def record_processing_time():
    start_time = pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S")
    return start_time


def F_col_name(names):
    res = []
    for name in names:
        x, y = int(re.split(r'[<≤]', name)[0]), int(re.split(r'[<≤]', name)[2])
        if y - x == 1:
            res.append(f'F={y}')
        else:
            res.append(name)
    return res


def state_updating(mysqldb, task_id, state, progress, pid, train_end_time):
    """
    修改任务状态
    :param task_id:
    :param mysql_conf:
    :param state:
    :param progress:
    :return:
    """
    if not train_end_time:
        sql = "update model_instance set state =  '%s', progress = '%s', pid = '%s' where id = '%s'" % (
            state, progress, pid, task_id)
    else:
        sql = "update model_instance set state =  '%s', progress = '%s', pid = '%s', training_end_time = '%s' " \
              "where id = '%s'" % (state, progress, pid, train_end_time, task_id)
    mysqldb.execute(sql)

def update_max_time(mysqldb, task_id, max_date):
    max_d = "update model_instance set max_date =  '%s'" \
              "where id = '%s'" % (max_date, task_id)
    mysqldb.execute(max_d)

def select_name_and_creator(mysqldb, task_id):
    sql = "select user_id, name from model_instance where id = '%s'" % task_id
    results = mysqldb.query(sql)
    user_id, name = '001', '001'
    # 解析结果
    if results:
        for row in results:
            user_id = str(row['user_id'])
            name = str(row['name'])
            print(f"user_id: {user_id}, name: {name}")
    return user_id, name


def R_rule(rfm_df, gap_type=-1, date_gap=90):
    """
    R 划分规则
    :param date_gap:
    :param rfm_df:
    :param gap_type: 根据拟定划分规则，分配不同的间隔
    :return:
    """

    # R值分析，R值间隔天数
    R_gap = [7, 14, 30]
    R_max = rfm_df.R.max()
    gap_type = gap_type - 1
    if gap_type >= 0 and gap_type <= 2:
        gap = R_gap[gap_type]
        quota = math.floor(R_max / gap)
        # 保证截止时间为选择的最大区间
        R_max = date_gap
        R_values = [0] + [gap * i for i in range(1, quota)] + [R_max]
    else:  # 默认是均等分-5等分
        # interval = math.floor(R_max / 5)  # 计算每个等分的间隔大小
        # rounded_interval = math.floor(interval / 5) * 5
        # R_values = [0] + [rounded_interval * i for i in range(1, 5)] + [R_max]  # 计算五个等分的数值
        # RFM模型汇总结果分析，R值划分间隔
        R_max = date_gap
        R_date_gap = {
                      90: [0, 7, 14, 30, 60, R_max],
                      180: [0, 14, 30, 60, 90, R_max],
                      365: [0, 30, 60, 90, 180, R_max],
                      730: [0, 30, 90, 180, 360, R_max]
                      }
        R_values = R_date_gap[date_gap]
    return R_values


def F_rule(rfm_df):
    """
    F 划分规则
    :param rfm_df:
    :return:
    """
    F_gap = 5
    F_max = rfm_df.F.max()
    if F_max <= 5:
        F_values = [0, 1, 2, 3, 4, 5]
    elif F_max <= 10:
        F_values = [0, 1, 2, 3, 4, F_max]
    elif F_max <= 20:
        F_values = [0, 1, 2, 4, 8, F_max]
    else:
        interval = math.floor(F_max / F_gap)  # 计算每个等分的间隔大小
        rounded_interval = math.floor(interval / 5) * 5
        F_values = [0, 1, 2] + [rounded_interval * i for i in range(1, 3)] + [F_max]  # 计算五个等分的数值
    return F_values


def M_gap_rule(m_max: int, m_type="total"):
    """
    根据产品总消费金额和客单件的最大值进行选择不同的划分区间
    :param m_max: M最大值
    :param m_type: total为总消费金额 否则为客单价 -- 源代码没有根据参数数据去划分
    :return: M分区间隔值
    :rtype: List
    """
    if m_type == "total":
        # 按消费总金额划分M值分析间隔
        if m_max <= 10000:
            M_gap = [10, 50, 100]
        elif m_max <= 100000:
            M_gap = [100, 500, 1000]
        elif m_max <= 1000000:
            M_gap = [1000, 5000, 10000]
        else:
            M_gap = [10000, 50000, 100000]
    else:
        # 按单次消费平均金额划分M值分析间隔
        if m_max <= 10000:
            M_gap = [10, 20, 50]
        elif m_max <= 100000:
            M_gap = [50, 100, 500]
        else:
            M_gap = [100, 1000, 10000]
    return M_gap

def M_partition_interval(rfm_df):
    mean_value = math.floor(rfm_df['M'].mean())
    gap_times = 4
    return mean_value*gap_times


def round_to_nearest_hundred( m, gap_num ):
    m = math.floor(m / 10) * 10
    if gap_num <= 50:
        return m
    elif gap_num <= 75:
        return math.floor(m / 50) * 50
    return ((m + 50) // 100) * 100

def M_rule(rfm_df, gap_type=-1, m_type="total"):
    """
    M 划分规则
    :param rfm_df:
    :param gap_type: 根据分配划分间隔，分配不同组合
    :param m_type:
    :return:
    """
    M_max = rfm_df.M.max()
    M_max = math.floor(M_max / 10) * 10
    mean_value = math.floor(rfm_df['M'].mean())
    mp = M_partition_interval(rfm_df)
    M_gap = M_gap_rule(mp, m_type)
    gap_type = gap_type - 1
    if gap_type in (0, 1, 2):
        # 均值*倍数为中间，判断划分等级
        gap = M_gap[gap_type]
        m_mean_times = mp
        before_quota = math.floor(m_mean_times/gap)
        after_quota = math.floor((M_max - m_mean_times)/ 5 / 10) * 10
        cut_points = [0] + [gap*i for i in range(1, before_quota + 1)] + \
                     [m_mean_times + after_quota * i for i in range(1, 5)] + [M_max]
    else:
        # 五等分
        m1 = math.floor(mean_value / 3)
        m2 = math.floor(2 * mean_value / 3 )
        m3 = math.floor(mean_value)
        m4 = math.floor(4 * mean_value / 3)
        gap_num = m2-m1
        cut_points = [round_to_nearest_hundred(m, gap_num) for m in [0, m1, m2, m3, m4, M_max]]
    return cut_points


def update_rfm_max(mysqlHp, start_time, date_gap, R_max, F_max, M_max):
    # 更新rfm 相关值的最大值
    del_max_sql = f"""delete from model_rfm_max_value 
                        where instance_id = '{task_id}' and cycle = {date_gap}"""
    mysqlHp.execute(del_max_sql)

    update_max = f"""
               insert into model_rfm_max_value(instance_id,cycle,recency,frequency,monetary,create_time) 
               values ("%s","%d","%d","%d","%d","%s")""" % (task_id, date_gap,
                                                            int(R_max), int(F_max), int(M_max),
                                                            start_time)
    mysqlHp.execute(update_max)

def update_log(task_id, des, build_or_scoring, state, error_log, create_user, update_user, mysqlHp):
    if des == '任务开始执行':
        res_sql = f"DELETE FROM model_log WHERE task_id = '{task_id}'"
        mysqlHp.execute(res_sql)

    date = record_processing_time()
    create_time, update_time = date, date
    deleted = 0
    sql_query = f"""
        INSERT INTO model_log (task_id, time, des, build_or_scoring, state, error_log, create_user, update_user, create_time, update_time, deleted) 
        VALUES ('{task_id}', '{date}', '{des}', {build_or_scoring}, '{state}', '{error_log}', '{create_user}', '{update_user}', '{create_time}', '{update_time}', {deleted})
    """
    mysqlHp.execute(sql_query)

def detect_file_type(file_path):
    _, extension = os.path.splitext(file_path)
    if extension == '.csv':
        return 'csv'
    elif extension in ['.xls', '.xlsx', '.xlsm']:
        return 'excel'
    else:
        return 'unknown'

def read_data(flag, data_location, pgdb):
    """
    根据传参读取数据
    :param flag: 2：文件 否读数据库表
    :param data_location: 文件名|表名
    :return:
    """
    # data_location = r"E:\sinobaseAim\models\rfm\data\RFM订单数据大金额.csv"
    if str(flag) == "2":
        if detect_file_type(data_location) == 'csv':
            try:
                data = pd.read_csv(data_location, encoding='utf-8')
            except Exception:
                data = pd.read_csv(data_location, encoding='gbk')
            finally:
                print("只支持utf-8和gbk编码文件！")
        else:
            try:
                data = pd.read_excel(data_location)
            except Exception:
                data = pd.read_excel(data_location, engine='openpyxl')
            finally:
                print("只支持utf-8和gbk编码文件！")
    else:
        query = f"SELECT * FROM {data_location};"
        columns, result = pgdb.query(query)
        print("Query result:", result)
        data = pd.DataFrame(result, columns=columns)
    data.columns = ['userid', 'datetime', 'amount']
    data["userid"] = data['userid'].rank(method='dense')
    # 转换datetime列为日期格式
    data['datetime'].dropna(inplace=True)
    data['datetime'] = pd.to_datetime(data['datetime'])
    # print(data)
    return data


def calculate_R_F_M(data, datetime_max):
    # 计算R、F、M值
    # 计算R值（最近一次购买时间距离当前日期的天数）
    rfm_df = data.groupby('userid').agg(
        R=('datetime', lambda x: (datetime_max - x.max()).days),
        F=('datetime', 'count'),
        M=('amount', 'sum')
    ).reset_index()
    return rfm_df


def R_F_M_group(rfm_df, ta, gap_type, m_type, date_gap):
    """
    根据计算的R F M 值，进行分组
    :param rfm_df:
    :param ta:
    :param gap_type:
    :param m_type:
    :return:
    """
    r_gap, m_gap = -1, -1
    if ta == "R":
        r_gap = gap_type.get(ta, -1)
    elif ta == "M":
        m_gap = gap_type.get(ta, -1)
    if m_type == 'by_purch':
        rfm_df['M'] = rfm_df['M'] / rfm_df["F"]
    # 自定义分组字典
    group_dict = {
        'R': R_rule(rfm_df, r_gap, date_gap),
        'F': F_rule(rfm_df),
        'M': M_rule(rfm_df, m_gap, m_type)
    }

    # 定义分组函数
    def assign_group(row, ty):
        # group = sum(row[ty] >= cutoff for cutoff in group_dict[ty])
        group = 0
        v = 1 if int(row[ty]) == 0 else int(row[ty])
        for i, cutoff in enumerate(group_dict[ty]):
            if v > cutoff:
                group = i + 1
            else:
                return f"{group_dict[ty][group - 1]}<{ty}≤{group_dict[ty][group]}"
    # 保留全部分组的结果
    def assign_group_t(group, ty):
            return f"{group_dict[ty][group - 1]}<{ty}≤{group_dict[ty][group]}"

    # 用户保证没有值的分组
    group_dict_result = {}
    for k, v in group_dict.items():
        value = []
        for i, n in enumerate(v[:-1]):
            value.append(assign_group_t(i + 1, k))
        group_dict_result[k] = value
    # 添加分组列
    for ty in ["R", "F", "M"]:
        # rfm_df[ty + '_group'] = rfm_df.parallel_apply(lambda x: assign_group(x, ty), axis=1)
        rfm_df[ty + '_group'] = rfm_df.apply(lambda x: assign_group(x, ty), axis=1)
    return rfm_df, group_dict_result


def complement_matrix_columns(matrix, group_dict_result, ty):
    # 用于补充列
    group_columns = list(matrix)
    for f in group_dict_result[ty]:
        if f not in group_columns:
            matrix[f] = 0
    matrix.reset_index(inplace=True)
    return matrix


def conplement_matrix_row(result, ta, group_dict_result):
    # 用户补充行，并且合并连续为空的值
    all_columns = result.columns.tolist()
    ranges = [re.findall(r'\d+', v) for v in result[ta + '_group'].tolist()]
    all_ranges = group_dict_result[ta]
    max_v = re.findall(r'\d+', all_ranges[-1])[1]
    for i in range(1, len(ranges)):
        a = ranges[i - 1][1]
        b = ranges[i][0]
        combined_range = "{}<F≤{}".format(a, b)
        if combined_range not in all_ranges and int(b) - int(a) != 0:
            # 新行的数据，r_group 列为指定值，其他列填充为 0
            new_row_data = {col: 0 for col in all_columns}
            new_row_data[ta + '_group'] = combined_range
            # 使用 loc 属性添加新行
            result.loc[len(result)] = new_row_data

        # 补充开始不为0的值
        min_v = ranges[i - 1][0]
        if i == 1 and min_v != "0":
            combined_range = "{}<F≤{}".format("0", min_v)
            # 新行的数据，r_group 列为指定值，其他列填充为 0
            new_row_data = {col: 0 for col in all_columns}
            new_row_data[ta + '_group'] = combined_range
            # 使用 loc 属性添加新行
            result.loc[len(result)] = new_row_data
        # 补充结束不为最大值区间的
        # ma_v = ranges[ i ][ 1 ]
        # if i == len(ranges) - 1 and ma_v < max_v:
        #     combined_range = "{}<F≤{}".format(ma_v, max_v)
        #     # 新行的数据，r_group 列为指定值，其他列填充为 0
        #     new_row_data = {col:0 for col in all_columns}
        #     new_row_data[ ta + '_group' ] = combined_range
        #     # 使用 loc 属性添加新行
        #     result.loc[ len(result) ] = new_row_data
    return result


def R_F_M_analysis(rfm_df, mysqlHp, group_dict_result, start_time, user_id, date_gap=90):
    """
    RFM 综合分析结果，主要通过RF分组计算各指标值
    :param rfm_df: 源数据
    :param mysqlHp: 数据库连接
    :param group_dict_result:全部分组结果
    :param start_time: 计算开始时间
    :param date_gap: 数据日期间隔
    :return:
    """
    table_name = "model_rfm_result"
    # 删除历史数据
    if date_gap == 90:
        res_sql = f"DELETE FROM `{table_name}` WHERE instance_id = '{task_id}'"
        mysqlHp.execute(res_sql)
    # 根据 R、F 分类对用户进行统计
    summary = rfm_df.groupby(['R_group', 'F_group']).agg({
        'userid': 'count',  # 计算客户数
        'M': ['mean', 'sum']  # 计算平均每次消费金额和总消费金额
    })

    # 重命名列名
    summary.columns = ['CustomerCount', 'AverageAmount', 'TotalAmount']
    # 计算客户数占比
    # summary[ 'CustomerPercentage' ] = summary[ 'CustomerCount' ] / summary[ 'CustomerCount' ].sum()
    summary['CustomerPercentage'] = summary['CustomerCount']
    # summary[ 'CustomerPercentage' ] = summary[ 'CustomerPercentage' ].apply(lambda x: float('{:.4}'.format(x))) * 100
    for data_type, feature in enumerate(["CustomerPercentage", "AverageAmount", "TotalAmount"]):
        # 将统计结果转化为混淆矩阵, 并对列行求和
        RF_confusion_matrix = summary.pivot_table(index='R_group', columns='F_group', values=feature,
                                                  fill_value=0)
        RF_confusion_matrix = RF_confusion_matrix.reset_index()
        RF_confusion_matrix['group_sort'] = RF_confusion_matrix['R_group'].apply(lambda x: extract_number(x))
        RF_confusion_matrix.sort_values('group_sort', inplace=True)
        RF_confusion_matrix = conplement_matrix_row(RF_confusion_matrix, 'R', group_dict_result)

        # 保证列的顺序，对于累计值会错
        RF_confusion_matrix['group_sort'] = RF_confusion_matrix['R_group'].apply(lambda x: extract_number(x))
        RF_confusion_matrix.sort_values('group_sort', inplace=True)
        RF_confusion_matrix.drop(["group_sort"], inplace=True, axis=1)

        sum_columns = [r for r in list(RF_confusion_matrix) if r != 'R_group' ]
        RF_confusion_matrix['RowSums'] = RF_confusion_matrix[sum_columns].sum(axis=1)
        RF_confusion_matrix['RowSums'] = RF_confusion_matrix['RowSums'].apply(
            lambda x: str(round(x, 4))[:6]).astype(float)
        # RF_confusion_matrix.loc['ColumnSums'] = RF_confusion_matrix.sum(axis=0)
        # RF_confusion_matrix.loc['ColumnSums'] = RF_confusion_matrix.loc['ColumnSums'].round(2)
        # 打印概览分析结果
        RF_confusion_matrix = RF_confusion_matrix.rename(columns={"RowSums": "data_total"})
        RF_confusion_matrix = RF_confusion_matrix.rename(columns={"R_group": "recency_group"})
        RF_confusion_matrix["seq"] = range(1, len(RF_confusion_matrix) + 1)
        result = RF_confusion_matrix.copy()
        result.drop([ "seq" ], inplace = True, axis = 1)
        RF_confusion_matrix.drop(["data_total", "recency_group"], inplace=True, axis=1)
        # 补充列索引
        RF_confusion_matrix = complement_matrix_columns(RF_confusion_matrix, group_dict_result, "F")
        group_columns = RF_confusion_matrix.columns
        # 分组排序，保证列名顺序，并且补充没有值的列组
        sorted_columns = sorted(group_columns, key=extract_number)
        # 分组统计指标值
        for i, v in enumerate(['data_st', 'data_nd', 'data_rd', 'data_th', 'data_ve']):
            try:
                RF_confusion_matrix = RF_confusion_matrix.rename(columns={sorted_columns[i]: v})
            except Exception as E:
                print(v, "此列没有值")
                RF_confusion_matrix[v] = 0
        result.reset_index(inplace=True)
        result = pd.concat([RF_confusion_matrix, result], axis=1)

        result['frequency_group'] = ','.join(F_col_name(sorted_columns[:5]))
        result['create_user'] = user_id
        result['create_time'] = start_time
        result['deleted'] = 0

        # 系统表功能参数
        result['instance_id'] = task_id
        result['tenant_api_name'] = tenant_api
        result['cycle_category'] = period_dict[date_gap]
        result['data_type'] = data_type + 1
        table_coumns = ['instance_id', 'tenant_api_name', 'cycle_category', 'data_type',
                        'recency_group', 'frequency_group', 'data_st', 'data_nd', 'data_rd', 'data_th',
                        'data_ve', 'data_total', 'seq', 'create_user', 'create_time', 'deleted']
        result['recency_number'] = result['recency_group'].apply(extract_number)
        result.sort_values('recency_number', inplace=True)
        res = result[table_coumns]
        # print(res)
        # res.to_sql(table_name, con=mysqlHp, if_exists='append', index=False)
        mysqlHp.insert_dataframe_to_pg(df=res, table_name=table_name)
        # se_re = "select * from model_rfm_result"
        # sr = mysqlHp.query(se_re)
        # print("查询是否存入成功！")
        # print(sr)


def extract_number(string):
    # 使用正则表达式提取数字部分
    matches = re.findall(r'\d+', string)
    if matches:
        return int(matches[0])
    return float('inf')  # 若字符串中无数字，则返回无穷大，确保它排在最后


def customer_analysis(df, ta, tb, group_dict_result):
    """
    RFM 两两组合分析
    :param df:
    :param ta:
    :param tb:
    :param group_dict_result:
    :return:
    """
    # 统计 R 组下客户数和占比
    r_group = df.groupby(ta + '_group').size().reset_index(name=ta + '_Count')
    # 保证相对顺序
    # 补充行
    r_group['group_sort'] = r_group[ta + '_group'].apply(lambda x: extract_number(x))
    r_group.sort_values('group_sort', inplace=True)
    r_group = conplement_matrix_row(r_group, ta, group_dict_result)
    # 重排补充行的顺序
    r_group['group_sort'] = r_group[ta + '_group'].apply(lambda x: extract_number(x))
    r_group.sort_values('group_sort', inplace=True)
    # 计算客户占比的累计占比
    r_group[ta + '_Percentage'] = r_group[ta + '_Count'] / r_group[ta + '_Count'].sum()
    r_group[ta + '_Percentage'] = r_group[ta + '_Percentage'].apply(
        lambda x: str(round(x, 4))[:6]).astype(float) * 100

    r_group[ta + '_cumsum_count'] = r_group[ta + '_Count'].cumsum()
    r_group['Cumulative_Percentage'] = r_group[ta + '_cumsum_count'] / r_group[ta + '_Count'].sum()
    r_group['Cumulative_Percentage'] = r_group['Cumulative_Percentage'].apply(
        lambda x: str(round(x, 4))[:6]).astype(float).astype(float) * 100
    # 统计 R、F 组合下客户数和占比
    rf_group = df.groupby([ta + '_group', tb + '_group']).size().reset_index(name=ta + tb + '_Count')
    rf_group[ta + tb + '_Percentage'] = rf_group[ta + tb + '_Count'] / rf_group[ta + tb + '_Count'].sum()
    rf_group[ta + tb + '_Percentage'] = rf_group[ta + tb + '_Percentage'].apply(
        lambda x: str(round(x, 4))[:6]).astype(float) * 100
    pivot_table = pd.pivot_table(rf_group, index=ta + '_group', columns=tb + '_group',
                                 values=[ta + tb + '_Percentage'], fill_value=0)
    # 重置索引，将列名重新命名
    pivot_table = pivot_table.reset_index()
    # 对group 名字进行排序:重命名后，调整列名顺序
    group_columns = [ta + '_group'] + [f'{col[1]}' for col in pivot_table.columns[1:]]
    pivot_table.columns = group_columns
    pivot_table = complement_matrix_columns(pivot_table, group_dict_result, tb)

    sorted_columns = sorted(pivot_table.columns, key=extract_number)
    pivot_table = pivot_table[sorted_columns]
    # 合并 pivot_table 和 r_group
    result = pd.merge(r_group, pivot_table, on=ta + '_group', how='left')
    # 输出结果
    print(f"result {ta} | {tb}")
    return result, sorted_columns[:5]


def rfm_table_colums(table_columns):
    # 不同结果表对应的数据列名
    assert (table_columns in ('R', 'F', 'M'))
    if table_columns == "R":
        return ['instance_id', 'tenant_api_name', 'cycle_category', 'target', 'interval', 'field',
                'custom_num', 'custom_rate', 'custom_rate_all', 'target_one', 'target_two',
                'target_three', 'target_four', 'target_five', 'seq', 'create_user',
                'create_time', 'deleted']
    elif table_columns == "F":
        return ['instance_id', 'tenant_api_name', 'cycle_category', 'target', 'field', 'custom_num',
                'custom_rate', 'custom_rate_all', 'target_one', 'target_two', 'target_three',
                'target_four', 'target_five', 'seq', 'create_user', 'create_time', 'deleted']
    elif table_columns == "M":
        return ['instance_id', 'tenant_api_name', 'cycle_category', 'target',
                'interval', 'field_type', 'field_json', 'max_revenue', 'seq',
                'create_user', 'create_time', 'deleted']


# a当前的具体组名称， b统计的结果集， c存在的组名称与数量映射 d数据总数 e 当c为空是e为1
def setJson(a, c, d, k, b1, b2, b3, b4, b5):
    # m结果需要整合在一个json里
    # c:客户数 d:客户占比 k：累计客户占比 b：指标分组字段
    return {'field': a, 'custom_num': round(c, 4), 'custom_rate': round(d, 4), 'custom_rate_all': round(k, 4),
            'target_one': round(b1, 4), 'target_two': round(b2, 4), 'target_three': round(b3, 4),
            'target_four': round(b4, 4), 'target_five': round(b5, 4)
            }


def rfm_store_table(mysqlHp, result, group_colums, task_id, tenant_api_name, date_gap, tb, table_type, gap_type, M_max,
                    start_time, field_type, user_id, sentry):
    """
    根据RFM两两组合的分析结果，整合出使用表结构的值，并存储
    :param mysqlHp: 数据库连接
    :param result: 分析结果
    :param group_colums: 排序好的列名顺序
    :param task_id: 任务表示
    :param tenant_api_name:api标识
    :param date_gap: 计算数据日期间隔
    :param tb: 分析组
    :param table_type: 归属表类型
    :param gap_type: 分组间隔类型
    :param M_max: M最大值
    :param start_time: 计算开始时间
    :param field_type: M分组类型
    :return: 入库
    """
    # 系统表功能参数
    result['instance_id'] = task_id
    result['tenant_api_name'] = tenant_api_name
    result['cycle_category'] = period_dict[date_gap]
    result['target'] = target_dict[tb]
    if table_type != 'F':
        result['interval'] = gap_type
    # 主要统计参数
    result = result.rename(
        columns={table_type + '_group': 'field', table_type + '_Count': 'custom_num',
                 table_type + '_Percentage': 'custom_rate', 'Cumulative_Percentage': 'custom_rate_all'})

    def field_split(x):
        x, y = re.split(r'[<≤]', x)[0], re.split(r'[<≤]', x)[2]
        if int(y) - int(x) == 1:
            return y
        return '-'.join([x, y])

    result['field'] = result['field'].apply(field_split)
    # 分组统计指标值
    for i, v in enumerate(['target_one', 'target_two', 'target_three', 'target_four', 'target_five']):
        try:
            result = result.rename(columns={group_colums[i]: v})
        except Exception as E:
            print(v, "此列没有值")
            result[v] = 0

    result['seq'] = ','.join(F_col_name(group_colums))
    result['create_user'] = user_id
    result['create_time'] = start_time
    result['deleted'] = 0
    result.fillna(0, inplace=True)
    # 根据R F M不同值获取表头
    result_table = rfm_table_colums(table_type)
    table_name = ''
    if table_type == "R":
        # 将数据插入数据库表
        table_name = 'model_rfm_r'  # 数据库表名
    elif table_type == "F":
        # 将数据插入数据库表
        table_name = 'model_rfm_f'  # 数据库表名
    elif table_type == "M":
        result['field_type'] = field_type
        result['max_revenue'] = M_max
        result['field_json'] = result.apply(
            lambda x: setJson(x['field'], x['custom_num'], x['custom_rate'], x['custom_rate_all'],
                              x['target_one'], x['target_two'], x['target_three'],
                              x['target_four'], x['target_five']), axis=1)

        result = result.groupby(['instance_id', 'tenant_api_name', 'cycle_category', 'target',
                                 'interval', 'field_type', 'max_revenue', 'seq',
                                 'create_user', 'create_time', 'deleted'])['field_json'].agg(list).reset_index()
        result['field_json'] = result['field_json'].apply(lambda x: json.dumps(x))
        # 将数据插入数据库表
        table_name = 'model_rfm_m'  # 数据库表名
        # print(result[result_table])
    # 删除历史数据
    if sentry in (0, 2, 4) and gap_type in (1, -1) and field_type in (0, 1):
        res_sql = f"DELETE FROM `{table_name}` WHERE instance_id = '{task_id}'"
        mysqlHp.execute(res_sql)
    # 存储mysql中
    rfm_res = result[result_table]
    float_columns = rfm_res.select_dtypes(include=['float'])
    # 对这些浮点数列保留四位小数
    for c in float_columns:
        rfm_res[c] = rfm_res[c].round(4)
    # rfm_res.to_sql(table_name, con=mysqlHp, if_exists='append', index=False)
    mysqlHp.insert_dataframe_to_pg(df=rfm_res, table_name=table_name)
def read_database():
    # 从YAML配置文件中加载数据库连接参数
    # with open('utils/db_config.yaml', 'r') as stream:
    #     config = yaml.safe_load(stream)
    # mysql_config = config[ 'mysql' ]
    # pg_config = config[ 'postgresql' ]
    # db_config = SuperVar.getVar('database_config')
    # mysql_config = db_config['database'][ 'mysql' ]
    # pg_config = db_config['database'][ 'pgsql' ]
    # # 使用加载的配置文件创建数据库连接
    # mysqlHp = mysqlHelper.MySQLHelper(
    #     host=mysql_config['host'],
    #     port=mysql_config['port'],
    #     username=mysql_config['username'],
    #     password=mysql_config['password'],
    #     db_name=mysql_config['database'],
    #     # charset=mysql_config['charset']
    # )
    #
    # pgdb = postgreHelper.PostgreSQLDatabase(
    #     host=pg_config['host'],
    #     port=pg_config['port'],
    #     database=pg_config['database'],
    #     user=pg_config['username'],
    #     password=pg_config['password']
    # )
    mysqlHp = SuperVar.getVar("engine")
    pgdb = SuperVar.getVar("source_engine")
    return mysqlHp, pgdb

def RFM_main(task_id, tenant_api_name, flag, data_location, pid, user_id, name):
    """
    程序调度
    :param task_id:
    :param tenant_api_name:
    :param flag:
    :param data_location:
    :param pid:
    :return:
    """

    mysqlHp, pgdb = read_database()

    custom_logger.info(f"更新pid")
    try:
        # 获取任务名与创建者
        # user_id, name = select_name_and_creator(mysqlHp, task_id)
        update_log(task_id=task_id, des='任务开始执行', build_or_scoring=1,
                   state=1, error_log=None, create_user=user_id, update_user=user_id, mysqlHp=mysqlHp)
        HttpRequest.post_messeage(user_id, task_id, f'AI模型中心【{name}】任务已开始训练，点击任务管理前往查看',
                                  name, flag=1)
        state_updating(mysqlHp, task_id=task_id, state=2, progress='5.00%', pid=pid, train_end_time=None)
        start_time = pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S")
        custom_logger.info("读取数据")
        update_log(task_id=task_id, des='正在处理数据', build_or_scoring=1,
                   state=1, error_log=None, create_user=user_id, update_user=user_id, mysqlHp=mysqlHp)
        # 有些数据为空，先填空为0，也可以删掉
        data = read_data(flag, data_location, pgdb)
        update_log(task_id=task_id, des='读取数据完成', build_or_scoring=1,
                   state=1, error_log=None, create_user=user_id, update_user=user_id, mysqlHp=mysqlHp)
        # 更新截止时间
        datetime_max = data.datetime.max()
        update_max_time(mysqlHp, task_id, datetime_max)
        update_log(task_id=task_id, des='开始RFM模型训练', build_or_scoring=1,
                   state=1, error_log=None, create_user=user_id, update_user=user_id, mysqlHp=mysqlHp)
        update_log(task_id=task_id, des='RFM模型正在计算中', build_or_scoring=1,
                   state=1, error_log=None, create_user=user_id, update_user=user_id, mysqlHp=mysqlHp)
        sentry = 0  # 用于R  F  M  第一次执行，用于删除历史数据标识
        date_offset = [90, 180, 365, 730]
        for idx, date_gap in enumerate(date_offset):
            print(f"计算 {date_gap} 天前的R F M 值")
            days_d_ago = data[data['datetime'] >= datetime_max - pd.DateOffset(days=date_gap)]
            if days_d_ago.empty:
                custom_logger.info(f"计算周期{date_gap}RFM的统计值,但没有此区间的数据")
                continue
            custom_logger.info(f"计算周期{date_gap}RFM的统计值")
            rfm_df = calculate_R_F_M(days_d_ago, datetime_max)
            # 根据R F M的值进行分组
            custom_logger.info(f"对周期{date_gap}RFM的统计值进行分组")
            rfm_df_group, group_dict_result = R_F_M_group(rfm_df, -1, gap_type={}, m_type='total', date_gap=date_gap)
            R_max = rfm_df.R.max()
            F_max = rfm_df.F.max()
            M_max = M_partition_interval(rfm_df)
            print("RFM 总体概览图")
            custom_logger.info(f"计算周期{date_gap}RFM 总体概览图")
            R_F_M_analysis(rfm_df_group, mysqlHp, group_dict_result, start_time, user_id, date_gap)
            print("RFM 两两组合分析表")
            custom_logger.info(f"计算周期{date_gap}RFM 两两组合分析表")
            combine_rfm = [("R", "F"), ("R", "M"), ("F", "R"), ("F", "M"), ("M", "R"), ("M", "F")]

            state_updating(mysqlHp, task_id=task_id, state=2, progress=str((idx + 1) * 20) + '.00%', pid=pid,
                           train_end_time=None)
            for ta, tb in combine_rfm:
                custom_logger.info(f"计算周期{ta}, {tb}两两组合分析表")
                # R M分析产品可以划分不同间隔值
                if ta in ("R", "M"):
                    for gap_type in [1, 2, 3]:
                        # 对应上述rule函数的列表，分配不同间隔值
                        if ta == 'M':
                            for field_type, type in enumerate(['total', 'by_purch']):
                                print(date_gap, gap_type, field_type, type)
                                rfm_df_group, group_dict_result = R_F_M_group(rfm_df, ta, gap_type={ta: gap_type},
                                                                              m_type=type, date_gap=date_gap)
                                result, group_colums = customer_analysis(rfm_df_group, ta, tb, group_dict_result)
                                rfm_store_table(mysqlHp, result, group_colums, task_id, tenant_api_name, date_gap, tb,
                                                ta, gap_type, M_max, start_time, field_type + 1, user_id, sentry)
                        else:
                            fm_df_group, group_dict_result = R_F_M_group(rfm_df, ta, gap_type={ta: gap_type},
                                                                         m_type='total', date_gap=date_gap)
                            result, group_colums = customer_analysis(rfm_df_group, ta, tb, group_dict_result)
                            rfm_store_table(mysqlHp, result, group_colums, task_id, tenant_api_name, date_gap, tb, ta,
                                            gap_type, M_max, start_time, 0, user_id, sentry)
                else:
                    rfm_df_group, group_dict_result = R_F_M_group(rfm_df, -1, gap_type={}, m_type='total', date_gap=date_gap)
                    result, group_colums = customer_analysis(rfm_df_group, ta, tb, group_dict_result)
                    rfm_store_table(mysqlHp, result, group_colums, task_id, tenant_api_name, date_gap, tb, ta, -1,
                                    M_max, start_time, 0, user_id, sentry)
                # 在训练结束后，将 pid 字段置为空
                # 更新rfmmax
                update_rfm_max(mysqlHp, start_time, period_dict[date_gap], R_max, F_max, M_max)
                sentry = sentry + 1
    except Exception as e:
        traceback_info = traceback.format_exc()
        print(traceback_info)
        custom_logger.debug(str(e))
        messeage = f"AI模型中心【{name}】任务训练失败，点击任务管理前往查看错误日志"
        HttpRequest.post_messeage(user_id, task_id, messeage, name, flag=3)
        state_updating(mysqlHp, task_id=task_id, state=4, progress='100.00%', pid=pid,
                       train_end_time=record_processing_time())
        update_log(task_id=task_id, des='RFM任务训练错误', build_or_scoring=1,
                   state=0, error_log=None, create_user=user_id, update_user=user_id, mysqlHp=mysqlHp)
        sys.exit(1)
    custom_logger.info(f"********RFM模型分析计算结束********")
    state_updating(mysqlHp, task_id=task_id, state=3, progress='100.00%', pid=pid,
                   train_end_time=record_processing_time())
    update_log(task_id=task_id, des='RFM模型训练完成', build_or_scoring=1,
               state=1, error_log=None, create_user=user_id, update_user=user_id, mysqlHp=mysqlHp)
    HttpRequest.post_messeage(user_id, task_id, f'AI模型中心【{name}】任务训练完成，点击任务管理前往查看训练结果',
                              name, flag=2)
    update_log(task_id=task_id, des='RFM任务完成', build_or_scoring=1,
                   state=1, error_log=None, create_user=user_id, update_user=user_id, mysqlHp=mysqlHp)

def rfm_start():
    # args = parse_arguments()
    # task_id = args.task_id
    # tenant_api = args.tenant_api
    # flag = args.flag
    # data_location = args.data_location
    pid = os.getpid()
    global task_id
    global tenant_api
    task_id = SuperVar.getVar('task_id')
    task_name = SuperVar.getVar('task_name')
    tenant_api = SuperVar.getVar('tenant')
    predict_id = SuperVar.getVar('predict_id')
    flag = SuperVar.getVar('filetype')
    data_location = SuperVar.getVar('location')
    creator = SuperVar.getVar('creator')
    global  custom_logger
    custom_logger=read_log()
    RFM_main(task_id, tenant_api, flag, data_location, pid, creator, task_name)

def parse_arguments():
    """
    后台传参
    :return:
    """
    parser = argparse.ArgumentParser(description='Script description')
    parser.add_argument('-t', '--task_id', type=str, required=True, help='Task ID')
    parser.add_argument('-ten', '--tenant_api', type=str, required=True, help='Tenant API')
    parser.add_argument('-f', '--flag', type=str, required=True, choices=["1", "2"],
                        help='Flag, 1: 建模数据集，2:上传文件数据集')
    parser.add_argument('-l', '--data_location', type=str, required=True, help='根据flag，对应表名或路径')
    return parser.parse_args()


# if __name__ == '__main__':
#     # 接收脚本传递过来的建模参数
#
#     args = parse_arguments()
#     task_id = args.task_id
#     tenant_api = args.tenant_api
#     flag = args.flag
#     data_location = args.data_location
#     pid = os.getpid()
#     # 主实体
#     # flag = "2"
#     # # data_location = r"./data/RFM订单数据.xlsx"
#     # data_location = r"./data/RFM订单数据大金额.csv"
#     # tenant_api = 't100059'
#     # task_id = '756a8261-59b1-4b05-a5e3-aafa1a04c54a'
#
#     custom_logger.info("读取当前环境参数")
#     # python rfm.py -t 5c9439f4-a3cc-4291-89b7-551d83564d07d -ten t100010d -f 2 -l ./data/RFM.csv
#     # 在这里执行你的脚本逻辑
#     print(f'Task ID: {task_id}')
#     print(f'Tenant API: {tenant_api}')
#     print(f'Flag: {flag}')
#     print(f'Data Location: {data_location}')
#
#     RFM_main(task_id, tenant_api, flag, data_location, pid)
