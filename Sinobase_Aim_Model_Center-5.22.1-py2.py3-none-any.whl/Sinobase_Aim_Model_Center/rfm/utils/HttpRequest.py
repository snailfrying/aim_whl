# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :HttpRequest.py

@Time      :2023/09/18 14:30

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
from Sinobase_Aim_Model_Center.model_util import SuperVar

import time
import yaml
import json
import requests
from loguru import logger

def gettoken( url, clientId, clientSecret ):
    response = requests.get(url, params = {'clientId':clientId, 'clientSecret':clientSecret})
    redata = json.loads(response.text)
    return redata.get("data")

def create_rt_alarm( id, content, user ):
    data = {}
    data[ 'alarm_id' ] = id
    data[ 'content_var' ] = content
    data[ 'user_var' ] = user
    return data

def createAlarm( url, token, data ):
    headers = {'Authorization':token, 'Content-Type':'application/json', 'Accept':'application/json'}
    # 将data字典转换为JSON字符串
    data_json = json.dumps(data)
    response = requests.post(url, headers = headers, data = data_json)
    logger.info(response.text)

def post_messeage(creator, task_id, content, title, flag):
    # with open('utils/warnning.yaml', 'r') as config_file:
    #     config = yaml.safe_load(config_file)
    # 从家豪创造的superval获取
    config =  SuperVar.getVar('alarm_config')
    task_id =  task_id
    content = {"title": title,
               "content":task_id + content,
               'time':time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
    user = {"creator":creator}
    id = 'model_center_0' + str(flag)
    data = create_rt_alarm(id, content, user)
    # get token
    token_params = {
        'url': 'https://dev-mip.smartone.net.cn/auth/mipApp/token/getToken',
        'clientId': 'user_client',
        'clientSecret': '$2a$10$BurTWIy5NTF9GJJH4magz.9Bd4bBurWYG8tmXxeQh1vs7r/wnCFG2'
    }
    token = gettoken(**token_params)
    if config[ 'alarm' ][ 'open' ]:
        createAlarm(config[ 'alarm' ][ 'alarmurl' ], token, data)

if __name__ == '__main__':
    post_messeage('json', '1', 'rfm 程序执行完成！', 'rfm model process', 1)
    # url = 'https://dev-mip.smartone.net.cn/auth/mipApp/token/getToken'
    # clientId = 'user_client'
    # clientSecret = '$2a$10$BurTWIy5NTF9GJJH4magz.9Bd4bBurWYG8tmXxeQh1vs7r/wnCFG2'
    # data = gettoken(url, clientId, clientSecret)
    # print(data)
    pass