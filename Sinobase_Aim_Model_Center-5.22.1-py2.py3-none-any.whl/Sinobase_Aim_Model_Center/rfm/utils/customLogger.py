#!/usr/bin/env python3
# -*- coding: utf-8 _*_

"""
    @Author: json
    @Time: 2023/8/29 16:05
    @Describe
    @Version 1.0
"""
import sys
from loguru import logger as loguru_logger


class CustomLogger:
    def __init__(self, log_config, model_name, status_name):
        self.name = model_name
        self.logger = loguru_logger
        self.log_config = log_config["LogConfig"]
        self.model_name = model_name
        self.status_name = status_name
        self.logger_format = "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | " \
                             "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - {message}"

        self.logger.remove()  # Remove any default logger sinks
        # self.logger.add("log/{}.log".format(self.name), level="DEBUG", format=self.logger_format, enqueue=True)
        # self.logger.add(sys.stdout, level="DEBUG", format=self.logger_format)
        if self.log_config['OpenConsole'] == 'True':
            # 控制台输出
            self.logger.add(sys.stderr, level=self.log_config['ConsoleLog_Level'], format=self.logger_format)

        if self.log_config['OpenDebug'] == 'True':
            # 输入到Debug文件
            debuglog_filename = self.model_name + '-' + '{time:YYYY-MM-DD}.debug_' + self.status_name + self.log_config[
                'LogName']
            self.logger.add(self.log_config['Debug_path'] + '/' + debuglog_filename,
                            filter=lambda record: record["level"].name == "DEBUG",
                            rotation="00:00", compression="zip", encoding=self.log_config['Log_Coding'], format=self.logger_format)

        # 输入到文件
        log_filename = self.model_name + '-' + '{time:YYYY-MM-DD}.' + self.status_name + self.log_config['LogName']
        self.logger.add(self.log_config['Log_path'] + '/' + log_filename,
                        filter=lambda record: record["level"].name <= self.log_config['Log_Level'] and record[
                            "level"].name != "DEBUG",
                        rotation="00:00", compression="zip", encoding=self.log_config['Log_Coding'], format=self.logger_format)

    def info(self, message):
        self.logger.info(message, name=self.name)

    def debug(self, message):
        self.logger.debug(message, name=self.name)

    def warning(self, message):
        self.logger.warning(message, name=self.name)

    def error(self, message):
        self.logger.error(message, name=self.name)

    def critical(self, message):
        self.logger.critical(message, name=self.name)


# 使用自定义日志类
# if __name__ == '__main__':
#     custom_logger = CustomLogger("my_module")
#
#     custom_logger.info("这是一条信息")
#     custom_logger.debug("这是一条调试信息")
#     custom_logger.warning("这是一条警告")
#     custom_logger.error("这是一条错误")
#     custom_logger.critical("这是一条严重错误")
