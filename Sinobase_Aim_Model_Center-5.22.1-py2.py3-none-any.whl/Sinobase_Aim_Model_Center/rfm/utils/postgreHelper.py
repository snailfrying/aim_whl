# #!/usr/bin/env python3
# # -*- coding: utf-8 _*_
#
# """
#     @Author: json
#     @Time: 2023/6/6 9:50
#     @Describe
#     @Version 1.0
# """
import psycopg2
from sqlalchemy import create_engine
from sqlalchemy.pool import NullPool
class PostgreSQLDatabase:
    def __init__(self, host, port, database, user, password):
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        self.connection = None
        self.engine = create_engine(f'postgresql+psycopg2://{user}:{password}@{host}:{port}/{database}',
                                    poolclass=NullPool)

    def connect(self):
        try:
            self.connection = psycopg2.connect(
                host=self.host,
                port=self.port,
                database=self.database,
                user=self.user,
                password=self.password
            )
            print("Connected to the PostgreSQL database.")
        except psycopg2.Error as e:
            print("Error connecting to the PostgreSQL database:", e)

    def close(self):
        if self.connection is not None:
            self.connection.close()
            print("Connection to the PostgreSQL database closed.")

    def get_tables(self):
        if self.connection is not None:
            cursor = self.connection.cursor()
            cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public';")
            tables = cursor.fetchall()
            cursor.close()
            return [table[0] for table in tables]
        else:
            print("Not connected to the PostgreSQL database.")

    def execute_query(self, query):
        if self.connection is not None:
            cursor = self.connection.cursor()
            cursor.execute(query)
            result = cursor.fetchall()
            # 将结果转换为DataFrame
            columns = [desc[0] for desc in cursor.description]
            cursor.close()
            return columns, result
        else:
            print("Not connected to the PostgreSQL database.")

    def execute_update(self, query):
        if self.connection is not None:
            cursor = self.connection.cursor()
            cursor.execute(query)
            self.connection.commit()
            cursor.close()
            print("Update executed successfully.")
        else:
            print("Not connected to the PostgreSQL database.")

# 示例用法
# if __name__ == '__main__':
# db = PostgreSQLDatabase(host='10.88.10.25', port='5432', user='postgres', password='postgres', database='aim_model')
# db.connect()
# # 查看数据库中的表
# tables = db.get_tables()
# print("Tables in the database:", tables)

# 执行查询
# query = "SELECT * FROM your_table;"
# result = db.execute_query(query)
# print("Query result:", result)

# db.close()
