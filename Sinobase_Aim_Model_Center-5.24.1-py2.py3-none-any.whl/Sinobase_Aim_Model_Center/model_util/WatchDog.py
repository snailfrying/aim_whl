# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :WatchDog.py

@Time      :2023/6/25 11:04

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

import os


def WatchDog(fn):
    # 获取

    print(os.path.basename(__file__).split('.')[0])
    print(fn.__name__)

    def sayspam(*args):
        fn(*args)

    return sayspam


@WatchDog
def hello():
    print('hello')


if __name__ == '__main__':
    hello()
