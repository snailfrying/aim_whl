# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :sql_log.py

@Time      :2023/8/1 9:24

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
import time as ti
from Sinobase_Aim_Model_Center.model_util import SuperVar

def insertSqlLog(task_id, des, build_or_scoring, state, error_log, engine, create_time):
    import pytz
    from datetime import datetime
    shanghai_tz = pytz.timezone('Asia/Shanghai')

    # 获取上海时区的当前时间
    shanghai_time = datetime.now(shanghai_tz)
    the_time = shanghai_time.strftime('%Y-%m-%d %H:%M:%S')
    if SuperVar.getVar("System_info") != 'User':
        engine.execute(
            sql="""INSERT INTO model_log (task_id, time,des, build_or_scoring, state,error_log,create_time,update_time, deleted) value ('%s','%s','%s','%s','%s','%s','%s','%s','%s')""" % (
                task_id, the_time, des, str(build_or_scoring), str(state), str(error_log).replace('\'','\\"'),
                create_time,
                create_time, '0'))
