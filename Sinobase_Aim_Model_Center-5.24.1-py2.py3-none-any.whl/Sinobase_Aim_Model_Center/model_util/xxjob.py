# # -*- coding:utf-8 -*-
# #                 ____                                       _____  __
# #                /\  _`\                                    /\___ \/\ \
# #                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___
# #                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\
# #                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \
# #                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
# #                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
# #                                                      /\______\
# #                                                      \/______/
# '''
# @FileName  :xxjob.py
#
# @Time      :2023/5/22 14:46
#
# @Author    :Guan_jh
#
# @Email     :guan_jh@qq.com
#
# @Describe  :
# '''
#
# import asyncio
#
# from pyxxl import ExecutorConfig, PyxxlRunner
#
# def xxjobConfig(xxjobconfig):
#     config = ExecutorConfig(
#         # xxl_admin_baseurl="http://localhost:8080/xxl-job-admin/api/",
#         # executor_app_name="xxl-job-executor-sample",
#         # executor_host="172.17.0.1",
#         xxl_admin_baseurl=xxjobconfig['baseurl'],
#         executor_app_name=xxjobconfig['app_name'],
#         executor_port=9134,
#         executor_log_path=xxjobconfig['log']
#         # executor_host=xxjobconfig['executor_host']
#     )
#
#     app = PyxxlRunner(config)
#
#
#     # @app.handler.register(name="hello")
#     # async def test_task():
#     #     print("demoJobHandler")
#     #     return "成功..."
#
#
#     # 如果你代码里面没有实现全异步，请使用同步函数，不然会阻塞其他任务
#     @app.handler.register(name="test")
#     def test_task3():
#         print("test")
#         return "成功3"
#
#
#     app.run_executor()
#
#
