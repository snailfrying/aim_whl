# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :CalLoss.py

@Time      :2023/5/19 10:50

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

from sklearn import metrics

from loguru import logger


@logger.catch
def cal(effective_test, predict_test, type):
    y = effective_test
    # print(y)
    y_hat = predict_test
    loss = []
    # print(y_hat)
    if type =='classier':
        fpr, tpr, threshold = metrics.roc_curve(y, y_hat)
        score = metrics.accuracy_score(y, y_hat)
        auc = metrics.auc(fpr, tpr)
        recall = metrics.recall_score(y, y_hat)
        f1_score = metrics.f1_score(y, y_hat)

        # auc2f1_score3精确率4召回率
        loss.append(auc)
        loss.append(f1_score)
        loss.append(score)
        loss.append(recall)
    # print(MSE, RMSE, MAE, MAPE, score, auc)
    elif type =='regress':
        R2 = metrics.r2_score(y, y_hat)
        MSE = metrics.mean_squared_error(y, y_hat)
        RMSE = metrics.mean_squared_error(y, y_hat) ** 0.5
        # MAE = metrics.mean_absolute_error(y, y_hat)
        # MAPE = metrics.mean_absolute_percentage_error(y, y_hat)
        loss.append(R2)
        loss.append(MSE)
        loss.append(RMSE)
    return loss
