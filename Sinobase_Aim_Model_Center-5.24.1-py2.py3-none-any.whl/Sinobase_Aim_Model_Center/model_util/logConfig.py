# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :logging.py

@Time      :2023/5/18 10:32

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

from loguru import logger
import sys
import time


def Createlogging(logconfig, model_name, statusname):
    # 初始化
    logger.remove()
    log_filename = model_name + '-' + '{time:YYYY-MM-DD}.' + statusname + logconfig['LogName']
    debuglog_filename = model_name + '-' + '{time:YYYY-MM-DD}.debug_' + statusname + logconfig['LogName']

    if logconfig['OpenConsole'] == 'True':
        # 控制台输出
        logger.add(sys.stderr, level=logconfig['ConsoleLog_Level'])

    if logconfig['OpenDebug'] == 'True':
        # 输入到Debug文件
        logger.add(logconfig['Debug_path'] + '/' + debuglog_filename,
                   filter=lambda record: record["level"].name == "DEBUG",
                   rotation="00:00", compression="zip", encoding=logconfig['Log_Coding'])
    # 输入到文件
    logger.add(logconfig['Log_path'] + '/' + log_filename,
               filter=lambda record: record["level"].name <= logconfig['Log_Level'] and record["level"].name != "DEBUG",
               rotation="00:00", compression="zip", encoding=logconfig['Log_Coding'])

    return logger



