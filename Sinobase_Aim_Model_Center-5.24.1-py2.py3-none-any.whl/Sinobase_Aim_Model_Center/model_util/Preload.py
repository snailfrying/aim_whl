# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :Preload.py

@Time      :2023/5/18 11:52

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

from Sinobase_Aim_Model_Center.model_util import logConfig, loadConfig, sqlPlugin, SuperVar
from Sinobase_Aim_Model_Center.model_util.paths import get_config_path


def PerLoad(task_id, status_name, log_config):
    # 读取配置文件
    loadconfig = loadConfig.loadConfig()
    sql_config_path = get_config_path(SuperVar.getVar('sql_connect_path'))
    sql_connects = loadconfig.get_config(sql_config_path)
    # 生成日志
    logger = logConfig.Createlogging(log_config['LogConfig'], task_id, status_name)
    logger.info("")
    logger.info("============================日志开始记录=================================")
    return logger, sql_connects


def sql_init(config, sqlconnection):
    print(sqlconnection)
    return sqlPlugin.Usesql(host=config['host'], port=config['port'], username=config['username'],
                            password=config['password'],
                            database=config['database'], connection=sqlconnection, ssl=config['ssl'])
