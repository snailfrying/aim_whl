# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :predict.py

@Time      :2023/11/02 09:47

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
import os
import sys
import time
import datetime
from pathlib import Path
import joblib
import numpy as np
import pandas as pd

from Sinobase_Aim_Model_Center.model_util import SuperVar, HttpRequest, sql_log, logConfig
from Sinobase_Aim_Model_Center.model_util.Rt_Alarm import create_rt_alarm
from Sinobase_Aim_Model_Center.model_util import loadScriptConstructor

from sklearn.linear_model import LogisticRegression, LassoCV

def predict():
    SuperVar.setVar("system_type", "predict")
    task_id = SuperVar.getVar("task_id")
    # 生成日志
    log_config = SuperVar.getVar('log_config')
    logger = logConfig.Createlogging(log_config['LogConfig'], task_id, 'predict')
    logger.info("")
    logger.info("============================正在使用预测=================================")
    logger.info("============================日志开始记录=================================")
    if SuperVar.getVar("System_info") == 'User':
        logger.info("============================用户使用mock=================================")
        file_path = SuperVar.getVar("file_path")
        start_json = SuperVar.getVar("start_json")
        try:
            sourcedata = pd.read_csv(file_path)
            SuperVar.setVar("sourcedata", sourcedata)
        except Exception as e:
            print(e)
            print("mock文件不存在")
            sys.exit(0)
        if os.path.exists(start_json['model_path']):
            SuperVar.setVar("model_path", start_json['model_path'])
        else:
            print("mock模型不存在")
            sys.exit(0)
    else:
        if SuperVar.getVar("base_config")['databricks']:
            start_json = SuperVar.getVar("start_json")
            # if 'model_name' in start_json.keys():
            #     model_name = start_json['model_name']
            #     SuperVar.setVar("model_name", model_name)
            # else:
            #     logger.error(
            #         "由于base_config中databricks状态为TRUE,因此预测将使用在线集群,请配置model_name,output_table_path在json中")
            #     sys.exit(0)
            if 'output_table_path' in start_json.keys():
                output_table_path = start_json['output_table_path']
                SuperVar.setVar("output_table_path", output_table_path)
            else:
                logger.error(
                    "由于base_config中databricks状态为TRUE,因此预测将使用在线集群,请配置model_name,output_table_path在json中")
                output_table_path = "/dbfs/FileStore/batch-inference/" + task_id + "_" + datetime.datetime.now().strftime(
                    "%Y%m%d%H%M%S") + ".csv"
                logger.error(output_table_path)
                SuperVar.setVar("output_table_path", output_table_path)
                # sys.exit(0)

    SuperVar.setVar("logger", logger)
    task_id = SuperVar.getVar("task_id")
    open_alarm = SuperVar.getVar("open_alarm")
    logger = SuperVar.getVar("logger")
    filetype = SuperVar.getVar("filetype")
    model_config = SuperVar.getVar("model_config")
    source_engine = SuperVar.getVar("source_engine")
    location = SuperVar.getVar("location")
    tenant = SuperVar.getVar("tenant")
    engine = SuperVar.getVar("engine")
    create_time = SuperVar.getVar("create_time")
    predict_id = SuperVar.getVar("predict_id")
    alarm_config = SuperVar.getVar("alarm_config")

    if open_alarm:
        logger.info("实时预警开启")
        #     获取token
        token = HttpRequest.gettoken(alarm_config['alarm']['url'], alarm_config['alarm']['clientId'],
                                     alarm_config['alarm']['clientSecret'])
        model_config['token'] = token
        SuperVar.setVar("token", token)
        logger.debug("token获取成功")
        logger.debug(token)
    else:
        logger.info("实时预警关闭")

    # if open_alarm:
    #     content = {"title": task_name,
    #                'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
    #     user = {"creator": creator}
    #     HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
    #                             create_rt_alarm('model_center_01', content, user))
    sql_log.insertSqlLog(task_id, '预测任务开始', '2', '1', '', engine, create_time)
    sql_log.insertSqlLog(task_id, '正在获取预测数据', '2', '1', '', engine, create_time)
    # 获取创建者
    # creator = engine.execute(
    #     sql="""select user_id from model_instance where id = '%s'""" % task_id).values.tolist()[
    #     0][0]
    # 获取训练名称
    # task_name = engine.execute(
    #     sql="""select name from model_instance where id='%s'""" % task_id).values.tolist()[
    #     0][0]
    #
    #
    # # 获取数据
    # # try:
    if SuperVar.getVar("System_info") == 'User':
        sourcedata = SuperVar.getVar("sourcedata")
    else:
        if filetype == 1:
            logger.debug("""select * from %s.%s""" % (tenant, location))
            sourcedata = source_engine.execute(sql="""select * from %s.%s""" % (tenant, location))
        elif filetype == 2 or filetype == 3:
            sourcedata = pd.read_csv(location)
        SuperVar.setVar("sourcedata", sourcedata)
    logger.info('location' + str(location))
    task_name = SuperVar.getVar('task_name')
    creator = SuperVar.getVar("creator")

    logger.debug(sourcedata)
    feature = engine.execute(
        sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % task_id)
    SuperVar.setVar("feature", feature)

    # params = engine.execute(sql="""select * from model_instance where id = '%s'""" % task_id)
    #
    # dataXvar = feature.loc[feature['feature_type'] == '字符型变量']
    #
    # for i, j in zip(dataXvar['feature_name'], dataXvar['id']):
    #     sourcedata[i] = pd.get_dummies(sourcedata[i]).astype(int).apply(lambda x: ''.join(x.astype(str)), axis=1)

    # ------------------------------
    params = engine.execute(sql="""select * from model_instance where id = '%s'""" % task_id)
    sql_log.insertSqlLog(task_id, '预测数据获取完成', '2', '1', '', engine, create_time)
    sql_log.insertSqlLog(task_id, '数据预处理中', '2', '1', '', engine, create_time)
    SuperVar.setVar("dataID", "thisID")
    if SuperVar.getVar("System_info") != 'User':

        logger.info("开始使用系统脚本处理数据")
        # 系统模板脚本处理
        baseconfig = SuperVar.getVar("base_config")
        if baseconfig['system_script']:
            default_feature_path = Path(__file__).parent.parent / 'model_center' / 'Feature_Engineering'
            featurepath = 'default'
            featurepathpy = featurepath + '.py'
            featurepathpyc = featurepath + '.pyc'
            system_default = default_feature_path / featurepathpy
            if not os.path.exists(system_default):
                system_default = default_feature_path / featurepathpyc
            loadScriptConstructor.Script_System(system_default)
        logger.info("外部脚本处理数据已经完成")
        logger.info("开始使用用户脚本处理数据")

        caller = SuperVar.getVar('main_file')
        if caller != 'GuanJiahao':
            loadScriptConstructor.Script_seq(caller)
            logger.info("用户脚本处理数据已经完成")
        else:
            logger.info("没有发现用户脚本无法处理")
        sourcedata = SuperVar.getVar("sourcedata")
        # 页面处理
        logger.info("开始处理页面勾选数据")
        # Todo 以页面数据为准
        feature = engine.execute(
            sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % task_id)
        org_feature_list = feature.loc[feature['feature_type'].isin(['字符型变量', '数值型变量'])][
            'feature_name'].values.tolist()

        model_id = feature.loc[feature['feature_type'].isin(['ID'])]['feature_name'].values.tolist()[0]

        model_user_id = sourcedata[model_id]
        sourcedata = sourcedata[org_feature_list]
        SuperVar.setVar("sourcedata", sourcedata)
        # out_list = SuperVar.getVar('out_list')
        # for i in out_list:
        #     sourcedata = sourcedata.drop(i, axis=1)
        #     logger.info('排除字段:' + str(i))
        #     feature_id = feature.query(f'feature_name == "{i}"')['id'].values.tolist()[0]
        #     engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % feature_id)
        logger.info("页面勾选处理已经完成")
    else:
        logger.info("正在处理数据")
        SuperVar.setVar("dataID", "thisID")
        SuperVar.setVar("sourcedata", sourcedata)

        caller = SuperVar.getVar('main_file')
        if caller != 'GuanJiahao':
            loadScriptConstructor.Script_seq(caller)
            logger.info("用户脚本处理数据已经完成")
        else:
            logger.info("没有发现用户脚本无法处理")
        logger.info("数据处理完成")
    sourcedata = SuperVar.getVar("sourcedata")
    dataX = sourcedata
    # dataXvar = feature.loc[feature['feature_type'] == '字符型变量']
    #
    # for i, j in zip(dataXvar['feature_name'], dataXvar['id']):
    #     sourcedata[i] = pd.get_dummies(sourcedata[i]).astype(int).apply(lambda x: ''.join(x.astype(str)), axis=1)
    #     # 进入特征处理
    # params = engine.execute(sql="""select * from model_instance where id = '%s'""" % task_id)
    # # OneHot编码，
    # var_onehot = params['var_onehot']
    # var_group = params['var_group']
    # dataXvar = feature.loc[feature['feature_type'] == '字符型变量']
    # for i in dataXvar['feature_name']:
    #     if int(var_onehot):
    #         sourcedata[i] = pd.get_dummies(sourcedata[i]).astype(int).apply(lambda x: ''.join(x.astype(str)),
    #                                                                         axis=1)
    #     # Todo 变量值分组
    #     if int(var_group):
    #         li = sourcedata[i].values.tolist()

    #         li = list(set(li))
    #         replace_dict = {}
    #         for m in range(len(li)):
    #             replace_dict[li[m]] = m
    #         sourcedata[i] = sourcedata[i].replace(replace_dict)
    #
    # dataXint = feature.loc[feature['feature_type'] == '数值型变量']
    # # 缺失值填充方法
    # num_fill = params['num_fill']
    # # 是否使用数据交换
    # num_swap = params['num_exchange']
    # for i in dataXint['feature_name']:
    #     # 均值填充
    #     if int(num_fill) == 1:
    #         sourcedata[i].fillna(sourcedata[i].mean(), inplace=True)
    #     #     大
    #     if int(num_fill) == 2:
    #         sourcedata[i].fillna(sourcedata[i].max(), inplace=True)
    #     #     小
    #     if int(num_fill) == 3:
    #         sourcedata[i].fillna(sourcedata[i].min(), inplace=True)
    #     #     0
    #     if int(num_fill) == 4:
    #         sourcedata[i].fillna(0, inplace=True)
    #     # 数值变换
    #     if int(num_swap):
    #         sourcedata[i + '_stand'] = sourcedata[i].apply(
    #             lambda x: (x - np.mean(sourcedata[i])) / np.std(sourcedata[i]))
    #         sourcedata[i + '_normal'] = sourcedata[i].apply(
    #             lambda x: (x - np.min(sourcedata[i])) / (np.max(sourcedata[i]) - np.min(sourcedata[i])))
    #         sourcedata[i + '_log'] = sourcedata[i].apply(lambda x: 0 if x <= 0 else np.log(x))
    #         # sourcedata[i + '_sqrt'] = sourcedata[i].apply(lambda x: np.sqrt(x))

    # dataXname = feature.loc[feature['feature_type'].isin(['字符型变量', '数值型变量'])]

    # 查看目标变量是否存在，如果存在删除掉，否则继续
    # if SuperVar.getVar("System_info") != 'User':
    #     feature = SuperVar.getVar("feature")
    #     Yname = feature.loc[feature['feature_type'].isin(['目标变量'])]
    #     if Yname.loc[1, 'feature_name'] in sourcedata.columns:
    #         logger.info("目标变量存在")
    #         # sourcedata.drop(Yname['feature_name'], axis=1)
    #         del sourcedata[Yname.loc[1, 'feature_name']]
    #     logger.debug(sourcedata.columns)
    #     # print(sourcedata.columns)
    #     try:
    #         dataID = feature.loc[feature['feature_type'] == 'ID']['feature_name'].values[0]
    #         if dataID in sourcedata.columns:
    #             sourcedata.drop([dataID], axis=1)
    #     except Exception as e:
    #         print(e)
    #         pass
        # dataXnotname = feature.loc[feature['feature_type'].isin(['ID'])]
        # dataX = sourcedata.drop(dataXnotname['feature_name'], axis=1)
    # sourcedata = sourcedata.drop(['ID', '排除'], axis=1)  # 删除id和y列

    #

    if SuperVar.getVar("System_info") != 'User':
        use_ass_id = engine.execute(sql="""select ass_id from model_assessment where task_id = '%s' and `use`=1 and deleted = 0""" % (
            task_id))
        the_use_ass_id = use_ass_id.values.tolist()[0][0]
        # print(the_use_ass_id)
        sql_log.insertSqlLog(task_id, '数据预处理完成', '2', '1', '', engine, create_time)
        # 获取模型路径
        sql_log.insertSqlLog(task_id, '正在获取使用模型', '2', '1', '', engine, create_time)
    if SuperVar.getVar("System_info") == 'User':
        model_path = SuperVar.getVar("model_path")
    else:
        model_path = engine.execute(sql="""select model_path from model_map where task_id = '%s' and ass_id='%s' """ % (
            task_id, the_use_ass_id))
        model_path = model_path.values.tolist()[0][0]
    # sql_log.insertSqlLog(task_id, '使用模型的路径为 {' + model_path + '}', '2', '1', '', engine, create_time)
    logger.debug(model_path)
    if not SuperVar.getVar("base_config")['databricks']:
        try:
            model = joblib.load(model_path)
            sql_log.insertSqlLog(task_id, '获取模型成功', '2', '1', '', engine, create_time)
            logger.info("获取模型成功")
        except Exception as e:
            logger.error("获取模型失败")
            sql_log.insertSqlLog(task_id, '获取模型失败', '2', '0', e, engine, create_time)
            if open_alarm:
                content = {"title": task_name,
                           "databasename": location,
                           'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
                user = {"creator": creator}
                HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                        create_rt_alarm('model_application_02', content, user))
            sys.exit()
    else:
        model_name = task_id
        # 获取当前use的版本
        version = engine.execute(
            sql="""select version from model_assessment where task_id = '%s' and ass_id='%s' """ % (
                task_id, the_use_ass_id))

        version = version.values.tolist()[0][0]

        version = version.split(" ")[1]
        logger.info(version)
        model_databricks_path = f"models:/{model_name}/{version}"
        logger.info("获取模型成功")

    logger.info("开始预测")
    sql_log.insertSqlLog(task_id, '开始预测', '2', '1', '', engine, create_time)
    try:

        # 保证顺序一致
        dataX = dataX.sort_index(axis=1, ascending=False)
        base_config = SuperVar.getVar("base_config")
        if base_config['databricks'] and SuperVar.getVar("System_info") != 'User':
            import mlflow
            from pyspark.sql.functions import struct
            from databricks.sdk.runtime import spark
            model_name = task_id
            output_table_path = SuperVar.getVar("output_table_path")
            # output_table_path = "/FileStore/batch-inference/test_aim"
            # table = spark.table(input_table_name)
            table = spark.createDataFrame(dataX)
            logger.info(table)
            model_uri = model_databricks_path
            # MLflow注册模型时指定特定的 Azure Databricks 域名
            predict = mlflow.pyfunc.spark_udf(spark, model_uri, result_type="double")
            output_df = table.withColumn("prediction", predict(struct(*table.columns)))

            sql_log.insertSqlLog(task_id, '模型预测完成', '2', '1', '', engine, create_time)
            logger.info('模型预测完成')
            logger.info(output_table_path)
            # 会造成相对顺序变化
            # output_df_single_partition = output_df.coalesce(1)
            file_name = task_id.replace('-', '_') + '_' + predict_id
            # output_df_single_partition.write.format("csv") \
            #     .option("header", "true") \
            #     .mode("overwrite") \
            #     .save(f"{output_table_path}/{file_name}.csv")
            pandas_df = output_df.toPandas()
            pandas_df[ 'user_id' ] = model_user_id
            # 保存为 CSV 文件
            pandas_df.to_csv(f"{output_table_path}/{file_name}.csv", index=False)
            logger.info("模型输出完成")
            logger.info(pandas_df.shape)
            engine.execute(sql="""UPDATE model_pre_lib set `status` = 1 where pre_id='%s'""" % predict_id)
            sql_log.insertSqlLog(task_id, '预测完成', '2', '1', '', engine, create_time)
            logger.info("运行结束")
            if open_alarm:
                content = {"title": task_name,
                           "databasename": location,
                           'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
                user = {"creator": creator}
                HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                        create_rt_alarm('model_application_01', content, user))
            return
        else:
            # print("预测用")
            # print(dataX.columns.to_list())
            y_pre = model.predict(dataX)
            sql_log.insertSqlLog(task_id, '模型预测完成', '2', '1', '', engine, create_time)
            logger.info('模型预测完成')

    except Exception as e:
        logger.error("模型预测失败")
        logger.error(e)
        sql_log.insertSqlLog(task_id, '模型预测失败', '2', '0', e, engine, create_time)
        if open_alarm:
            content = {"title": task_name,
                       "databasename": location,
                       'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
            user = {"creator": creator}
            HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                    create_rt_alarm('model_application_01', content, user))
        sys.exit()
    try:
        y_pre_df = pd.DataFrame(y_pre)
        y_pre_df.columns = ['LABEL']
        pre_result = pd.concat([sourcedata, y_pre_df], axis=1)

        logger.debug(dataX.shape)
        logger.debug(y_pre_df.shape)
        logger.debug(pre_result)
        if filetype != 3:
            if SuperVar.getVar("System_info") != 'User':
                # 模型路径
                model_path = model_config['model'][
                                 'savepath'] + '/' + tenant + '/' + task_id + '/' + predict_id + '/' + 'model_predict_' + predict_id + '.csv'
                model_dir = model_config['model']['savepath'] + '/' + tenant + '/' + task_id + '/' + predict_id

                logger.info('保存路径')
                logger.debug(model_dir)
                logger.info(model_path)

                if not os.path.exists(model_dir):
                    os.makedirs(model_dir)

                pre_result.to_csv(model_path, encoding='utf-8', index=False)
            else:
                logger.info('输出结果')
                print(pre_result)
        else:
            logger.info('输出结果')
            # 将dataframe  pre_result转换成json格式
            pre_result_json = pre_result.to_json(orient='records')
        engine.execute(sql="""UPDATE model_pre_lib set `status` = 1 where pre_id='%s'""" % predict_id)

        logger.info('模型输出完成')
        sql_log.insertSqlLog(task_id, '预测完成', '2', '1', '', engine, create_time)
        logger.info("运行结束")
        if open_alarm:
            content = {"title": task_name,
                       "databasename": location,
                       'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
            user = {"creator": creator}
            HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                    create_rt_alarm('model_application_01', content, user))
        sys.exit(0)
    except Exception as e:
        logger.error("运行出错")
        sql_log.insertSqlLog(task_id, '预测失败', '2', '0', e, engine, create_time)
        if open_alarm:
            content = {"title": task_name,
                       "databasename": location,
                       'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
            user = {"creator": creator}
            HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                    create_rt_alarm('model_application_02', content, user))
        logger.error(e)
    finally:
        sys.exit(0)
