# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :train.py

@Time      :2023/11/02 09:48

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''

import datetime
import sys
import time
import importlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from Sinobase_Aim_Model_Center.model_util import SuperVar, HttpRequest, sql_log, GetData, CreateId, load, \
    runScript, logConfig, dfutil
from Sinobase_Aim_Model_Center.model_util.Rt_Alarm import create_rt_alarm
from Sinobase_Aim_Model_Center.model_util.paths import get_alg_root


def train_system():
    SuperVar.setVar("system_type", "train")
    task_id = SuperVar.getVar("task_id")
    # 生成日志
    log_config = SuperVar.getVar('log_config')
    logger = logConfig.Createlogging(log_config['LogConfig'], task_id, 'train')
    logger.info("")
    logger.info("============================日志开始记录=================================")
    SuperVar.setVar("logger", logger)

    open_alarm = SuperVar.getVar("open_alarm")
    model_config = SuperVar.getVar("model_config")
    creator = SuperVar.getVar("creator")
    tenant = SuperVar.getVar("tenant")
    task_name = SuperVar.getVar("task_name")
    engine = SuperVar.getVar("engine")
    create_time = SuperVar.getVar("create_time")
    sc_type = SuperVar.getVar("sc_type")
    all_start = SuperVar.getVar("all_start")
    alarm_config = SuperVar.getVar("alarm_config")
    # alg_name = SuperVar.getVar("alg_name")

    if open_alarm:
        logger.info("实时预警开启")
        #     获取token
        token = HttpRequest.gettoken(alarm_config['alarm']['url'], alarm_config['alarm']['clientId'],
                                     alarm_config['alarm']['clientSecret'])
        model_config['token'] = token
        SuperVar.setVar("token", token)
        logger.debug("token获取成功")
        logger.debug(token)
    else:
        logger.info("实时预警关闭")

    if open_alarm:
        content = {"title": task_name,
                   'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
        user = {"creator": creator}
        HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                create_rt_alarm('model_center_01', content, user))
    sql_log.insertSqlLog(task_id, '训练任务开始', '1', '1', '', engine, create_time)
    sql_log.insertSqlLog(task_id, '正在处理数据', '1', '1', '', engine, create_time)

    X_vf, y_vf, dataX, dataY, algmodels, params, CanUse = GetData.GetDataStart(engine,
                                                                               SuperVar.getVar("source_engine"),
                                                                               SuperVar.getVar("sc_type"))
    if not CanUse:
        logger.error("[OUTER]训练失败")
        logger.info(f"总花费{str(time.time() - all_start)}时间")
        if open_alarm:
            content = {"title": task_name,
                       'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
            user = {"creator": creator}
            HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                    create_rt_alarm('model_center_03', content, user))
        sql_log.insertSqlLog(task_id, f'任务失败:校验失败', '1', '0', f'{params}', engine, create_time)
        # 8小时转换为秒
        eight_hours = 8 * 60 * 60

        # 加上8小时
        now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() + eight_hours))
        engine.execute(
            sql="""UPDATE model_instance SET state = 4,training_end_time='%s', pid = 0  WHERE id = '%s' """ % (
                now_time, task_id))
        logger.info("============================训练完成=================================")
        logger.info("============================束　　日=================================")
        logger.info("============================结录记志=================================")
        logger.info("")
        sys.exit()

    sql_log.insertSqlLog(task_id, '数据处理完成', '1', '1', '', engine, create_time)
    sql_log.insertSqlLog(task_id, '正在获取数据', '1', '1', '', engine, create_time)
    X_train, X_test, y_train, y_test = load.load_dataset(dataX, dataY,
                                                         int(params['proportion'].to_string(index=False)) / 100)

    sql_log.insertSqlLog(task_id, '数据获取完成', '1', '1', '', engine, create_time)
    model_config['task_id'] = task_id
    model_config['tenant'] = tenant

    if int(params['cross_validation'].to_string(index=False)) == 0:
        model_config['cv'] = 2
    else:
        model_config['cv'] = int(params['cross_validation_num'].to_string(index=False))
    # 是否开启额外验证集
    if int(params['validation'].to_string(index=False)) == 1:
        model_config['verify'] = 1
    else:
        model_config['verify'] = 0
    loss_dict = {}
    modelnum = 0
    failmodelList = []
    version = 'V' + str(datetime.datetime.now().strftime("%Y%m%d%H")) + '-' + str(CreateId.CreateOnes(True, True, 3))
    model_config['version'] = version
    sql_log.insertSqlLog(task_id, '开始训练模型', '1', '1', '', engine, create_time)
    alg_num = 0


    for algmodel_1 in algmodels:
        alg_num += 1
        algmodel = algmodel_1[0]
        model_species = engine.execute(
            sql="""select type from alg_map where func = '%s'""" % algmodel).values.tolist()[0][0]
        algname = engine.execute(
            sql="""select name from alg_map where func = '%s'""" % algmodel).values.tolist()[0][0]
        # version = engine.execute(
        #     sql="""select version from alg_map where func = '%s'""" % algmodel).values.tolist()[0][0]

        model_config['algname'] = algname

        model_config['model_species'] = model_species
        # 获取评估指标
        model_config['evaluation_index'] = engine.execute(
            sql="""select evaluation_index from model_instance where id = '%s'""" % task_id).values.tolist()[0][0]

        logger.debug(model_config['model_species'])
        logger.info('[INNER]训练开始' + algname + f' 模型计算开始    ({alg_num}/{len(algmodels)})')
        sys.path.append(str(get_alg_root('classifier')))
        sys.path.append(str(get_alg_root('clustering')))
        sys.path.append(str(get_alg_root('public')))
        sys.path.append(str(get_alg_root('regression')))
        module = importlib.import_module(algmodel)
        function = getattr(module, 'definition_model')

        logger.info(algname + ' 模型正在计算中')
        sql_log.insertSqlLog(task_id, algname + ' 模型正在计算中', '1', '1', '', engine, create_time)
        start = time.time()
        # 全局变量
        model, param_dist = function()
        # 这里应用模型模块
        # 保证顺序一致
        X_train = X_train.sort_index(axis=1, ascending=False)
        X_test = X_test.sort_index(axis=1, ascending=False)
        if model_config['verify']:
            X_vf = X_vf.sort_index(axis=1, ascending=False)

        # 在此插入 其他模型
        # 目前算法为 kmeans 分类 回顾

        if sc_type == 'kmeans':

            # 这里需要配置 param_dist 来进行训练
            param_dist['n_clusters'] = params['clustering_range']
            ModelStatus, ex = runScript.use_model(model, param_dist, model_config, X_train, y_train, X_test, y_test,
                                                  X_vf,
                                                  y_vf,
                                                  algname)
        elif sc_type == 'classier':
            ModelStatus, ex = runScript.use_model(model, param_dist, model_config, X_train, y_train, X_test, y_test,
                                                  X_vf,
                                                  y_vf,
                                                  algname)
        elif sc_type == 'regress':
            ModelStatus, ex = runScript.use_model(model, param_dist, model_config, X_train, y_train, X_test, y_test,
                                                  X_vf,
                                                  y_vf,
                                                  algname)
        else:
            ModelStatus = False

        if ModelStatus == True:
            modelnum += 1
            logger.info(algname + ' 模型计算完成,花费时间： ' + str(time.time() - start) + 's')
            sql_log.insertSqlLog(task_id, algname + ' 模型训练完成', '1', '1', '', engine, create_time)
            # 8小时转换为秒
            eight_hours = 8 * 60 * 60

            # 加上8小时
            now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() + eight_hours))
            engine.execute(
                sql="""UPDATE model_instance SET progress = '%s'  WHERE id ='%s' """ % (
                    str('{:.2f}%'.format(modelnum / len(algmodels) * 100)), task_id))
        else:
            logger.info("[ALL]" + algname + ' 模型计算失败,花费时间： ' + str(time.time() - start) + 's')
            try:
                sql_log.insertSqlLog(task_id, algname + ' 模型训练失败', '1', '0', f'{ex}', engine, create_time)
            except:
                sql_log.insertSqlLog(task_id, algname + f' 模型训练失败{ex}', '1', '0', '训练失败', engine,
                                     create_time)

    if modelnum == len(algmodels):
        try:

            # 选择最好的选择
            logger.info("============================选择最好的模型=================================")
            # 获取选定的指标
            usetarget = engine.execute(
                sql="""select evaluation_index from model_instance where id = '%s'""" % task_id).values.tolist()[
                0][0]
            # 不要索引和列名
            logger.debug(usetarget)
            # 找到得分最高的指标
            maxscore = engine.execute(
                sql="""select max(test_set) from model_assessment where task_id = '%s' and target = %s and deleted = 0""" % (
                    task_id, usetarget)).values.tolist()[0][0]
            # 找到最高的ass_id
            good_model_id = engine.execute(
                sql="""select ass_id from model_assessment where task_id = '%s' and test_set = %s  and deleted = 0""" % (
                    task_id, maxscore)).values.tolist()[0][0]
            # if SuperVar.getVar("base_config")['databricks']:
            #     model = SuperVar.getVar(good_model_id)
            #     # 获取当前最好的模型assid
            #     now_assid = SuperVar.getVar("model_ass_loss")
                # if now_assid == model:

            # 修改use
            engine.execute(
                sql="""UPDATE model_assessment SET `use` = 1  WHERE task_id ='%s' and ass_id = '%s' """ % (
                    task_id, good_model_id))
            # 存到模型版本库中
            model_id = CreateId.Create()
            # 获取模型路径
            model_path = engine.execute(
                sql="""select model_path from model_map where task_id = '%s' and ass_id = '%s'""" % (
                    task_id, good_model_id)).values.tolist()[0][0]

            engine.execute(
                sql="""INSERT INTO model_version (model_id, task_id, ass_id,model_path, model_version, create_time,tenant_api_name) value ('%s','%s','%s','%s','%s','%s','%s')""" % (
                    model_id, task_id, good_model_id, model_path,
                    time.strftime('%Y%m%d%H', time.localtime()) + '-' + CreateId.CreateOnes(True, True, 3),
                    time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), tenant))
            logger.info("[ALL]训练完成")
            logger.info(f"总花费{str(time.time() - all_start)}时间")
            if open_alarm:
                content = {"title": task_name,
                           'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
                user = {"creator": creator}
                HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                        create_rt_alarm('model_center_02', content, user))
            sql_log.insertSqlLog(task_id, '任务完成', '1', '1', '', engine, create_time)
            # 8小时转换为秒
            eight_hours = 8 * 60 * 60

            # 加上8小时
            now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() + eight_hours))
            engine.execute(
                sql="""UPDATE model_instance SET state = 3,training_end_time='%s',pid = 0  WHERE id ='%s' """ % (
                    now_time, task_id))
            logger.info("============================训练完成=================================")
            logger.info("============================束　　日=================================")
            logger.info("============================结录记志=================================")
            logger.info("")
        except Exception as e:
            logger.error(e)
            sql_log.insertSqlLog(task_id, '任务失败', '1', '0', e, engine, create_time)
    else:
        logger.info("[OUTER]训练失败")
        logger.info(f"总花费{str(time.time() - all_start)}时间")
        if open_alarm:
            content = {"title": task_name,
                       'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
            user = {"creator": creator}
            HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                    create_rt_alarm('model_center_03', content, user))
        sql_log.insertSqlLog(task_id, '任务失败', '1', '0', '训练全部失败，请联系管理员', engine, create_time)
        # 8小时转换为秒
        eight_hours = 8 * 60 * 60

        # 加上8小时
        now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() + eight_hours))
        engine.execute(
            sql="""UPDATE model_instance SET state = 4,training_end_time='%s', pid = 0  WHERE id = '%s' """ % (
                now_time, task_id))
        logger.info("============================训练完成=================================")
        logger.info("============================束　　日=================================")
        logger.info("============================结录记志=================================")
        logger.info("")


def train(model, param_dist):
    SuperVar.setVar("system_type", "train")
    task_id = SuperVar.getVar("task_id")
    # 生成日志
    log_config = SuperVar.getVar('log_config')
    logger = logConfig.Createlogging(log_config['LogConfig'], task_id, 'train')
    logger.info("")
    logger.info("============================日志开始记录=================================")
    SuperVar.setVar("logger", logger)
    if SuperVar.getVar("System_info") == 'User':
        logger.info("============================用户使用mock=================================")
        #     读取csv文件-》 查看是否有label
        file_path = SuperVar.getVar("file_path")
        start_json = SuperVar.getVar("start_json")
        # 获取场景对应的type
        sc_type = start_json['model_species']
        SuperVar.setVar("sc_type", sc_type)
        SuperVar.setVar("model_species", sc_type)
        try:
            sourcedata = pd.read_csv(file_path)
            if "label" in start_json.keys():
                SuperVar.setVar("label", start_json['label'])
                if start_json['label'] not in sourcedata.columns:
                    print(f"mock文件中{start_json['label']}并不存在，请检查mock文件，确认大小写")
            else:
                print("请在mock_json中 写入 label")
                sys.exit(0)
        except Exception as e:
            print(e)
            print("mock文件不存在")
            sys.exit(0)

    open_alarm = SuperVar.getVar("open_alarm")
    model_config = SuperVar.getVar("model_config")
    creator = SuperVar.getVar("creator")
    tenant = SuperVar.getVar("tenant")
    task_name = SuperVar.getVar("task_name")
    engine = SuperVar.getVar("engine")
    create_time = SuperVar.getVar("create_time")
    sc_type = SuperVar.getVar("sc_type")
    all_start = SuperVar.getVar("all_start")
    alarm_config = SuperVar.getVar("alarm_config")
    alg_name = SuperVar.getVar("alg_name")

    if open_alarm:
        logger.info("实时预警开启")
        #     获取token
        token = HttpRequest.gettoken(alarm_config['alarm']['url'], alarm_config['alarm']['clientId'],
                                     alarm_config['alarm']['clientSecret'])
        model_config['token'] = token
        SuperVar.setVar("token", token)
        logger.debug("token获取成功")
        logger.debug(token)
    else:
        logger.info("实时预警关闭")

    if open_alarm:
        content = {"title": task_name,
                   'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
        user = {"creator": creator}
        HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                create_rt_alarm('model_center_01', content, user))

    sql_log.insertSqlLog(task_id, '训练任务开始', '1', '1', '', engine, create_time)
    sql_log.insertSqlLog(task_id, '正在处理数据', '1', '1', '', engine, create_time)
    if SuperVar.getVar("System_info") == 'User':
        X_vf, y_vf, dataX, dataY, _, params, CanUse = GetData.GetUserDataStart(engine,
                                                                               SuperVar.getVar("source_engine"),
                                                                               SuperVar.getVar("sc_type"))
    else:
        X_vf, y_vf, dataX, dataY, _, params, CanUse = GetData.GetDataStart(engine,
                                                                           SuperVar.getVar("source_engine"),
                                                                           SuperVar.getVar("sc_type"))
    if not CanUse:
        logger.error("[OUTER]训练失败")
        logger.info(f"总花费{str(time.time() - all_start)}时间")
        if open_alarm:
            content = {"title": task_name,
                       'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
            user = {"creator": creator}
            HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                    create_rt_alarm('model_center_03', content, user))
        sql_log.insertSqlLog(task_id, f'任务失败:校验失败', '1', '0', f'{params}', engine, create_time)
        # 8小时转换为秒
        eight_hours = 8 * 60 * 60

        # 加上8小时
        now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() + eight_hours))
        if SuperVar.getVar("System_info") != 'User':
            engine.execute(
                sql="""UPDATE model_instance SET state = 4,training_end_time='%s', pid = 0  WHERE id = '%s' """ % (
                    now_time, task_id))
        logger.info("============================训练完成=================================")
        logger.info("============================束　　日=================================")
        logger.info("============================结录记志=================================")
        logger.info("")
        sys.exit()

    sql_log.insertSqlLog(task_id, '数据处理完成', '1', '1', '', engine, create_time)
    sql_log.insertSqlLog(task_id, '正在获取数据', '1', '1', '', engine, create_time)
    X_train, X_test, y_train, y_test = load.load_dataset(dataX, dataY,
                                                         int(params['proportion'].to_string(index=False)) / 100)
    sql_log.insertSqlLog(task_id, '数据获取完成', '1', '1', '', engine, create_time)
    model_config['task_id'] = task_id
    model_config['tenant'] = tenant

    if int(params['cross_validation'].to_string(index=False)) == 0:
        model_config['cv'] = 2
    else:
        model_config['cv'] = int(params['cross_validation_num'].to_string(index=False))
    # 是否开启额外验证集
    if int(params['validation'].to_string(index=False)) == 1:
        model_config['verify'] = 1
    else:
        model_config['verify'] = 0
    loss_dict = {}
    failmodelList = []

    version = 'V' + str(datetime.datetime.now().strftime("%Y%m%d%H")) + '-' + str(
        CreateId.CreateOnes(True, True, 3))
    model_config['version'] = version
    sql_log.insertSqlLog(task_id, '开始训练模型', '1', '1', '', engine, create_time)
    # 获取算法类型
    model_species = SuperVar.getVar("model_species")
    # alg_name = os.path.splitext(os.path.basename(__file__))[0]
    # SuperVar.setVar('alg_name', alg_name)
    model_config['alg_name'] = alg_name
    model_config['model_species'] = model_species
    # 获取评估指标
    if SuperVar.getVar("System_info") != 'User':
        model_config['evaluation_index'] = engine.execute(
            sql="""select evaluation_index from model_instance where id = '%s'""" % task_id).values.tolist()[
            0][0]
    else:
        model_config['evaluation_index'] = 1


    logger.debug(model_config['model_species'])
    logger.info('[INNER]训练开始' + alg_name + ' 模型计算开始')
    logger.info(alg_name + ' 模型正在计算中')

    sql_log.insertSqlLog(task_id, alg_name + ' 模型正在计算中', '1', '1', '', engine, create_time)
    start = time.time()

    # 这里应用模型模块
    # 保证顺序一致
    X_train = X_train.sort_index(axis=1, ascending=False)
    # print(X_train)
    X_test = X_test.sort_index(axis=1, ascending=False)
    if model_config['verify']:
        X_vf = X_vf.sort_index(axis=1, ascending=False)

        # 在此插入 其他模型
        # 目前算法为 kmeans 分类 回顾
    if sc_type == 'kmeans':

        # 这里需要配置 param_dist 来进行训练
        param_dist['n_clusters'] = params['clustering_range']
        ModelStatus, ex = runScript.use_model(model, param_dist, model_config, X_train, y_train, X_test, y_test,
                                              X_vf,
                                              y_vf,
                                              alg_name)
    # elif sc_type == 'classier':
    #     ModelStatus, ex = runScript.use_model(model, param_dist, model_config, X_train, y_train, X_test, y_test,
    #                                           X_vf,
    #                                           y_vf,
    #                                           alg_name)
    # elif sc_type == 'regress':
    #     ModelStatus, ex = runScript.use_model(model, param_dist, model_config, X_train, y_train, X_test, y_test,
    #                                           X_vf,
    #                                           y_vf,
    #                                           alg_name)
    else:
        ModelStatus, ex = runScript.use_model(model, param_dist, model_config, X_train, y_train, X_test, y_test,
                                              X_vf,
                                              y_vf,
                                              alg_name)

    if ModelStatus == True:
        logger.info(alg_name + ' 模型计算完成,花费时间： ' + str(time.time() - start) + 's')
        sql_log.insertSqlLog(task_id, alg_name + ' 模型训练完成', '1', '1', '', engine, create_time)
        # 8小时转换为秒
        eight_hours = 8 * 60 * 60

        # 加上8小时
        now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() + eight_hours))
        # TODO 这里的进度需要修改
        engine.execute(
            sql="""UPDATE model_instance SET progress = '%s'  WHERE id ='%s' """ % (
                '100.00%', task_id))
    else:
        logger.info("[ALL]" + alg_name + ' 模型计算失败,花费时间： ' + str(time.time() - start) + 's')
        try:
            sql_log.insertSqlLog(task_id, alg_name + ' 模型训练失败', '1', '0', f'{ex}', engine,
                                 create_time)
            if SuperVar.getVar("System_info") == "User":
                # SuperVar.getVar("sourcedata").drop(SuperVar.getVar("dataID"), axis=1).to_csv('dataframe.csv')
                logger.error(SuperVar.getVar("sourcedata").drop(SuperVar.getVar("dataID")))
        except:
            sql_log.insertSqlLog(task_id, alg_name + f'模型训练失败{ex}', '1', '0', '训练失败', engine,
                                 create_time)
    if SuperVar.getVar("System_info") != 'User':
        try:
            # 选择最好的选择
            logger.info("============================选择最好的模型=================================")
            # 获取选定的指标
            usetarget = engine.execute(
                sql="""select evaluation_index from model_instance where id = '%s'""" % task_id).values.tolist()[
                0][0]
            # 不要索引和列名
            logger.debug(usetarget)
            # 找到得分最高的指标
            maxscore = engine.execute(
                sql="""select max(test_set) from model_assessment where task_id = '%s' and target = %s and deleted = 0""" % (
                    task_id, usetarget)).values.tolist()[0][0]
            # 找到最高的ass_id
            good_model_id = engine.execute(
                sql="""select ass_id from model_assessment where task_id = '%s' and test_set = %s  and deleted = 0""" % (
                    task_id, maxscore)).values.tolist()[0][0]
            # if SuperVar.getVar("base_config")['databricks']:
            #     model = SuperVar.getVar(good_model_id.split('-')[0])
            #     # 开始一个新的MLflow运行
            #     import mlflow
            #     with mlflow.start_run(run_name=SuperVar.getVar("task_name")) as run:
            #         # 将模型保存到当前运行的artifacts目录下
            #         model_path = "model"
            #         mlflow.sklearn.log_model(model, artifact_path=model_path)
            #
            #         # 注册模型
            #         registered_model_name = SuperVar.getVar("task_name")
            #         mlflow.register_model(model_uri=f"runs:/{run.info.run_id}/{model_path}", name=registered_model_name)

            # 修改use
            engine.execute(
                sql="""UPDATE model_assessment SET `use` = 1  WHERE task_id ='%s' and ass_id = '%s' """ % (
                    task_id, good_model_id))
            # 存到模型版本库中
            model_id = CreateId.Create()
            # 获取模型路径
            model_path = engine.execute(
                sql="""select model_path from model_map where task_id = '%s' and ass_id = '%s'""" % (
                    task_id, good_model_id)).values.tolist()[0][0]

            engine.execute(
                sql="""INSERT INTO model_version (model_id, task_id, ass_id,model_path, model_version, create_time,tenant_api_name) value ('%s','%s','%s','%s','%s','%s','%s')""" % (
                    model_id, task_id, good_model_id, model_path,
                    time.strftime('%Y%m%d%H', time.localtime()) + '-' + CreateId.CreateOnes(True, True, 3),
                    time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), tenant))
            logger.info("[ALL]训练完成")
            logger.info(f"总花费{str(time.time() - all_start)}时间")
            if open_alarm:
                content = {"title": task_name,
                           'time': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}
                user = {"creator": creator}
                HttpRequest.createAlarm(alarm_config['alarm']['alarmurl'], model_config['token'],
                                        create_rt_alarm('model_center_02', content, user))
            sql_log.insertSqlLog(task_id, '任务完成', '1', '1', '', engine, create_time)
            # 8小时转换为秒
            eight_hours = 8 * 60 * 60
            # 加上8小时
            now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() + eight_hours))
            engine.execute(
                sql="""UPDATE model_instance SET state = 3,training_end_time='%s',pid = 0  WHERE id ='%s' """ % (
                    now_time, task_id))
            logger.info("============================训练完成=================================")
            logger.info("============================束　　日=================================")
            logger.info("============================结录记志=================================")
            logger.info("")
        except Exception as e:
            logger.error(e)
            sql_log.insertSqlLog(task_id, '任务失败', '1', '0', e, engine, create_time)
    else:

        # 创建两个表格的数据
        table1_data = [i for i in range(10)]
        table2_data = [i ** 2 for i in table1_data]
        from mpl_toolkits.axisartist.axislines import AxesZero

        # 创建一个3x1的网格
        fig, (ax1, ax2, ax3) = plt.subplots(nrows=3, ncols=1)

        # 在第一个子图形上绘制两个并列的表格
        # ax1 = fig.add_subplot(1, 1, 1, axes_class=AxesZero)

        ax1.table(cellText=[["apples", "oranges"],
                            ["bananas", "kiwi"]],
                  colLabels=['col 1', 'col 2'],
                  loc='center')

        # The axis spines are still there, we only want the frame.
        # ax1.axis["bottom"].set_visible(False)
        # ax1.axis["top"].set_visible(False)
        # ax1.axis["left"].set_visible(False)
        # ax1.axis["right"].set_visible(False)

        # 在第二个子图形上绘制柱状图
        ax2.bar(range(len(table1_data)), table1_data)

        # 在第三个子图形上绘制折线图
        ax3.plot(range(len(table1_data)), table1_data)

        # 显示图像
        plt.show()

        logger.info("============================训练完成=================================")
        logger.info("============================束　　日=================================")
        logger.info("============================结录记志=================================")
        logger.info("")
