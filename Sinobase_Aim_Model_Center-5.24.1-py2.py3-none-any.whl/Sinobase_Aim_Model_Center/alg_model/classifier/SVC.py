# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :SVC.py

@Time      :2023/5/19 10:23

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

import sys
import warnings

from loguru import logger
from sklearn.svm import SVC

sys.path.append('../../..')
warnings.filterwarnings("ignore")

from scipy.stats import uniform
# SVC
#         arg = SVC(kernel='rbf', probability=True)
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)
@logger.catch
def definition_model():
    # 定义参数分布
    param_dist = {
        'kernel': ['linear', 'poly', 'rbf', 'sigmoid'],
        'C': [0.1, 1, 10, 100],
        'gamma': uniform(0.1, 10)
    }
    model = SVC()
    return model, param_dist