# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :GradientBoostingClassifier.py

@Time      :2023/5/19 10:16

@Author    :Guan_jh


@Email     :guan_jh@qq.com

@Describe  : 梯度提升决策树调参
'''

import sys
import warnings

import numpy as np
from loguru import logger
from sklearn.ensemble import GradientBoostingClassifier

sys.path.append('../../..')
warnings.filterwarnings("ignore")
from scipy.stats import uniform
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)
# for n_estimators in range(3, 10, 1):
#     for subsample in np.arange(0.5, 1, 0.1):
#         for max_depth in range(1, 3, 1):
#             for learning_rate in np.arange(0.1, 1, 0.1):
# GradientBoostingClassifier

@logger.catch
def definition_model():
    # 定义参数分布
    param_dist = {
        'n_estimators': [100, 200, 250],
        'learning_rate': [0.01, 0.1],
        'max_depth': [5, 7],
        # 'min_samples_split': [2, 5, 10],
        # 'min_samples_leaf': [1, 2, 5],
        # 'max_features': ['auto', 'sqrt', 'log2', 5, 10],
        'subsample': [0.85, 0.95]
    }
    model = GradientBoostingClassifier()
    return model, param_dist