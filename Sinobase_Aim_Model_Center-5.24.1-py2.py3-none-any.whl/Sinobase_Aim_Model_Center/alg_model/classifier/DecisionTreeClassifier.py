# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :DecisionTreeClassifier.py

@Time      :2023/5/19 10:22

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''
import sys
import warnings

from loguru import logger
from sklearn import tree

sys.path.append('../../..')
warnings.filterwarnings("ignore")
from scipy.stats import uniform
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)


@logger.catch
def definition_model():
    # 定义参数分布
    param_dist = {
        'criterion':['gini','entropy'],
        'max_depth': range(1, 20),
        # 'min_samples_split': uniform(0.1, 1.0),
        'splitter': ['best','random'],
        'min_samples_leaf': uniform(0.1, 0.5)
    }
    model = tree.DecisionTreeClassifier()
    return model, param_dist
