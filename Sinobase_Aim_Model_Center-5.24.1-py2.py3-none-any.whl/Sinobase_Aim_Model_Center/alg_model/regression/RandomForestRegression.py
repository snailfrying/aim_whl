# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :RandomForestRegression.py

@Time      :2023/7/6 9:59

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''


import sys
sys.path.append('../../..')
import warnings
warnings.filterwarnings("ignore")
from loguru import logger
from scipy.stats import uniform
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)
import numpy as np
from sklearn.ensemble import RandomForestRegressor





@logger.catch
def definition_model():
    # 定义参数分布
    # 'bootstrap', 'ccp_alpha', 'criterion', 'max_depth', 'max_features', 'max_leaf_nodes', 'max_samples', 'min_impurity_decrease', 'min_samples_leaf', 'min_samples_split', 'min_weight_fraction_leaf', 'n_estimators', 'n_jobs', 'oob_score', 'random_state', 'verbose', 'warm_start'
    param_dist = {
        'n_estimators':[ 50, 80, 160 ],
        'max_depth':[ 5, 8 ],
        # 'min_samples_split':uniform(0.1, 0.9),
        # 'min_samples_leaf':[ 1, 2, 5],
        # 'max_features':[ 'auto', 'sqrt', 'log2', 5, 10 ],
        'bootstrap':[ True, False ]
    }

    model = RandomForestRegressor()
    return model, param_dist