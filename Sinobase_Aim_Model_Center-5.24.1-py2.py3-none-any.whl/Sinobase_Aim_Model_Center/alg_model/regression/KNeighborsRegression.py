# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :KNeighborsRegression.py

@Time      :2023/7/6 9:55

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''


import sys

from sklearn.inspection import permutation_importance
from sklearn.linear_model import LassoCV

sys.path.append('../../..')
import warnings
warnings.filterwarnings("ignore")
from loguru import logger
from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)

from sklearn.neighbors import KNeighborsRegressor
import numpy as np

class MyKNeighborsRegressor(KNeighborsRegressor):
    # 重写feature_importances_属性
    def fit(self, X, y):
        super().fit(X, y)
        self.X_ = X
        self.y_ = y
        return self

    @property
    def feature_importances_(self):
        result = permutation_importance(self, self.X_, self.y_)
        return result.importances_mean




@logger.catch
def definition_model():
    # 定义参数分布
    # 'algorithm', 'leaf_size', 'metric', 'metric_params', 'n_jobs', 'n_neighbors', 'p', 'weights'
    param_dist = {
        'algorithm': ['auto', 'ball_tree', 'kd_tree', 'brute'],  # 用于计算最近邻的算法
        'leaf_size': [10, 30, 50, 100],  # 用于 BallTree 或 KDTree 的叶子大小
        'metric': ['minkowski', 'euclidean', 'manhattan', 'chebyshev'],  # 用于距离度量的函数
        'n_neighbors': [3, 5, 10, 20],  # 最近邻的数量
        'p': [1, 2, 3],  # Minkowski 距离的幂参数
        'weights': ['uniform', 'distance'],  # 最近邻的权重函数
    }

    model = MyKNeighborsRegressor()
    return model, param_dist

