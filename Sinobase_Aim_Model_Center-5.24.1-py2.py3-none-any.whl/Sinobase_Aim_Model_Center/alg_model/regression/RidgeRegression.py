# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :RidgeRegression.py

@Time      :2023/7/6 9:56

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :
'''

import sys

from sklearn.inspection import permutation_importance

sys.path.append('../../..')
import warnings

warnings.filterwarnings("ignore")
from loguru import logger
from scipy.stats import uniform
from warnings import simplefilter

simplefilter(action='ignore', category=FutureWarning)
import numpy as np
from sklearn.linear_model import Ridge

class MyRidge(Ridge):
    @property
    def feature_importances_(self):
        if self.coef_ is None:
            self.coef_ = self.coef_.flatten()
        return self.coef_ / abs(self.coef_).sum()


@logger.catch
def definition_model():
    # 定义参数分布
    # 'alpha', 'copy_X', 'fit_intercept', 'max_iter', 'positive', 'random_state', 'solver', 'tol'
    param_dist = {
        'alpha': np.logspace(-4, 4, 20),  # alpha是控制正则化强度的非负浮点数，范围从10^-4到10^4
        # 'max_iter': range(1000, 5000),  # max_iter是一个整数，表示最大迭代次数
        'random_state': range(0, 100),  # random_state是一个整数，表示随机数种子
        'solver': ['auto', 'svd', 'cholesky', 'lsqr', 'sparse_cg', 'sag', 'saga'],
        # solver是一个字符串，表示用于计算Ridge系数的求解器
        'tol': np.logspace(-6, -2, 10),  # tol是一个浮点数，表示解的精度
    }

    model = MyRidge()
    return model, param_dist
