# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :Script_Constructor.py

@Time      :2023/11/06 14:02

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
import inspect
import sys
import time
from datetime import datetime
import copy
from Sinobase_Aim_Model_Center.model_util import SuperVar, dfutil


def num_feature(func):
    def wrapper(*args, **kwargs):
        # 带着id走
        engine = SuperVar.getVar('engine')
        logger = SuperVar.getVar('logger')
        dataID = SuperVar.getVar("dataID")
        feature = SuperVar.getVar("feature")
        dataXint = feature.loc[feature['feature_type'] == '数值型变量']
        sourcedata = SuperVar.getVar("sourcedata")
        # 给当前数据加上id
        sourcedata = sourcedata.assign(thisID=sourcedata.index + 1)
        # 拿到需要传走的id
        datalist = dataXint['feature_name'].values.tolist()
        _, _, all_in = dfutil.compareA2Blist(sourcedata, datalist)
        # 记录一个原始list
        org_list = copy.deepcopy(all_in)
        # 加个id
        all_in.append('thisID')

        kwargs = {"data": sourcedata[all_in]}
        result = func(*args, **kwargs)

        result = copy.deepcopy(result)
        if dataID not in result.columns and "thisID" not in result.columns:
            raise Exception('id 不能被删除')
        # 在原dataframe中删除 已有的 列，把新的列 以id为主 做左合并
        sourcedata.drop(columns=org_list, inplace=True)

        # feature = engine.execute(
        #     sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % SuperVar.getVar("task_id"))

        # resultlistsource = dfutil.dfaWithListB(result, datalist)
        # print(resultlistsource)
        # del_source, add_source, inner_source = dfutil.compareAB(sourcedata[datalist],
        #                                                         result)
        #
        # # 删除的字段 入库 检查一下如果有id 就不能删除 并报错
        # if dataID in del_source:
        #     raise Exception('id 不能被删除')
        # else:
        #     # pass
        #     for i in del_source:
        #         logger.info('排除字段:' + str(i))
        #         if SuperVar.getVar("System_info") != 'User' and SuperVar.getVar("system_type")=="train":
        #             id = feature.query(f'feature_name == "{i}"')['id'].values.tolist()[0]
        #             engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % id)
        #             sourcedata = sourcedata.drop(i, axis=1)
        #         else:
        #             sourcedata = sourcedata.drop(i, axis=1)=
        #         # sourcedata = sourcedata.drop(i, axis=1)
        # # 添加的字段 入库 和原sourcedata合并 用id
        # for i in add_source:
        #     logger.info('新增字段:' + str(i))
        #     sql = """INSERT INTO model_feature  (task_id, feature_name, field_type, feature_type, feature_attr, feature_explain, feature_item, feature_count, feature_complete, feature_complete_rate, feature_category, feature_many, feature_many_rate, create_user, update_user, create_time, update_time, tenant_api_name) VALUES ('%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s')""" % (
        #         SuperVar.getVar("task_id"), str(i), 'int', '数值型变量', '其他', str(i), str(i), result[i].shape[0],
        #         len(result[result[i].notnull()]), len(result[result[i].notnull()]) / result[i].shape[0],
        #         len(set(result[i])), result[i].mode()[0], result[i].value_counts()[0] / result[i].shape[0],
        #         'System_create', 'System_create', datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        #         datetime.now().strftime("%Y-%m-%d %H:%M:%S"), SuperVar.getVar("tenant"))
        #     if SuperVar.getVar("system_type")=="train":
        #         engine.execute(
        #             sql=sql)
        # add_source.append(dataID)
        # for i in inner_source:
        #     if i != dataID:
        #         sourcedata = sourcedata.drop(i, axis=1)

        sourcedata = sourcedata.merge(result, on="thisID", how='left')
        sourcedata = sourcedata.drop("thisID", axis=1)
        SuperVar.setVar("sourcedata", sourcedata)
        # SuperVar.setVar("feature", feature)
        return result

    return wrapper


def var_feature(func):
    def wrapper(*args, **kwargs):
        logger = SuperVar.getVar('logger')
        engine = SuperVar.getVar('engine')
        dataID = SuperVar.getVar("dataID")

        feature = SuperVar.getVar("feature")

        dataXvar = feature.loc[feature['feature_type'] == '字符型变量']
        # 比对现有的dataXvar 和 sourcedata

        sourcedata = SuperVar.getVar("sourcedata")

        sourcedata = sourcedata.assign(thisID=sourcedata.index + 1)
        datalist = dataXvar['feature_name'].values.tolist()
        _, _, all_in = dfutil.compareA2Blist(sourcedata, datalist)
        org_list = copy.deepcopy(all_in)
        all_in.append("thisID")
        kwargs = {"data": sourcedata[all_in]}
        result = func(*args, **kwargs)

        result = copy.deepcopy(result)
        # feature = engine.execute(
        #     sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % SuperVar.getVar("task_id"))
        # # resultlistsource = dfutil.dfaWithListB(result, datalist)
        # print(resultlistsource)
        # del_source, add_source, inner_source = dfutil.compareAB(sourcedata[datalist],
        #                                                         result)
        # 删除的字段 入库 检查一下如果有id 就不能删除 并报错

        if dataID not in result.columns and "thisID" not in result.columns:
            raise Exception('id 不能被删除')

        sourcedata.drop(columns=org_list, inplace=True)
        # else:
        #     # pass
        #     for i in del_source:
        #         logger.info('排除字段:' + str(i))
        #         if SuperVar.getVar("System_info") != 'User' and SuperVar.getVar("system_type") == "train":
        #             id = feature.query(f'feature_name == "{i}"')['id'].values.tolist()[0]
        #             engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % id)
        #             sourcedata = sourcedata.drop(i, axis=1)
        #         else:
        #             sourcedata = sourcedata.drop(i, axis=1)
        #         # sourcedata = sourcedata.drop(i, axis=1)
        # # 添加的字段 入库 和原sourcedata合并 用id
        # for i in add_source:
        #     logger.info('新增字段:' + str(i))
        #     sql = """INSERT INTO model_feature  (task_id, feature_name, field_type, feature_type, feature_attr, feature_explain, feature_item, feature_count, feature_complete, feature_complete_rate, feature_category, feature_many, feature_many_rate, create_user, update_user, create_time, update_time, tenant_api_name) VALUES ('%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s')""" % (
        #         SuperVar.getVar("task_id"), str(i), 'string', '字符型变量', '其他', str(i), str(i), result[i].shape[0],
        #         len(result[result[i].notnull()]), len(result[result[i].notnull()]) / result[i].shape[0],
        #         len(set(result[i])), result[i].mode()[0], result[i].value_counts()[0] / result[i].shape[0],
        #         'System_create', 'System_create', datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        #         datetime.now().strftime("%Y-%m-%d %H:%M:%S"), SuperVar.getVar("tenant"))
        #     if SuperVar.getVar("system_type") == "train":
        #         engine.execute(
        #             sql=sql)
        # # add_source.append(dataID)
        #
        # # 删掉除了id以外 仍存在的列
        # # 将result 与 sourcedata 用id合并
        # for i in inner_source:
        #     if i != dataID:
        #         sourcedata = sourcedata.drop(i, axis=1)
        sourcedata = sourcedata.merge(result, on="thisID", how='left')
        sourcedata = sourcedata.drop("thisID", axis=1)
        SuperVar.setVar("sourcedata", sourcedata)
        # SuperVar.setVar("feature", feature)s
        return result

    return wrapper


def all_feature(func):
    def wrapper(*args, **kwargs):
        logger = SuperVar.getVar('logger')
        sourcedata = SuperVar.getVar("sourcedata")
        engine = SuperVar.getVar('engine')
        dataID = SuperVar.getVar("dataID")
        datalist = list(sourcedata.columns)
        sourcedata = sourcedata.assign(thisID=sourcedata.index + 1)
        org_list = copy.deepcopy(datalist)
        # sourcedata = SuperVar.getVar("sourcedata")
        kwargs = {"data": sourcedata}
        result = func(*args, **kwargs)
        result = copy.deepcopy(result)
        # feature = engine.execute(
        #     sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % SuperVar.getVar("task_id"))
        # resultlistsource = dfutil.dfaWithListB(result, datalist)
        # print(resultlistsource)
        # del_source, add_source, inner_source = dfutil.compareAB(sourcedata[datalist],
        #                                                         result)
        # 删除的字段 入库 检查一下如果有id 就不能删除 并报错
        if dataID not in result.columns and "thisID" not in result.columns:
            raise Exception('id 不能被删除')
        sourcedata.drop(columns=org_list, inplace=True)
        # else:
        #     # pass
        #     for i in del_source:
        #         logger.info('排除字段:' + str(i))
        #         if SuperVar.getVar("System_info") != 'User' and SuperVar.getVar("system_type") == "train":
        #             id = feature.query(f'feature_name == "{i}"')['id'].values.tolist()[0]
        #             engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % id)
        #             sourcedata = sourcedata.drop(i, axis=1)
        #         else:
        #             sourcedata = sourcedata.drop(i, axis=1)
        # # 添加的字段 入库 和原sourcedata合并 用id
        # for i in add_source:
        #     logger.info('新增字段:' + str(i))
        #     sql = """INSERT INTO model_feature  (task_id, feature_name, field_type, feature_type, feature_attr, feature_explain, feature_item, feature_count, feature_complete, feature_complete_rate, feature_category, feature_many, feature_many_rate, create_user, update_user, create_time, update_time, tenant_api_name) VALUES ('%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s')""" % (
        #         SuperVar.getVar("task_id"), str(i), 'int', '数值型变量', '其他', str(i), str(i), result[i].shape[0],
        #         len(result[result[i].notnull()]), len(result[result[i].notnull()]) / result[i].shape[0],
        #         len(set(result[i])), result[i].mode()[0], result[i].value_counts()[0] / result[i].shape[0],
        #         'System_create', 'System_create', datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        #         datetime.now().strftime("%Y-%m-%d %H:%M:%S"), SuperVar.getVar("tenant"))
        #     if SuperVar.getVar("system_type") == "train":
        #         engine.execute(
        #             sql=sql)
        # # add_source.append(dataID)
        # for i in inner_source:
        #     if i != dataID:
        #         sourcedata = sourcedata.drop(i, axis=1)
        sourcedata = sourcedata.merge(result, on="thisID", how='left')
        sourcedata = sourcedata.drop("thisID", axis=1)
        # print(sourcedata.columns)
        SuperVar.setVar("sourcedata", sourcedata)
        # SuperVar.setVar("feature", feature)

        return result

    return wrapper


def col_feature(func):
    def wrapper(*args, **kwargs):
        logger = SuperVar.getVar('logger')
        engine = SuperVar.getVar('engine')
        dataID = SuperVar.getVar("dataID")
        sourcedata = SuperVar.getVar("sourcedata")
        # print(sourcedata.columns)

        sourcedata = sourcedata.assign(thisID=sourcedata.index + 1)
        sig = inspect.signature(func)
        params = sig.parameters
        arg_num = 0
        arg_list = []
        args = ()
        # print(sourcedata.columns)
        for i in list(params.keys()):
            if i != 'data':
                arg_num += 1
                arg_list.append(i)
                args += (None,)
        if arg_num == 0:
            raise Exception('参数异常，请填入要使用的 列名')
        dataID = SuperVar.getVar("dataID")
        # 检查一些list在不在argllist里面
        last_list = []
        not_list = []
        for i in arg_list:
            if i in sourcedata.columns.to_list():
                last_list.append(i)
            else:
                not_list.append(i)
        if not_list:
            logger.error(f"以下字段不存在请检查，并删除{not_list}")
        use_list = copy.deepcopy(last_list)
        last_list.append('thisID')
        kwargs = {"data": sourcedata[last_list]}
        result = func(*args, **kwargs)

        result = copy.deepcopy(result)

        # print(result.columns)
        # feature = SuperVar.gestVar('feature')
        # feature = engine.execute(
        #     sql="""select * from model_feature where deleted = 0 and task_id = '%s'""" % SuperVar.getVar("task_id"))
        # del_source, add_source, inner_source = dfutil.compareAB(sourcedata[last_list],
        #                                                         result)
        #
        # print("========================")
        # print(del_source)
        # print("========================")
        # print(add_source)
        # print("========================")
        # print(inner_source)
        # print("========================")

        # 删除的字段 入库 检查一下如果有id 就不能删除 并报错
        if dataID not in result.columns and "thisID" not in result.columns:
            raise Exception('id 不能被删除')
        sourcedata.drop(columns=use_list, inplace=True)
        # else:
        #     # pass
        #     for i in del_source:
        #         logger.info('排除字段:' + str(i))
        #         if SuperVar.getVar("System_info") != 'User' and SuperVar.getVar("system_type") == "train":
        #             id = feature.query(f'feature_name == "{i}"')['id'].values.tolist()[0]
        #             engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % id)
        #             sourcedata = sourcedata.drop(i, axis=1)
        #         else:
        #             sourcedata = sourcedata.drop(i, axis=1)
        # # 添加的字段 入库 和原sourcedata合并 用id
        # for i in add_source:
        #     logger.info('新增字段:' + str(i))
        #     sql = """INSERT INTO model_feature  (task_id, feature_name, field_type, feature_type, feature_attr, feature_explain, feature_item, feature_count, feature_complete, feature_complete_rate, feature_category, feature_many, feature_many_rate, create_user, update_user, create_time, update_time, tenant_api_name) VALUES ('%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s','%s','%s','%s', '%s')""" % (
        #         SuperVar.getVar("task_id"), str(i), 'int', '数值型变量', '其他', str(i), str(i), result[i].shape[0],
        #         len(result[result[i].notnull()]), len(result[result[i].notnull()]) / result[i].shape[0],
        #         len(set(result[i])), result[i].mode()[0], result[i].value_counts()[0] / result[i].shape[0],
        #         'System_create', 'System_create', datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        #         datetime.now().strftime("%Y-%m-%d %H:%M:%S"), SuperVar.getVar("tenant"))
        #     if SuperVar.getVar("system_type") == "train":
        #         engine.execute(
        #             sql=sql)
        # for i in inner_source:
        #     if i != dataID:
        #         sourcedata = sourcedata.drop(i, axis=1)
        sourcedata = sourcedata.merge(result, on="thisID", how='left')
        sourcedata = sourcedata.drop("thisID", axis=1)
        SuperVar.setVar("sourcedata", sourcedata)
        # SuperVar.setVar("feature", feature)
        return result

    return wrapper

# def del_feature(func):
#     def wrapper(*args, **kwargs):
#         # logger = SuperVar.getVar("logger")
#         sig = inspect.signature(func)
#         params = sig.parameters
#         arg_list = []
#         args = ()
#         engine = SuperVar.getVar("engine")
#         for i in list(params.keys()):
#             if i != 'data':
#                 arg_list.append(i)
#                 args += (None,)
#         feature = SuperVar.getVar("feature")
#         print(feature['feature_name'])
#         for i in arg_list:
#             id = feature.query(f'feature_name == "{i}"')['id'].values.tolist()[0]
#             engine.execute(sql="""UPDATE model_feature SET feature_type = '排除'   WHERE id = '%s' """ % id)
#
#         kwargs = {"data": None}
#         result = func(*args, **kwargs)
#         return result
#
#     return wrapper
