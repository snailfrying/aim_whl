# -*- coding:utf-8 -*-
#                 ____                                       _____  __         
#                /\  _`\                                    /\___ \/\ \        
#                \ \ \L\_\  __  __     __      ___          \/__/\ \ \ \___    
#                 \ \ \L_L /\ \/\ \  /'__`\  /' _ `\           _\ \ \ \  _ `\  
#                  \ \ \/, \ \ \_\ \/\ \L\.\_/\ \/\ \         /\ \_\ \ \ \ \ \ 
#                   \ \____/\ \____/\ \__/.\_\ \_\ \_\        \ \____/\ \_\ \_\
#                    \/___/  \/___/  \/__/\/_/\/_/\/_/  _______\/___/  \/_/\/_/
#                                                      /\______\               
#                                                      \/______/  
'''
@FileName  :Model_Center.py

@Time      :2023/11/01 11:42

@Author    :Guan_jh

@Email     :guan_jh@qq.com

@Describe  :

'''
import os
import sys
import time
import warnings
from pathlib import Path
import pandas as pd
from typing import Optional, Union
from loguru import logger
import inspect

from Sinobase_Aim_Model_Center.model_center import train, push, predict, exportConfig
from Sinobase_Aim_Model_Center.model_util import Preload, SuperVar, logConfig
from Sinobase_Aim_Model_Center.model_util.loadConfig import loadConfig
from Sinobase_Aim_Model_Center.model_util.paths import get_config_path
from Sinobase_Aim_Model_Center.rfm import rfm
from Sinobase_Aim_Model_Center.rfm import rfm_predict

class ModelCenter:
    _expand_path = 'resource/expand/'
    _base_path = 'resource/base/'

    def __init__(self,
                 start_json: Optional[dict] = None,
                 alarm_config_file: Union[Path, str] = None,
                 database_config_file: Union[Path, str] = None,
                 log_config_file: Union[Path, str] = None,
                 model_config_file: Union[Path, str] = None,
                 model_feature_file: Union[Path, str] = None,
                 sql_connect_file: Union[Path, str] = None,
                 base_config_file: Union[Path, str] = None,
                 default_database: Optional[str] = 'mysql',
                 source_database: Optional[str] = 'pgsql',
                 config_path: Union[Path, str] = None,
                 feature_deal: Optional[str] = None
                 ):

        # 日志配置
        if log_config_file is None and config_path is None:
            print("请写入log_config.yml")
            log_config_file = self._expand_path + 'log_config.yml'
            log_config_path = get_config_path(log_config_file)
        elif config_path is not None:
            log_config_path = config_path + '/log_config.yml'
        else:
            log_config_path = log_config_file
        SuperVar.setVar('log_config_path', log_config_path)
        # 数据库配置
        if database_config_file is None and config_path is None:
            print("请写入database_config.yml")
            database_file = self._expand_path + 'database_config.yml'
            database_path = get_config_path(database_file)
        elif config_path is not None:
            database_path = config_path + '/database_config.yml'
        else:
            database_path = database_config_file
        database_config = loadConfig().read(database_path)
        SuperVar.setVar('database_path', database_path)
        SuperVar.setVar('database_config', database_config)

        # 模型基础配置
        if model_config_file is None and config_path is None:
            print("请写入database_config.yml")
            model_config_file = self._expand_path + 'model_config.yml'
            model_config_path = get_config_path(model_config_file)
        elif config_path is not None:
            model_config_path = config_path + '/model_config.yml'
        else:
            model_config_path = model_config_file
        model_config = loadConfig().read(model_config_path)
        SuperVar.setVar('model_config_path', model_config_file)
        SuperVar.setVar('model_config', model_config)

        # 模型特征
        if model_feature_file is None and config_path is None:
            model_feature_file = self._expand_path + 'Model_feature.yml'
            model_feature_path = get_config_path(model_feature_file)
        elif config_path is not None:
            model_feature_path = config_path + '/Model_feature.yml'
        else:
            model_feature_path = model_feature_file
        model_feature = loadConfig().read(model_feature_path)
        SuperVar.setVar('model_feature_path', model_feature_path)
        SuperVar.setVar('model_feature', model_feature)

        # 预警配置
        if alarm_config_file is None:
            alarm_config_file = self._expand_path + 'alarm_config.yml'
            alarm_config_path = get_config_path(alarm_config_file)
        elif config_path is not None:
            alarm_config_path = config_path + '/alarm_config.yml'
        else:
            alarm_config_path = alarm_config_file
        alarm_config = loadConfig().read(alarm_config_path)
        SuperVar.setVar('alarm_config_path', alarm_config_path)
        SuperVar.setVar('alarm_config', alarm_config)

        # sql连接字符串
        if sql_connect_file is None:
            sql_connect_file = self._base_path + 'sql_connect.yml'
            sql_connect_path = get_config_path(sql_connect_file)
        else:
            sql_connect_path = sql_connect_file
        SuperVar.setVar('sql_connect_path', sql_connect_path)

        # 基础设置
        if base_config_file is None and config_path is None:
            base_config_file = self._expand_path + 'base_config.yml'
            base_config_path = get_config_path(base_config_file)
        elif config_path is not None:
            base_config_path = config_path + '/base_config.yml'
        else:
            base_config_path = base_config_file
        base_config = loadConfig().read(base_config_path)
        SuperVar.setVar('base_config_path', base_config_path)
        SuperVar.setVar('base_config', base_config)

        try:
            if base_config['ext_file'] and (feature_deal is not None or start_json['feature_deal'] is not None):
                if start_json['feature_deal'] is not None:
                    SuperVar.setVar("main_file", start_json['feature_deal'])
                else:
                    SuperVar.setVar("main_file", feature_deal)
            else:
                if base_config['databricks']:
                    main_file = 'GuanJiahao'
                    SuperVar.setVar("main_file", main_file)
                else:
                    main_file = inspect.stack()[1].filename.strip(' ')
                    SuperVar.setVar("main_file", main_file)
        except:
            # if not base_config['ext_file']:
            #     main_file = inspect.stack()[1].filename.strip(' ')
            #     SuperVar.setVar("main_file", main_file)
            # else:
            print('允许使用外部文件，但外部文件不存在')
            main_file = 'GuanJiahao'
            SuperVar.setVar("main_file", main_file)

        SuperVar.setVar("all_start", time.time())
        SuperVar.setVar("default_database", default_database)
        SuperVar.setVar("source_database", source_database)

        log_config = loadConfig().get_config(log_config_path)
        SuperVar.setVar('log_config', log_config)
        if start_json is not None:
            SuperVar.setVar("start_json", start_json)
        try:
            if start_json['System_info'] == 'Sinobase':
                SuperVar.setVar("System_info", 'Sinobase')
        except:
            SuperVar.setVar("System_info", 'User')
            if "file_path" in start_json.keys():
                SuperVar.setVar("file_path", start_json['file_path'])
                SuperVar.setVar("start_json", start_json)
            else:
                print("请在mock_json中 写入 file_path")
                sys.exit(0)
        try:
            SuperVar.setVar("model_species", start_json['model_species'])
            if start_json['model_species'] != 'classier' and start_json['model_species'] != 'regress' and start_json[
                'model_species'] != 'kmeans':
                warnings.warn("model_species参数错误，任务将被强制停止")
                sys.exit(0)
        except:
            pass
        try:
            SuperVar.setVar("task_id", start_json['task_id'])
        except:
            pass
        try:
            SuperVar.setVar("tenant", start_json['tenant'])
        except:
            pass
        try:
            SuperVar.setVar("predict_id", start_json['predict_id'])
        except:
            pass

        try:
            SuperVar.setVar("primary", start_json['primary'])
        except:
            pass
        try:
            SuperVar.setVar("alg_name", start_json['alg_name'])
        except:
            pass
        try:
            SuperVar.setVar("out_list", start_json['out_list'])
        except:
            SuperVar.setVar("out_list", [])
        if not SuperVar.getVar("base_config")['model_save']:
            import mlflow
            mlflow.autolog()
            SuperVar.setVar('mlflow', mlflow)
        sql_connects = loadConfig().get_config(sql_connect_path)
        if SuperVar.getVar("System_info") == 'User':
            open_alarm = False
        if SuperVar.getVar("System_info") == 'Sinobase':
            open_alarm = alarm_config['alarm']['open']
        SuperVar.setVar("open_alarm", open_alarm)
        sql_config = database_config['database'][default_database]
        source_sql_config = database_config['database'][source_database]
        if database_config['databricks']['open']:
            from Sinobase_Aim_Model_Center.model_util import DatabricksGetPassword
            sql_config['password'] = DatabricksGetPassword.get_password_from_secrets(
                database_config['databricks']['secret_scope'],
                database_config['databricks'][default_database + '_secret_key'])
            source_sql_config['password'] = DatabricksGetPassword.get_password_from_secrets(
                database_config['databricks']['secret_scope'],
                database_config['databricks'][source_database + '_secret_key'])
        engine = Preload.sql_init(sql_config, sql_connects[default_database])
        source_engine = Preload.sql_init(source_sql_config, sql_connects[source_database])
        from datetime import datetime

        SuperVar.setVar("engine", engine)
        SuperVar.setVar("source_engine", source_engine)
        # 设置上海时区
        import pytz
        shanghai_tz = pytz.timezone('Asia/Shanghai')

        # 获取上海时区的当前时间
        shanghai_time = datetime.now(shanghai_tz)
        create_time = shanghai_time.strftime('%Y-%m-%d %H:%M:%S')
        SuperVar.setVar("create_time", create_time)

        # 生成日志
        log_config = SuperVar.getVar('log_config')
        logger = logConfig.Createlogging(log_config['LogConfig'], 'init', 'task')
        logger.info("")
        logger.info("============================任务初始化中=================================")
        if database_config_file is None and config_path is None:
            logger.debug("")
            logger.debug("============================初始化未完成=================================")
            SuperVar.setVar("init", False)
        else:
            SuperVar.setVar("init", True)
            if SuperVar.getVar("System_info") == 'Sinobase':
                # 获取创建者
                creator = engine.execute(
                    sql="""select user_id from model_instance where id = '%s'""" % start_json[
                        'task_id']).values.tolist()[
                    0][0]
                SuperVar.setVar("creator", creator)
                # 获取场景对应的type
                sc_type = engine.execute(
                    sql="""select a.type from model_mllib a left join model_instance b on a.id = b.model_id where b.id = '%s'""" %
                        start_json['task_id']).values.tolist()[
                    0][0]
                SuperVar.setVar("sc_type", sc_type)
                # 获取训练名称
                task_name = engine.execute(
                    sql="""select name from model_instance where id='%s'""" % start_json['task_id']).values.tolist()[
                    0][0]
                SuperVar.setVar("task_name", task_name)
                # 将pid保存
                engine.execute(
                    sql="""UPDATE model_instance SET pid = '%s'  WHERE id ='%s' """ % (
                        os.getpid(), start_json['task_id']))
                # 获取数据路径
                location = engine.execute(
                    sql="""select data_table from model_instance where id='%s'""" % start_json[
                        'task_id']).values.tolist()[
                    0][0]
                SuperVar.setVar("location", location)
                try:
                    # 如果有predict_id表示是预测，测根据预测表提取预测文件路径
                    location = engine.execute(
                            sql = """select csv_path from model_pre_lib where pre_id='%s'""" % start_json[
                                'predict_id' ]).values.tolist()[
                        0 ][ 0 ]
                    SuperVar.setVar("location", location)
                except:
                    pass
                # 获取数据类型
                filetype = engine.execute(
                    sql="""select data_type from model_instance where id='%s'""" % start_json[
                        'task_id']).values.tolist()[
                    0][0]
                SuperVar.setVar("filetype", filetype)
                logger.debug("")
                logger.debug("============================初始化已完成=================================")
            elif SuperVar.getVar("System_info") == 'User':
                task_id = '100000'
                SuperVar.setVar("task_id", task_id)
                tenant = 't'
                SuperVar.setVar('tenant', tenant)
                alg_name = 'mock测试算法'
                SuperVar.setVar("alg_name", alg_name)

                # 获取创建者
                creator = 'mock测试用户'
                SuperVar.setVar("creator", creator)
                print("测试 creator", creator)
                # 获取训练名称
                task_name = 'mock测试任务'
                SuperVar.setVar("task_name", task_name)
                # 获取数据路径
                location = start_json['file_path']
                SuperVar.setVar("location", location)
                # 获取数据类型
                filetype = 2
                SuperVar.setVar("filetype", filetype)
                predict_id = "mock预测id"
                SuperVar.setVar("predict_id", predict_id)

                logger.debug("")
                logger.debug("============================初始化已完成=================================")

    @staticmethod
    def train(model, param_dist) -> None:
        if not SuperVar.getVar("init"):
            logger.info("请使用exportConfig方法导出配置文件 进行必要初始化")
            sys.exit(0)
        else:
            train.train(model, param_dist)

    @staticmethod
    def train_system() -> None:
        if not SuperVar.getVar("init"):
            logger.info("请使用exportConfig方法导出配置文件 进行必要初始化")
            sys.exit(0)
        else:
            train.train_system()

    @staticmethod
    def predict() -> None:
        if not SuperVar.getVar("init"):
            logger.info("请使用exportConfig方法导出配置文件 进行必要初始化")
            sys.exit(0)
        else:
            predict.predict()

    @staticmethod
    def push() -> None:
        if not SuperVar.getVar("init"):
            logger.info("请使用exportConfig方法导出配置文件 进行必要初始化")
            sys.exit(0)
        else:
            push.push()

    @staticmethod
    def exportConfig(path) -> None:
        exportConfig.export_config(path)

    @staticmethod
    def rfm() -> None:
        rfm.rfm_start()

    @staticmethod
    def rfm_predict( ) -> None:
        rfm_predict.rfm_predict_start()




